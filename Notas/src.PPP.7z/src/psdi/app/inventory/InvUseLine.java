package psdi.app.inventory;

import psdi.app.mr.MRLineRemote;
import psdi.app.item.ItemSetRemote;
import java.util.Hashtable;
import psdi.app.location.LocationServiceRemote;
import java.util.Arrays;
import psdi.app.asset.Asset;
import psdi.app.asset.AssetSetRemote;
import psdi.security.UserInfo;
import psdi.app.po.POLineRemote;
import psdi.app.po.PORemote;
import psdi.app.po.Shipment;
import psdi.app.site.SiteServiceRemote;
import psdi.util.MXMath;
import psdi.app.inventory.virtual.IssuedItemForReturnSet;
import psdi.app.inventory.virtual.ReservationSet;
import psdi.app.signature.SignatureServiceRemote;
import java.util.HashMap;
import psdi.app.location.Location;
import java.util.Calendar;
import psdi.app.item.ItemRemote;
import psdi.app.financial.FinancialServiceRemote;
import psdi.app.item.Item;
import java.util.ArrayList;
import psdi.app.asset.AssetRemote;
import psdi.app.workorder.WORemote;
import psdi.app.common.TransactionGLMerger;
import psdi.mbo.MboSetRemote;
import psdi.mbo.SqlFormat;
import java.util.Date;
import psdi.server.MXServer;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import psdi.mbo.MboSetInfo;
import psdi.mbo.MboValueInfo;
import java.rmi.RemoteException;
import psdi.util.MXException;
import psdi.mbo.MboSet;
import psdi.util.MXApplicationException;
import psdi.mbo.MboRemote;
import psdi.mbo.Mbo;

public class InvUseLine extends Mbo implements InvUseLineRemote
{
    MboRemote issueMbo;
    double remainQty;
    boolean autocreated;
    long maxInvUseLineLimit;
    public boolean binNumSet;
    boolean updatedToInvbal;
    MXApplicationException conversionException;
    
    public InvUseLine(final MboSet ms) throws MXException, RemoteException {
        super(ms);
        this.issueMbo = null;
        this.remainQty = -1.11;
        this.autocreated = false;
        this.maxInvUseLineLimit = 0L;
        this.binNumSet = false;
        this.updatedToInvbal = false;
        this.conversionException = null;
    }
    
    @Override
    public void init() throws MXException {
        super.init();
        final String[] alwaysReadOnly = { "invuselinenum", "requestnum", "displayunitcost", "displaylinecost", "split", "mrnum", "mrlinenum", "ponum", "polinenum", "shelflife", "useby", "issueid", "newassetnum", "returnagainstissue", "toconditioncode", "shiptoattn", "unitcost", "restype" };
        this.setFieldFlag(alwaysReadOnly, 7L, true);
        try {
            final MboRemote owner = this.getOwner();
            if (owner != null && owner.isBasedOn("INVUSE") && ((InvUse)owner).isEntered() && this.isReturn() && this.isNull("issueid")) {
                this.setFieldFlag("unitcost", 7L, false);
                this.setFieldFlag("displayunitcost", 7L, false);
            }
            if (!this.toBeAdded()) {
                this.setDisplayUnitCost();
                if (!this.getString("issueid").equals("")) {
                    this.setAttributesEditibiltyForReturn();
                }
                if (this.getDouble("physcnt") > 0.0) {
                    this.setValue("newphyscnt", this.getDouble("physcnt"), 11L);
                }
                this.setValue("newphyscntdate", this.getDate("physcntdate"), 11L);
                if (this.isRotating() && owner != null && owner.isBasedOn("INVUSE")) {
                    ((InvUse)owner).setRotQtyMap(this.getLong("invuselineid"), this.getDouble("quantity"));
                }
            }
            if (owner != null && owner.isBasedOn("INVUSE")) {
                final String[] invUseReadOnly = { "invusenum", "usetype", "fromstoreloc" };
                ((InvUse)owner).setFieldFlag(invUseReadOnly, 7L, true);
            }
            this.setFieldFlag("refwo", 512L, true);
            this.setFieldFlag("asset", 512L, true);
            this.setFieldFlag("location", 512L, true);
            if (owner != null && owner.isBasedOn("INVUSE") && !((InvUse)owner).isEntered()) {
                final MboSetInfo msi = this.getMboSetInfo();
                final Map attrsOrig = msi.getAttributeDetails();
                for (final MboValueInfo mvi : (Collection<MboValueInfo>)attrsOrig.values()) {
                    if (!mvi.isUserdefined()) {
                        this.setFieldFlag(mvi.getAttributeName().toLowerCase(), 7L, true);
                    }
                }
            }
        }
        catch (RemoteException e) {
            e.printStackTrace();
        }
    }
    
    @Override
    public void add() throws MXException, RemoteException {
        final MboRemote owner = this.getOwner();
        if (owner == null) {
            return;
        }
        super.add();
        if (owner.isBasedOn("INVUSE")) {
            this.setValue("invusenum", owner.getString("invusenum"), 2L);
            this.setValue("fromstoreloc", owner.getString("fromstoreloc"), 2L);
            final String lineType = this.getMboValue("linetype").getMboValueInfo().getDefaultValue();
            if (lineType != null) {
                this.setValue("linetype", lineType, 3L);
            }
            else {
                this.setValue("linetype", this.getTranslator().toExternalDefaultValue("LINETYPE", "ITEM", this), 11L);
            }
            this.setValue("usetype", owner.getString("usetype"), 2L);
            this.setValue("tositeid", owner.getString("siteid"), 11L);
            this.setValue("toorgid", owner.getString("orgid"), 11L);
            if (this.isMixed()) {
                this.setValue("usetype", this.getTranslator().toExternalDefaultValue("INVUSETYPE", "ISSUE", this), 11L);
            }
            this.setValue("invuselinenum", (int)this.getThisMboSet().max("invuselinenum") + 1, 2L);
            final Date currentDate = MXServer.getMXServer().getDate();
            this.setValue("actualdate", currentDate, 2L);
            this.setValue("physcnt", 0, 2L);
            this.setValue("physcntdate", currentDate, 2L);
            this.setValue("newphyscntdate", currentDate, 2L);
            this.setValue("enterby", this.getUserInfo().getUserName(), 2L);
            this.setValue("displayunitcost", 0, 2L);
            this.setValue("returnagainstissue", false, 2L);
            this.setFieldFlag("returnagainstissue", 7L, true);
        }
    }
    
    @Override
    public boolean isIssue() throws MXException, RemoteException {
        return !this.isNull("USETYPE") && this.getTranslator().toInternalString("INVUSETYPE", this.getString("USETYPE")).equalsIgnoreCase("ISSUE");
    }
    
    @Override
    public boolean isReturn() throws MXException, RemoteException {
        return !this.isNull("USETYPE") && this.getTranslator().toInternalString("INVUSETYPE", this.getString("USETYPE")).equalsIgnoreCase("RETURN");
    }
    
    @Override
    public boolean isMixed() throws MXException, RemoteException {
        return !this.isNull("USETYPE") && this.getTranslator().toInternalString("INVUSETYPE", this.getString("USETYPE")).equalsIgnoreCase("MIXED");
    }
    
    @Override
    public boolean isTransfer() throws MXException, RemoteException {
        return !this.isNull("USETYPE") && this.getTranslator().toInternalString("INVUSETYPE", this.getString("usetype")).equalsIgnoreCase("TRANSFER");
    }
    
    public boolean isRotating() throws MXException, RemoteException {
        final MboRemote ItemMbo = this.getMboSet("ITEM").getMbo(0);
        return ItemMbo != null && ItemMbo.getBoolean("rotating");
    }
    
    public boolean isTool() throws MXException, RemoteException {
        return this.getTranslator().toInternalString("LINETYPE", this.getString("linetype")).equals("TOOL");
    }
    
    public MboRemote getSharedInventory() throws MXException, RemoteException {
        final SqlFormat sqf = new SqlFormat(this, "itemnum = :itemnum and location = :1 and siteid=:2 and itemsetid = :itemsetid");
        sqf.setObject(1, "LOCATIONS", "LOCATION", this.getString("fromstoreloc"));
        sqf.setObject(2, "SITE", "SITEID", this.getString("siteid"));
        final MboSetRemote invSet = ((MboSet)this.getThisMboSet()).getSharedMboSet("INVENTORY", sqf.format());
        if (invSet == null || invSet.isEmpty()) {
            return null;
        }
        return invSet.getMbo(0);
    }
    
    @Override
    public MboRemote getSharedInvBalance() throws MXException, RemoteException {
        InvBalances bal = null;
        final String checkBinnum = this.getString("frombin");
        final String checkLotnum = this.getString("fromlot");
        final String conditionCode = this.getString("fromconditionCode");
        final MboRemote inventoryMbo = this.getSharedInventory();
        if (inventoryMbo == null) {
            return null;
        }
        bal = ((Inventory)inventoryMbo).getInvBalanceRecord(checkBinnum, checkLotnum, conditionCode);
        return bal;
    }
    
    public MboRemote getSharedInventory(final String storeLoc, final String siteid) throws MXException, RemoteException {
        final SqlFormat sqf = new SqlFormat(this, "itemnum = :itemnum and location = :1 and siteid = :2");
        sqf.setObject(1, "INVENTORY", "location", storeLoc);
        sqf.setObject(2, "INVENTORY", "siteid", siteid);
        MboSetRemote invSet = null;
        invSet = ((MboSet)this.getThisMboSet()).getSharedMboSet("INVENTORY", sqf.format());
        if (invSet == null || invSet.isEmpty()) {
            return null;
        }
        return invSet.getMbo(0);
    }
    
    public MboRemote getSharedInvBalance(final String binnum, final String lotnum) throws MXException, RemoteException {
        InvBalances bal = null;
        final String conditionCode = this.getString("fromconditionCode");
        final MboRemote inventoryMbo = this.getSharedInventory();
        if (inventoryMbo == null) {
            return null;
        }
        bal = ((Inventory)inventoryMbo).getInvBalanceRecord(binnum, lotnum, conditionCode);
        return bal;
    }
    
    public MboRemote getSharedInvBalance(final String binnum, final String lotnum, final String storeloc, final String siteid) throws MXException, RemoteException {
        InvBalances bal = null;
        final String conditionCode = this.getString("fromconditionCode");
        final MboRemote inventoryMbo = this.getSharedInventory(storeloc, siteid);
        if (inventoryMbo == null) {
            return null;
        }
        bal = ((Inventory)inventoryMbo).getInvBalanceRecord(binnum, lotnum, conditionCode, storeloc, siteid);
        return bal;
    }
    
    void updateGlAccounts() throws MXException, RemoteException {
        final TransactionGLMerger glm = new TransactionGLMerger(this);
        glm.setMRInfo(this.getString("mrnum"), this.getString("mrlinenum"));
        glm.setItem(this.getString("itemnum"));
        glm.setItemSetID(this.getString("itemsetid"));
        glm.setConditionCode(this.getString("fromconditioncode"));
        final MboRemote owner = this.getOwner();
        if (owner == null || !(owner instanceof WORemote) || !this.getString("wonum").equals(owner.getString("wonum"))) {
            glm.setWonum(this.getString("wonum"));
        }
        else {
            glm.setWO(owner);
        }
        glm.setAssetnum(this.getString("assetnum"));
        glm.setLocation(this.getString("location"));
        glm.setStoreLoc(this.getString("fromstoreloc"));
        if (!this.isNull("gldebitacct")) {
            this.setValue("gldebitacct", glm.mergedGL(this.getTopGL(glm), this.getString("gldebitacct")), 11L);
        }
        else {
            this.setValue("gldebitacct", glm.getMergedDebitGLAccount(), 11L);
        }
    }
    
    private String getTopGL(final TransactionGLMerger glm) throws MXException, RemoteException {
        String topGl = null;
        if (!this.isNull("itemnum")) {
            if (this.isNull("fromstoreloc")) {
                topGl = glm.getItemResourceAccount();
            }
            else {
                topGl = glm.getInventoryGLAccount();
            }
        }
        return topGl;
    }
    
    double getDefaultIssueCost() throws MXException, RemoteException {
        double issueCost = 0.0;
        if (!this.isNull("itemnum") && !this.isNull("fromstoreloc")) {
            final String conditionCode = this.getString("fromconditioncode");
            final Inventory inventory = (Inventory)this.getMboSet("INVENTORY").getMbo(0);
            if (inventory != null) {
                final MboRemote invcost = inventory.getInvCostRecord(conditionCode);
                if (this.isIssue() || this.isTransfer() || invcost != null) {
                    if (!this.isNull("rotassetnum")) {
                        final AssetRemote rotAsset = (AssetRemote)this.getMboSet("ROTATINGASSET").getMbo(0);
                        issueCost = inventory.getDefaultIssueCost(rotAsset, conditionCode);
                    }
                    else {
                        issueCost = inventory.getDefaultIssueCost(conditionCode);
                    }
                }
                else {
                    final double fullIssueCost = inventory.getDefaultIssueCost();
                    final MboRemote itemcond = this.getMboSet("ITEMCONDITION").getMbo(0);
                    final double condrate = itemcond.getDouble("condrate");
                    issueCost = fullIssueCost * (condrate / 100.0);
                }
            }
        }
        return issueCost;
    }
    
    public void setIssueForThisReturn(final MboRemote issue) throws MXException, RemoteException {
        this.issueMbo = issue;
    }
    
    MboRemote getIssueForThisReturn() throws MXException, RemoteException {
        if (this.issueMbo == null) {
            final SqlFormat sqf = new SqlFormat(this, " matusetransid=:1 and siteid=:siteid");
            sqf.setObject(1, "MATUSETRANS", "MATUSETRANSID", this.getString("issueid"));
            this.issueMbo = this.getMboSet("$MatUseTransId" + this.getString("issueid"), "MATUSETRANS", sqf.format()).getMbo(0);
        }
        return this.issueMbo;
    }
    
    public MboRemote getWO() throws MXException, RemoteException {
        final MboRemote owner = this.getOwner();
        if (owner != null && owner instanceof WORemote) {
            return owner;
        }
        if (this.isNull("refwo")) {
            return null;
        }
        final SqlFormat sqf = new SqlFormat(this, "wonum=:refwo and siteid=:tositeid");
        final MboSetRemote woset = ((MboSet)this.getThisMboSet()).getSharedMboSet("WORKORDER", sqf.format());
        MboRemote woMbo = null;
        if (!woset.isEmpty()) {
            woMbo = woset.getMbo(0);
        }
        return woMbo;
    }
    
    public void validateInvUseLine(final ArrayList<InvUseLineSplitRemote> splitList) throws MXException, RemoteException {
        if (this.isIssue()) {
            final InventoryRemote invRem = (InventoryRemote)this.getSharedInventory();
            if (invRem != null) {
                invRem.checkRequestAgainstItemMaxIssue(this.getString("assetnum"), -this.getDouble("quantity"));
            }
        }
        if (splitList == null) {
            this.setValue("split", false, 2L);
            this.checkForNegativeBalance(this.getSharedInvBalance(), null);
        }
        else {
            this.setValue("split", true, 2L);
            for (int i = 0; i < splitList.size(); ++i) {
                final InvUseLineSplitRemote invuseLineSplit = splitList.get(i);
                if (!invuseLineSplit.toBeDeleted()) {
                    final MboRemote invBal = this.getSharedInvBalance(invuseLineSplit.getString("frombin"), invuseLineSplit.getString("fromlot"));
                    this.checkForNegativeBalance(invBal, invuseLineSplit);
                }
            }
        }
    }
    
    public void preValidateLine() throws MXException, RemoteException {
        if (this.getDouble("quantity") == 0.0) {
            throw new MXApplicationException("po", "nonNegativeQty");
        }
        if (this.isTransfer() && this.isNull("toStoreLoc")) {
            throw new MXApplicationException("inventory", "transferNoStoreRoom");
        }
        if (this.isNull("conversion") && !this.isNull("itemnum") && !this.isNull("tostoreloc")) {
            if (this.conversionException == null) {
                throw new MXApplicationException("inventory", "conversionDoesNotExistNullMU", new MXApplicationException("inventory", "conversionDoesNotExistInstruction"));
            }
            if (!this.isNull("ponum") && !this.isNull("polinenum")) {
                final Object[] err = { this.conversionException.params[0], this.conversionException.params[1], this.getString("polinenum") };
                throw new MXApplicationException("inventory", "conversionDoesNotExistPOline", err, new MXApplicationException("inventory", "conversionDoesNotExistInstruction"));
            }
            throw new MXApplicationException("inventory", "conversionDoesNotExist", this.conversionException.params, new MXApplicationException("inventory", "conversionDoesNotExistInstruction"));
        }
        else if (!this.isNull("ponum") && this.isNull("polinenum")) {
            final Object[] params = { this.getMboValue("polinenum").getName() };
            throw new MXApplicationException("system", "null", params);
        }
    }
    
    public void validateLine() throws MXException, RemoteException {
        if (this.toBeDeleted() || this.isNull("itemnum")) {
            return;
        }
        if (this.isTransfer() && !this.getBoolean("split")) {
            final String fromLocation = this.getString("fromstoreloc");
            final String fromBin = this.getString("frombin");
            final String fromLot = this.getString("fromlot");
            final String fromCondition = this.getString("fromconditioncode");
            final String fromSiteID = this.getString("siteid");
            final String toLocation = this.getString("tostoreloc");
            final String toBin = this.getString("tobin");
            final String toLot = this.getString("tolot");
            final String toCondition = this.getString("toconditioncode");
            final String toSiteID = this.getString("tositeid");
            if (fromLocation.equals(toLocation) && fromBin.equals(toBin) && fromLot.equals(toLot) && fromCondition.equals(toCondition) && fromSiteID.equals(toSiteID)) {
                throw new MXApplicationException("inventory", "transferToIdentical");
            }
        }
        if (this.isTransfer() && ((Item)this.getMboSet("ITEM").getMbo(0)).isLotted() && this.getString("tolot").equals("")) {
            throw new MXApplicationException("inventory", "toBinAndToLotEmpty");
        }
        if (!this.getBoolean("split")) {
            this.setValue("unitcost", this.getDouble("displayunitcost"), 2L);
            this.setValue("physcnt", this.getDouble("newphyscnt"), 2L);
            this.setValue("physcntdate", this.getDate("newphyscntdate"), 2L);
        }
        if (!this.isTransfer() && !this.getTranslator().toInternalString("LINETYPE", this.getString("linetype")).equals("TOOL")) {
            final FinancialServiceRemote fsr = (FinancialServiceRemote)MXServer.getMXServer().lookup("FINANCIAL");
            final boolean requireGL = fsr.glRequiredForTrans(this.getUserInfo(), this.getString("orgid"));
            if (this.isNull("refwo") && this.isNull("assetnum") && this.isNull("location") && this.isNull("gldebitacct") && requireGL && this.isNull("mrnum")) {
                throw new MXApplicationException("inventory", "matusetransNullChargeTo");
            }
        }
        if (!this.getString("mrnum").equals("") && this.getString("mrlinenum").equals("")) {
            throw new MXApplicationException("inventory", "specifyReqLineNum");
        }
        if (!this.getString("mrlinenum").equals("") && this.getString("mrnum").equals("")) {
            throw new MXApplicationException("inventory", "specifyReqNum");
        }
        if (!this.isNull("rotassetnum") && (this.isIssue() || this.isTransfer())) {
            final MboRemote rotasset = this.getMboSet("ROTASSET").getMbo(0);
            if (rotasset != null && !this.getString("frombin").equalsIgnoreCase(rotasset.getString("binnum"))) {
                final Object[] param = { "Item/Rotating Asset/Bin combination", "" };
                throw new MXApplicationException("commlog", "InvalidTemplateId", param);
            }
        }
        if (this.checkRotatingAssetExistInToSite(this.getString("rotassetnum"), this) && this.getString("newassetnum").equals("")) {
            final String[] params = { this.getString("rotassetnum"), this.getString("tositeid") };
            throw new MXApplicationException("inventory", "blankNewAssetNum", params);
        }
        ItemRemote item = null;
        if (!this.isNull("itemnum")) {
            item = (ItemRemote)this.getMboSet("ITEM").getMbo(0);
            if (item.isConditionEnabled() && this.isNull("fromconditioncode")) {
                final Object[] param = { this.getString("itemnum") };
                throw new MXApplicationException("inventory", "noConditionCode", param);
            }
        }
        final MboRemote inventory = this.getSharedInventory();
        if (inventory == null) {
            throw new MXApplicationException("inventory", "invbalNotInInventory");
        }
        if (this.isTransfer()) {
            final MboRemote toInventory = this.getSharedInventory(this.getString("tostoreloc"), this.getString("tositeid"));
            if (toInventory != null && ((Inventory)toInventory).isConsignment()) {
                throw new MXApplicationException("inventory", "ConsignmentStoreroomNotAllowed");
            }
        }
        MboRemote invBal = null;
        if (!this.getBoolean("split")) {
            invBal = this.getSharedInvBalance();
            if (invBal == null && (this.isIssue() || this.isTransfer())) {
                final Object[] param2 = { this.getString("itemnum") };
                throw new MXApplicationException("inventory", "invuselineNoBalances", param2);
            }
            if (invBal != null && item != null && !item.isLotted()) {
                final Date currentUseBy = invBal.getDate("useby");
                Calendar currentUseByCal = null;
                if (currentUseBy != null) {
                    currentUseByCal = Calendar.getInstance();
                    currentUseByCal.setTime(currentUseBy);
                    final Date now = MXServer.getMXServer().getDate();
                    final Calendar nowCal = Calendar.getInstance();
                    nowCal.setTime(now);
                    nowCal.set(11, 0);
                    nowCal.set(12, 0);
                    nowCal.set(13, 0);
                    nowCal.set(14, 0);
                    if (currentUseByCal.before(nowCal)) {
                        throw new MXApplicationException("inventory", "expiredLot");
                    }
                }
            }
        }
        if (!this.isNull("RefWO")) {
            if (this.getWO() != null && this.getWO().getBoolean("HistoryFlag") && (this.isIssue() || this.isTransfer())) {
                final Object[] param2 = { this.getString("refwo"), this.getMboValue("REFWO").getColumnTitle() };
                throw new MXApplicationException("workorder", "WOHistory", param2);
            }
            this.verifyChangesAreAllowed();
        }
        boolean noFinancial = false;
        if (this.getTranslator().toInternalString("LINETYPE", this.getString("linetype")).equals("TOOL")) {
            noFinancial = true;
        }
        final FinancialServiceRemote fsr2 = (FinancialServiceRemote)MXServer.getMXServer().lookup("FINANCIAL");
        if (!noFinancial) {
            final MboRemote owner = this.getOwner();
            if (owner != null && owner.isBasedOn("InvUse")) {
                final String fromOrgId = this.getString("orgid");
                if (fsr2.glRequiredForTrans(this.getUserInfo(), fromOrgId) && (this.isNull("gldebitacct") || this.isNull("glcreditacct"))) {
                    throw new MXApplicationException("financial", "GLRequiredForTrans");
                }
                if (owner.isBasedOn("InvUse")) {
                    final String glDebitAcct = this.getString("gldebitacct");
                    final String toorgID = this.getString("toorgid");
                    if (!glDebitAcct.equals("")) {
                        final String[] params2 = { glDebitAcct };
                        if (!fsr2.validateFullGLAccount(this.getUserInfo(), glDebitAcct, toorgID)) {
                            throw new MXApplicationException("inventory", "InvalidGLAccount", params2);
                        }
                    }
                    if (!this.isNull("glcreditacct")) {
                        final String[] params2 = { this.getString("glcreditacct") };
                        if (!fsr2.validateFullGLAccount(this.getUserInfo(), this.getString("glcreditacct"), fromOrgId)) {
                            throw new MXApplicationException("inventory", "InvalidGLAccount", params2);
                        }
                    }
                }
            }
        }
    }
    
    public void checkAssetWOLocValidate() throws MXException, RemoteException {
        if (!this.getString("assetnum").equals("")) {
            final SqlFormat sqf = new SqlFormat(this, "assetnum=:assetnum and siteid=:tositeid");
            final MboRemote asset = this.getMboSet("$Asset" + this.getString("assetnum") + this.getString("tositeid"), "ASSET", sqf.format()).getMbo(0);
            if (asset == null || this.getTranslator().toInternalString("LOCASSETSTATUS", asset.getString("status"), asset).equalsIgnoreCase("DECOMMISSIONED")) {
                final String[] params = { this.getString("assetnum"), "" };
                throw new MXApplicationException("asset", "NotValidAsset", params);
            }
        }
        if (!this.isNull("RefWO")) {
            final MboRemote wo = this.getWO();
            if (wo != null && (this.getTranslator().toInternalString("WOSTATUS", wo.getString("status"), wo).equalsIgnoreCase("WAPPR") || this.getTranslator().toInternalString("WOSTATUS", wo.getString("status"), wo).equalsIgnoreCase("CAN") || this.getTranslator().toInternalString("WOSTATUS", wo.getString("status"), wo).equalsIgnoreCase("CLOSE"))) {
                final Object[] param = { this.getString("refwo"), this.getMboValue("REFWO").getColumnTitle() };
                throw new MXApplicationException("workorder", "NotValidNotCancelledWo", param);
            }
        }
        if (!this.isNull("location")) {
            final SqlFormat sqf = new SqlFormat(this, "location=:location and siteid=:tositeid");
            final MboRemote loc = this.getMboSet("$Location" + this.getString("location") + this.getString("tositeid"), "LOCATIONS", sqf.format()).getMbo(0);
            if (loc == null || ((Location)loc).isDecommissioned()) {
                final Object[] param2 = { this.getString("location"), this.getMboValue("location").getColumnTitle() };
                throw new MXApplicationException("locations", "NotValidStoreOtherLoc", param2);
            }
        }
    }
    
    @Override
    public void appValidate() throws MXException, RemoteException {
        if (this.getBoolean("validated")) {
            super.appValidate();
            return;
        }
        final MboRemote owner = this.getOwner();
        if (owner != null && owner.isBasedOn("INVUSE") && owner.isModified("status")) {
            final String maxStatus = this.getTranslator().toInternalString("INVUSESTATUS", owner.getString("status"), owner);
            if (maxStatus.equalsIgnoreCase("CANCELLED")) {
                super.appValidate();
                return;
            }
        }
        this.preValidateLine();
        super.appValidate();
        this.validateLine();
    }
    
    public boolean getBinNumFlag() {
        return this.binNumSet;
    }
    
    public void setBinNumFlag(final boolean binNumFlag) {
        this.binNumSet = binNumFlag;
    }
    
    MboRemote validateInventory(final String location, final String siteid) throws MXException, RemoteException {
        final SqlFormat sqf = new SqlFormat(this, "itemnum = :itemnum and itemsetid = :itemsetid and location = :1 and siteid = :2");
        sqf.setObject(1, "INVENTORY", "location", location);
        sqf.setObject(2, "INVENTORY", "siteid", siteid);
        final MboSetRemote invSet = this.getMboSet("$$$getInvSet_loc_site", "INVENTORY", sqf.format());
        if (invSet.isEmpty()) {
            throw new MXApplicationException("inventory", "invbalNotInInventory");
        }
        invSet.reset();
        return invSet.getMbo(0);
    }
    
    public MboRemote addUpdateInvUseLineSplit() throws MXException, RemoteException {
        final MboSetRemote invUseLineSplitSet = this.getMboSet("INVUSELINESPLIT");
        if (invUseLineSplitSet.count() > 1) {
            return null;
        }
        MboRemote invUseLineSplit = invUseLineSplitSet.getMbo(0);
        if (invUseLineSplit == null) {
            invUseLineSplit = invUseLineSplitSet.add(2L);
            invUseLineSplit.setValue("autocreated", true, 11L);
        }
        if (invUseLineSplit.getBoolean("autocreated")) {
            invUseLineSplit.setValue("itemsetid", this.getString("itemsetid"), 11L);
            invUseLineSplit.setValue("itemnum", this.getString("itemnum"), 11L);
            invUseLineSplit.setValue("fromstoreloc", this.getString("fromstoreloc"), 11L);
            invUseLineSplit.setValue("invusenum", this.getString("invusenum"), 11L);
            invUseLineSplit.setValue("invuselineid", this.getLong("invuselineid"), 11L);
            invUseLineSplit.setValue("quantity", this.getString("quantity"), 11L);
            invUseLineSplit.setValue("fromlot", this.getString("fromlot"), 11L);
            invUseLineSplit.setValue("frombin", this.getString("frombin"), 11L);
            invUseLineSplit.setValue("fromconditioncode", this.getString("fromconditioncode"), 11L);
            invUseLineSplit.setValue("invuselinenum", this.getString("invuselinenum"), 11L);
            invUseLineSplit.setValue("unitcost", this.getDouble("unitcost"), 11L);
            invUseLineSplit.setValue("rotassetnum", this.getString("rotassetnum"), 11L);
            invUseLineSplit.setValue("physcnt", 0, 2L);
            invUseLineSplit.setValue("physcntdate", MXServer.getMXServer().getDate(), 2L);
            if (!this.isNull("newphyscnt")) {
                invUseLineSplit.setValue("physcnt", this.getDouble("newphyscnt"), 2L);
                invUseLineSplit.setValue("physcntdate", this.getDate("newphyscntdate"), 2L);
            }
            invUseLineSplit.setValue("newassetnum", this.getString("newassetnum"), 11L);
            invUseLineSplit.setValueNull("sendersysid", 2L);
        }
        return invUseLineSplit;
    }
    
    public void save() throws MXException, RemoteException {
        if (this.toBeDeleted()) {
            super.save();
            ((InvUseLineSet)this.getThisMboSet()).clearInvBalMap();
            return;
        }
        final MboRemote owner = this.getOwner();
        final long maxInvUseLineLimit = ((InvUseLineSet)this.getThisMboSet()).readMaxInvUseLineLimitProperty();
        final Object[] params = { maxInvUseLineLimit + "" };
        if (owner != null && owner.isBasedOn("InvUse") && owner.getOwner() == null) {
            if (this.isRotating()) {
                ((InvUse)owner).setRotQtyMap(this.getLong("invuselineid"), this.getDouble("quantity"));
            }
            final HashMap<Long, Double> rotQtyMap = ((InvUse)owner).getRotQtyMap();
            double rotqty = 0.0;
            for (final Double value : rotQtyMap.values()) {
                rotqty += value;
            }
            if (rotqty > maxInvUseLineLimit) {
                throw new MXApplicationException("inventory", "MaxInvUseLineLimitExceeded", params);
            }
            final double lines = this.getThisMboSet().count(16) + rotqty - rotQtyMap.size();
            if (lines > maxInvUseLineLimit) {
                throw new MXApplicationException("inventory", "MaxInvUseLineLimitExceeded", params);
            }
        }
        if (owner != null && owner.isBasedOn("INVUSE") && ((InvUse)owner).isEntered()) {
            if (!this.getString("requestnum").equals("")) {
                this.updateInvReservePendingQty();
            }
            if (!this.getBoolean("split")) {
                this.addUpdateInvUseLineSplit();
            }
        }
        super.save();
        ((InvUseLineSet)this.getThisMboSet()).clearInvBalMap();
    }
    
    @Override
    public void setStagingBin(final String binflag, final String stagingBin) throws MXException, RemoteException {
        final MboRemote invMbo = this.getMboSet("INVENTORY").getMbo(0);
        if (binflag.equals("0")) {
            if (invMbo != null) {
                this.setValue("stagingbin", invMbo.getString("dfltstagebin"), 2L);
            }
        }
        else if (binflag.equals("1")) {
            this.setValue("stagingbin", stagingBin, 2L);
        }
        else {
            this.setValue("stagingbin", this.getString("frombin"), 2L);
        }
    }
    
    public void checkForNegativeBalance(final MboRemote invBal, final MboRemote invuselinesplit) throws MXException, RemoteException {
        final MboRemote owner = this.getOwner();
        double sumQuantity = 0.0;
        if (this.isIssue() || this.isTransfer()) {
            final MboRemote inventory = this.getSharedInventory();
            if (inventory == null) {
                return;
            }
            if (invBal == null) {
                return;
            }
            double avblQty = inventory.getDouble("avblBalance");
            if (avblQty < Math.abs(this.getDouble("quantity"))) {
                if (!this.isNull("requestnum")) {
                    final double reservedQty = this.getMboSet("InvReserve").getMbo(0).getDouble("RESERVEDQTY");
                    final double curBal = invBal.getDouble("curbal");
                    if (curBal >= reservedQty || curBal >= Math.abs(this.getDouble("quantity"))) {
                        avblQty = curBal;
                    }
                }
                else {
                    final MboSetRemote invresSet = this.getSharedInvReserveSet();
                    if (!invresSet.isEmpty()) {
                        final double sumReservedQty = invresSet.sum("reservedqty");
                        avblQty += sumReservedQty;
                    }
                }
            }
            final MboSetRemote invUseLineSet = this.getThisMboSet();
            int i = 0;
            while (true) {
                final InvUseLine invUseLine = (InvUseLine)invUseLineSet.getMbo(i);
                if (invUseLine == null) {
                    break;
                }
                if (!invUseLine.toBeDeleted()) {
                    if (!this.getBoolean("split") && !invUseLine.getBoolean("split") && this.getString("itemnum").equals(invUseLine.getString("itemnum")) && this.getString("frombin").equals(invUseLine.getString("frombin")) && this.getString("fromlot").equals(invUseLine.getString("fromlot"))) {
                        sumQuantity += Math.abs(invUseLine.getDouble("quantity"));
                    }
                }
                ++i;
            }
            if (this.getBoolean("split")) {
                final MboSetRemote invuselinesplitset = this.getOwner().getMboSet("SPLITUSELINE").getMbo(0).getMboSet("INVUSELINESPLIT");
                MboRemote uselinesplit = null;
                int j = 0;
                MboRemote mbo = this;
                if (invuselinesplit != null) {
                    mbo = invuselinesplit;
                }
                while ((uselinesplit = invuselinesplitset.getMbo(j)) != null) {
                    if (mbo.getString("itemnum").equals(uselinesplit.getString("itemnum")) && mbo.getString("frombin").equals(uselinesplit.getString("frombin")) && mbo.getString("fromlot").equals(uselinesplit.getString("fromlot"))) {
                        sumQuantity += Math.abs(invuselinesplit.getDouble("quantity"));
                    }
                    ++j;
                }
            }
            if (owner != null && owner.isBasedOn("INVUSE") && ((InvUse)owner).isStaged()) {
                this.canGoNegative(this.getUserInfo(), sumQuantity, invBal.getDouble("stagedcurbal"), avblQty, this);
            }
            else {
                this.canGoNegative(this.getUserInfo(), sumQuantity, invBal.getDouble("curbal"), avblQty, this);
            }
        }
    }
    
    public void checkForNegativeAvlBalanceBeforeSplitting() throws MXException, RemoteException {
        final MboRemote owner = this.getOwner();
        double sumQuantity = 0.0;
        if (this.isIssue() || this.isTransfer()) {
            final MboRemote inventory = this.getSharedInventory();
            if (inventory == null) {
                return;
            }
            final MboRemote invBal = this.getSharedInvBalance();
            if (invBal == null) {
                return;
            }
            double avblQty = inventory.getDouble("avblBalance");
            if (avblQty < Math.abs(this.getDouble("quantity"))) {
                if (!this.isNull("requestnum")) {
                    final MboRemote invReserve = this.getMboSet("InvReserve").getMbo(0);
                    double reservedQty = 0.0;
                    if (invReserve != null) {
                        reservedQty = invReserve.getDouble("RESERVEDQTY");
                    }
                    final double curBal = invBal.getDouble("curbal");
                    if (curBal >= reservedQty || curBal >= Math.abs(this.getDouble("quantity"))) {
                        avblQty = curBal;
                    }
                }
                else {
                    final MboSetRemote invresSet = this.getSharedInvReserveSet();
                    if (!invresSet.isEmpty()) {
                        final double sumReservedQty = invresSet.sum("reservedqty");
                        avblQty += sumReservedQty;
                    }
                }
            }
            final MboSetRemote invUseLineSet = this.getThisMboSet();
            int i = 0;
            while (true) {
                final InvUseLine invUseLine = (InvUseLine)invUseLineSet.getMbo(i);
                if (invUseLine == null) {
                    break;
                }
                if (!invUseLine.toBeDeleted()) {
                    if (this.getString("itemnum").equals(invUseLine.getString("itemnum")) && this.getString("frombin").equals(invUseLine.getString("frombin")) && this.getString("fromlot").equals(invUseLine.getString("fromlot"))) {
                        if (invUseLine.isReturn()) {
                            sumQuantity += Math.abs(invUseLine.getDouble("quantity")) * -1.0;
                        }
                        else {
                            sumQuantity += Math.abs(invUseLine.getDouble("quantity"));
                        }
                    }
                }
                ++i;
            }
            if (owner != null && owner.isBasedOn("INVUSE") && !((InvUse)owner).isStaged()) {
                this.canGoNegative(this.getUserInfo(), sumQuantity, avblQty, this);
            }
        }
    }
    
    public MboSetRemote getSharedInvReserveSet() throws MXException, RemoteException {
        SqlFormat sqf = null;
        final String requestNum = this.getString("requestnum");
        if (!this.getString("mrnum").equals("") && !this.getString("mrlinenum").equals("")) {
            sqf = new SqlFormat(this, "mrnum = :1 and mrlinenum = :2");
            sqf.setObject(1, "MR", "MRNUM", this.getString("mrnum"));
            sqf.setObject(2, "MRLINE", "MRLINENUM", this.getString("mrlinenum"));
        }
        else if (!this.isNull("itemnum") && (requestNum == null || requestNum.equals(""))) {
            final StringBuffer where = new StringBuffer("");
            if (!this.isNull("mrnum")) {
                where.append(" and prnum = :prnum");
                if (this.isNull("mrlinenum")) {
                    where.append(" and mrlinenum is null");
                }
                else {
                    where.append(" and mrlinenum = :mrlinenum");
                }
            }
            else if (!this.isNull("ponum")) {
                where.append(" and ponum=:ponum");
                if (this.isNull("polinenum")) {
                    where.append(" and polinenum is null");
                }
                else {
                    where.append(" and polinenum=:polinenum");
                }
            }
            else if (!this.isNull("refwo")) {
                where.append(" and wonum = :refwo");
                if (!this.isNull("assetnum")) {
                    where.append(" and assetnum = :assetnum");
                }
            }
            else if (!this.isNull("assetnum")) {
                where.append(" and assetnum = :assetnum and wonum is null");
            }
            if (where.toString().equals("")) {
                where.append(" and 1=2 ");
            }
            sqf = new SqlFormat(this, "itemnum=:itemnum and location=:fromstoreloc and storelocsiteid=:tositeid" + where.toString());
        }
        else {
            sqf = new SqlFormat(this, "requestnum = :1");
            sqf.setObject(1, "INVRESERVE", "REQUESTNUM", requestNum);
        }
        final String whereClause = sqf.format();
        final MboSetRemote invrSet = ((MboSet)this.getThisMboSet()).getSharedMboSet("INVRESERVE", whereClause);
        return invrSet;
    }
    
    void verifyChangesAreAllowed() throws MXException, RemoteException {
        final MboRemote workorder = this.getWO();
        if (workorder == null) {
            return;
        }
        if (!this.isNull("taskid")) {
            final MboSetRemote woChildren = workorder.getMboSet("CHILDREN");
            int y = 0;
            for (MboRemote woChild = woChildren.getMbo(y); woChild != null; woChild = woChildren.getMbo(y)) {
                if (woChild.getBoolean("ISTASK") && this.getString("taskid").equals(woChild.getString("TASKID")) && !woChild.getBoolean("woacceptscharges")) {
                    final Object[] param = { workorder.getString("wonum"), this.getString("taskid") };
                    throw new MXApplicationException("workorder", "TaskAcceptsChargesNo", param);
                }
                ++y;
            }
        }
        else if (!workorder.getBoolean("woacceptscharges")) {
            final Object[] param2 = { workorder.getString("wonum") };
            throw new MXApplicationException("workorder", "WOAcceptsChargesNo", param2);
        }
    }
    
    public void updateInvBalances(final MboRemote mbo, final double quantity, final String status) throws MXException, RemoteException {
        final HashMap<String, MboRemote> invBalMap = ((InvUseLineSet)this.getThisMboSet()).getInvBalMap();
        final String frombin = mbo.getString("frombin");
        final String tobin = mbo.getString("tobin");
        String key = null;
        InvBalances invBalMbo = null;
        final Inventory invMbo = (Inventory)this.getSharedInventory();
        key = this.getString("itemnum") + this.getString("itemsetid") + this.getString("fromstoreloc") + mbo.getString("frombin") + mbo.getString("fromlot") + this.getString("fromconditioncode");
        invBalMbo = (InvBalances)((InvUseLineSet)this.getThisMboSet()).getInvBalMap(key);
        if (invBalMbo == null) {
            invBalMbo = (InvBalances)this.getSharedInvBalance(frombin, mbo.getString("fromlot"));
            invBalMap.put(key, invBalMbo);
        }
        if (status.equalsIgnoreCase("CANCELLED") && this.getOwner() != null && this.getOwner().isBasedOn("INVUSE")) {
            if (((InvUse)this.getOwner()).isStaged()) {
                invBalMbo.setValue("stagedcurbal", invBalMbo.getDouble("stagedcurbal") - quantity, 2L);
            }
            else if (((InvUse)this.getOwner()).isShipped()) {
                invBalMbo.setValue("curbal", invBalMbo.getDouble("curbal") + quantity, 2L);
                return;
            }
        }
        else {
            invBalMbo.setValue("curbal", invBalMbo.getDouble("curbal") - quantity, 2L);
        }
        if (status.equalsIgnoreCase("SHIPPED")) {
            return;
        }
        invBalMbo = (InvBalances)this.getSharedInvBalance(tobin, mbo.getString("tolot"));
        if (invBalMbo == null) {
            String stagingBin = "null";
            if (!this.getString("stagingbin").equals("")) {
                stagingBin = this.getString("stagingbin");
            }
            key = this.getString("itemnum") + this.getString("itemsetid") + this.getString("fromstoreloc") + stagingBin + mbo.getString("tolot") + this.getString("fromconditioncode");
            invBalMbo = (InvBalances)((InvUseLineSet)this.getThisMboSet()).getInvBalMap(key);
            if (invBalMbo == null) {
                invBalMbo = (InvBalances)invMbo.getMboSet("INVBALANCES").add();
                invBalMbo.setValue("binnum", mbo.getString("tobin"), 11L);
                invBalMbo.setValue("lotnum", mbo.getString("tolot"), 11L);
                invBalMbo.setValue("conditioncode", this.getString("fromconditioncode"), 11L);
                invBalMbo.setValue("stagingbin", true, 2L);
                invBalMap.put(key, invBalMbo);
            }
        }
        if (status.equalsIgnoreCase("STAGED")) {
            invBalMbo.setValue("stagedcurbal", invBalMbo.getDouble("stagedcurbal") + quantity, 2L);
        }
        else if (status.equalsIgnoreCase("CANCELLED")) {
            invBalMbo.setValue("curbal", invBalMbo.getDouble("curbal") + quantity, 2L);
        }
    }
    
    public void updateStagedInvBalances(final String status) throws MXException, RemoteException {
        final MboSetRemote matRecTransSet = this.getMboSet("MATRECSTAGETRANSFER");
        if (!matRecTransSet.isEmpty()) {
            final MboRemote matRecTrans = matRecTransSet.getMbo(0);
            if (matRecTrans != null) {
                this.setValue("stagingbin", matRecTrans.getString("tobin"), 2L);
                this.setValue("staginglot", matRecTrans.getString("tolot"), 2L);
            }
        }
        final InvBalances invBalMbo = (InvBalances)this.getSharedInvBalance(this.getString("stagingbin"), this.getString("staginglot"));
        if (invBalMbo != null) {
            invBalMbo.setValue("stagedcurbal", invBalMbo.getDouble("stagedcurbal") - this.getDouble("quantity"), 2L);
        }
    }
    
    public void updateInvReservePendingQty() throws MXException, RemoteException {
        final InvReserveRemote invReserve = (InvReserveRemote)this.getSharedInvReserveSet().getMbo(0);
        if (invReserve == null) {
            return;
        }
        final SqlFormat sqf1 = new SqlFormat(this, "requestnum=:requestnum and siteid = :1 and invusenum in ( select invusenum from invuse where siteid=:1 and status in ( select value from synonymdomain where domainid = 'INVUSESTATUS' and maxvalue = 'ENTERED'))");
        double pendingQty = 0.0;
        sqf1.setObject(1, "INVRESERVE", "STORELOCSITEID", invReserve.getString("storelocsiteid"));
        final MboSetRemote invUseLineSet = this.getMboSet("$INVUSELINE" + this.getLong("invuselineid"), "INVUSELINE", sqf1.format());
        int i = 0;
        MboRemote invUseLine = null;
        if (!invUseLineSet.isEmpty()) {
            while ((invUseLine = invUseLineSet.getMbo(i)) != null) {
                if (!invUseLine.getString("invusenum").equalsIgnoreCase(this.getString("invusenum"))) {
                    pendingQty += invUseLine.getDouble("quantity");
                }
                ++i;
            }
        }
        for (i = 0; (invUseLine = this.getThisMboSet().getMbo(i)) != null; ++i) {
            if (!invUseLine.toBeDeleted() && invUseLine.getString("requestnum").equals(invReserve.getString("requestnum"))) {
                pendingQty += invUseLine.getDouble("quantity");
            }
        }
        invReserve.setValue("pendingqty", pendingQty, 2L);
        invUseLineSet.cleanup();
    }
    
    public void updateInvReserveStagedQty() throws MXException, RemoteException {
        if (!this.getString("requestnum").equals("")) {
            final InvReserveRemote invreserve = (InvReserveRemote)this.getSharedInvReserveSet().getMbo(0);
            if (invreserve == null) {
                return;
            }
            invreserve.setValue("stagedqty", invreserve.getDouble("stagedqty") + this.getDouble("quantity"), 2L);
            final MboRemote owner = this.getOwner();
            if (owner != null && owner.isBasedOn("INVUSE") && ((InvUse)owner).isEntered()) {
                invreserve.setValue("pendingqty", invreserve.getDouble("pendingqty") - this.getDouble("quantity"), 2L);
            }
        }
    }
    
    public void updateInvReserveActualQty() throws MXException, RemoteException {
        if (!this.getString("requestnum").equals("")) {
            final MboRemote invreserve = this.getSharedInvReserveSet().getMbo(0);
            if (invreserve == null) {
                return;
            }
            ((InvReserve)invreserve).incrActualQty(this.getDouble("quantity"));
            if (!this.getString("mrnum").equals("") && ((InvReserve)invreserve).getDouble("reservedqty") <= 0.0) {
                this.updateMR(invreserve);
            }
            final MboRemote owner = this.getOwner();
            if (owner != null && owner.isBasedOn("INVUSE") && ((InvUse)owner).isEntered()) {
                invreserve.setValue("pendingqty", invreserve.getDouble("pendingqty") - this.getDouble("quantity"), 2L);
            }
            else if (owner != null && owner.isBasedOn("INVUSE") && ((InvUse)owner).isStaged()) {
                invreserve.setValue("stagedqty", invreserve.getDouble("stagedqty") - this.getDouble("quantity"), 2L);
            }
            else if (owner != null && owner.isBasedOn("InvUse") && ((InvUse)owner).isShipped()) {
                invreserve.setValue("shippedqty", invreserve.getDouble("shippedqty") - this.getDouble("quantity"), 2L);
            }
        }
    }
    
    public void updateInvReserveShippedQty() throws MXException, RemoteException {
        if (!this.getString("requestnum").equals("")) {
            final MboRemote invreserve = this.getSharedInvReserveSet().getMbo(0);
            invreserve.setValue("shippedqty", invreserve.getDouble("shippedqty") + this.getDouble("quantity"), 2L);
            final MboRemote owner = this.getOwner();
            if (owner != null && owner.isBasedOn("INVUSE") && ((InvUse)owner).isEntered()) {
                invreserve.setValue("pendingqty", invreserve.getDouble("pendingqty") - this.getDouble("quantity"), 2L);
            }
            else if (owner != null && owner.isBasedOn("INVUSE") && ((InvUse)owner).isStaged()) {
                invreserve.setValue("stagedqty", invreserve.getDouble("stagedqty") - this.getDouble("quantity"), 2L);
            }
        }
    }
    
    public void updateInvReserveForCancel() throws MXException, RemoteException {
        if (!this.getString("requestnum").equals("")) {
            final MboRemote invreserve = this.getSharedInvReserveSet().getMbo(0);
            if (invreserve == null) {
                return;
            }
            final MboRemote owner = this.getOwner();
            if (owner != null && owner.isBasedOn("INVUSE") && ((InvUse)owner).isEntered()) {
                invreserve.setValue("pendingqty", invreserve.getDouble("pendingqty") - this.getDouble("quantity"), 2L);
            }
            else if (owner != null && owner.isBasedOn("INVUSE") && ((InvUse)owner).isStaged()) {
                invreserve.setValue("stagedqty", invreserve.getDouble("stagedqty") - this.getDouble("quantity"), 2L);
            }
            else if (owner != null && owner.isBasedOn("INVUSE") && ((InvUse)owner).isShipped()) {
                invreserve.setValue("shippedqty", invreserve.getDouble("shippedqty") - this.getDouble("quantity") - this.getDouble("returnedqty"), 2L);
            }
        }
    }
    
    @Override
    public void canDelete() throws MXException, RemoteException {
        super.canDelete();
        if (this.getOwner() != null && this.getOwner().isBasedOn("INVUSE") && !((InvUse)this.getOwner()).isEntered()) {
            throw new MXApplicationException("inventory", "cannotDeleteExistingRow");
        }
    }
    
    @Override
    public void delete(final long accessModifier) throws MXException, RemoteException {
        super.delete(accessModifier);
        final MboRemote owner = this.getOwner();
        this.getMboSet("INVUSELINESPLIT").deleteAll(2L);
        if (owner != null && owner.isBasedOn("InvUse") && owner.getOwner() == null && this.isRotating()) {
            final HashMap<Long, Double> rotQtyMap = ((InvUse)owner).getRotQtyMap();
            if (rotQtyMap != null && rotQtyMap.containsKey(this.getLong("invuselineid"))) {
                rotQtyMap.remove(this.getLong("invuselineid"));
            }
        }
        final MboRemote invreserve = this.getSharedInvReserveSet().getMbo(0);
        if (invreserve == null) {
            return;
        }
        final MboRemote invUseLine = this.getMboSet("$INVUSELINE" + this.getLong("invuselineid"), "INVUSELINE", "invuselineid=:invuselineid").getMbo(0);
        if (invUseLine != null && this.getOwner().getOwner() == null && !this.getString("requestnum").equals("")) {
            invreserve.setValue("pendingqty", invreserve.getDouble("pendingqty") - this.getDouble("quantity"), 2L);
        }
        if (this.isRotating() && owner != null && owner.isBasedOn("InvUse")) {
            ((InvUse)owner).removeUsedRotAssetNSMap(this.getString("invuselinenum"));
        }
    }
    
    @Override
    public void undelete() throws MXException, RemoteException {
        super.undelete();
        InvUseLineSplit invuselinesplit = null;
        for (int i = 0; (invuselinesplit = (InvUseLineSplit)this.getMboSet("INVUSELINESPLIT").getMbo(i)) != null; ++i) {
            invuselinesplit.undelete();
        }
        final ItemRemote item = (ItemRemote)this.getMboSet("ITEM").getMbo(0);
        if (item.isRotating()) {
            final MboRemote owner = this.getOwner();
            if (owner != null && owner.isBasedOn("InvUse") && this.getString("rotassetnum") != null) {
                final String keyNum = this.getString("invusenum") + this.getString("invuselinenum");
                ((InvUse)owner).checkRotAssetNumList(keyNum, this.getString("rotassetnum"), false);
                ((InvUse)owner).setUsedRotAssetSMap(keyNum, this.getString("rotassetnum"));
            }
            final MboRemote mbo = this.getOwner().getOwner();
            if (this.getOwner() != null && this.getOwner().isBasedOn("InvUse") && mbo == null) {
                final HashMap<Long, Double> rotQtyMap = ((InvUse)this.getOwner()).getRotQtyMap();
                if (rotQtyMap != null && !rotQtyMap.containsKey(this.getLong("invuselineid"))) {
                    ((InvUse)this.getOwner()).setRotQtyMap(this.getLong("invuselineid"), this.getDouble("quantity"));
                }
            }
        }
    }
    
    @Override
    public boolean checkReservationExist() throws MXException, RemoteException {
        final SignatureServiceRemote sr = (SignatureServiceRemote)MXServer.getMXServer().lookup("SIGNATURE");
        final String reserve = sr.getUserPref("INVUSE_RESERVATION", this.getUserInfo());
        if (reserve.equals("1") || ((InvUse)this.getOwner()).getBoolean("resvpref")) {
            final MboSetRemote invReserveSet = this.getMboSet("INVRESERVEFORUSELINE");
            if (!invReserveSet.isEmpty()) {
                this.getMboSet("RESERVATION").clear();
                ((ReservationSet)this.getMboSet("RESERVATION")).addReservationRecords(invReserveSet);
                return !this.getMboSet("RESERVATION").isEmpty();
            }
        }
        return false;
    }
    
    @Override
    public void checkReservationExistForInfo() throws MXException, RemoteException {
        final MboSetRemote invReserveSet = this.getMboSet("INVRESERVEFORUSELINE");
        if (!invReserveSet.isEmpty()) {
            this.getMboSet("RESERVATION").clear();
            ((ReservationSet)this.getMboSet("RESERVATION")).addReservationRecords(invReserveSet);
        }
    }
    
    @Override
    public boolean checkIssueExist() throws MXException, RemoteException {
        if (this.getBoolean("returnagainstissue")) {
            return false;
        }
        final SignatureServiceRemote sr = (SignatureServiceRemote)MXServer.getMXServer().lookup("SIGNATURE");
        final String rtn = sr.getUserPref("INVUSE_RETURN", this.getUserInfo());
        if (rtn.equals("1") || ((InvUse)this.getOwner()).getBoolean("returnpref")) {
            final MboSetRemote matUseTransSet = this.getMboSet("MATUSETRANSFORUSELINE");
            if (!matUseTransSet.isEmpty()) {
                ((IssuedItemForReturnSet)this.getMboSet("ISSUEDITEMFORRETURN")).clear();
                ((IssuedItemForReturnSet)this.getMboSet("ISSUEDITEMFORRETURN")).addIssueRecords(matUseTransSet, this);
                return !this.getMboSet("ISSUEDITEMFORRETURN").isEmpty();
            }
        }
        return false;
    }
    
    @Override
    public void checkIssueExistForInfo() throws MXException, RemoteException {
        if (this.getBoolean("returnagainstissue")) {
            return;
        }
        final MboSetRemote matUseTransSet = this.getMboSet("MATUSETRANSFORUSELINE");
        if (!matUseTransSet.isEmpty()) {
            ((IssuedItemForReturnSet)this.getMboSet("ISSUEDITEMFORRETURN")).clear();
            ((IssuedItemForReturnSet)this.getMboSet("ISSUEDITEMFORRETURN")).addIssueRecords(matUseTransSet, this);
        }
    }
    
    @Override
    public void updateInvUseLineForReservation(final MboRemote reservation) throws MXException, RemoteException {
        final MboRemote owner = this.getOwner();
        if (reservation == null || (owner != null && owner.isBasedOn("InvUse") && !((InvUse)owner).isEntered())) {
            return;
        }
        if (!reservation.getBoolean("keepcurqty")) {
            final String requestnum = reservation.getString("requestnum");
            final String siteid = reservation.getString("siteid");
            double qty = reservation.getDouble("reservedqty") - this.getPendingQty(requestnum, siteid) - reservation.getDouble("stagedqty") - reservation.getDouble("shippedqty");
            qty -= ((InvUseLineSet)this.getThisMboSet()).getQtyForReservationinSet(requestnum, this.getLong("invuselineid"));
            this.setValue("quantity", qty, 2L);
        }
        this.setValue("requestnum", reservation.getString("requestnum"), 2L);
        this.setValue("refwo", reservation.getString("wonum"), 2L);
        this.setValue("tositeid", reservation.getString("tositeid"), 2L);
        this.setValue("tostoreloc", reservation.getString("tostoreloc"), 2L);
        if (!this.getString("ponum").equals("")) {
            final MboRemote poline = this.getMboSet("POLINE").getMbo(0);
            if (poline != null) {
                this.setValue("inspectionrequired", poline.getString("inspectionrequired"), 2L);
            }
        }
        final String userShowAgainPref = "INVUSE_RESERVATION";
        final SignatureServiceRemote sr = (SignatureServiceRemote)MXServer.getMXServer().lookup("SIGNATURE");
        if (owner != null && owner.isBasedOn("InvUse")) {
            if (owner.getString("showagainpref").equalsIgnoreCase("1") || owner.getString("showagainpref").equalsIgnoreCase("Y")) {
                sr.setUserPref(userShowAgainPref, "0", this.getUserInfo());
            }
            else {
                sr.setUserPref(userShowAgainPref, "1", this.getUserInfo());
            }
        }
    }
    
/*
Punto 1 y 2: Anulaci�n de Recepci�n OC en USD y Devoluci�n de Recepci�n OC
    Los c�lculos de PPP en USD al momento de la recepci�n, devoluci�n y anulaci�n los realiza correctamente.
    Lo que MAXIMO no realiza correctamente, es el total de USD de la recepci�n/anulaci�n/devoluci�n, 
    ya que para calcularlo toma la tasa al momento de la aprobaci�n de la OC y deber�a tomar el del momento 
    de la transacci�n, como lo hace el c�lculo de PPP en USD.
    En una transferencia debe calcularse el linecost2 con el PPP en USD.

Punto 5:
    En la transacci�n de transferencia, en la tabla MATRECTRANS, se calcula mal el costo total USD de la 
    transferencia (linecost2).
*/

    
    @Override
    public void updateInvUseLineForReturn(final MboRemote issuedItemForReturn) throws MXException, RemoteException {
        final MboRemote owner = this.getOwner();
        if (issuedItemForReturn == null || (owner != null && owner.isBasedOn("InvUse") && !((InvUse)owner).isEntered())) {
            return;
        }
        this.setValue("issueid", issuedItemForReturn.getString("issueid"), 11L);
        this.setValue("returnagainstissue", true, 2L);
        if (!issuedItemForReturn.getBoolean("keepcurqty")) {
            final double qty = issuedItemForReturn.getDouble("quantity") - MXMath.abs(this.getInvUseLineQtyForReturn(this.getLong("issueid")));
            this.setValue("quantity", qty, 11L);
        }
        this.setValue("frombin", issuedItemForReturn.getString("binnum"), 2L);
        this.setValue("fromlot", issuedItemForReturn.getString("lotnum"), 2L);
        this.setValue("fromconditioncode", issuedItemForReturn.getString("conditioncode"), 2L);
        this.setValue("unitcost", issuedItemForReturn.getString("unitcost"), 2L);	///AMB<--<
        this.setValue("mrnum", issuedItemForReturn.getString("mrnum"), 2L);
        this.setValue("mrlinenum", issuedItemForReturn.getString("mrlinenum"), 2L);
        if (!issuedItemForReturn.getString("refwo").equals("")) {
            this.setValue("refwo", issuedItemForReturn.getString("refwo"), 2L);
        }
        if (!issuedItemForReturn.getString("assetnum").equals("")) {
            this.setValue("assetnum", issuedItemForReturn.getString("assetnum"), 2L);
        }
        if (!issuedItemForReturn.getString("location").equals("")) {
            this.setValue("location", issuedItemForReturn.getString("location"), 2L);
        }
        if (!issuedItemForReturn.getString("gldebitacct").equals("")) {
            this.setValue("gldebitacct", issuedItemForReturn.getString("gldebitacct"), 2L);
        }
        this.setValue("tositeid", issuedItemForReturn.getString("tositeid"), 2L);
        final String userShowAgainPref = "INVUSE_RETURN";
        final SignatureServiceRemote sr = (SignatureServiceRemote)MXServer.getMXServer().lookup("SIGNATURE");
        if (owner != null && owner.isBasedOn("InvUse")) {
            if (owner.getString("showagainpref").equalsIgnoreCase("1") || owner.getString("showagainpref").equalsIgnoreCase("Y")) {
                sr.setUserPref(userShowAgainPref, "0", this.getUserInfo());
            }
            else {
                sr.setUserPref(userShowAgainPref, "1", this.getUserInfo());
            }
        }
    }
    
    public void addRecordForStageTransfer(final MboSetRemote matrecMboSet, final ArrayList<InvUseLineSplitRemote> splitLineSplit) throws MXException, RemoteException {
        String costType = "";
        final Inventory inv = (Inventory)this.getMboSet("INVENTORY").getMbo(0);
        if (inv != null) {
            costType = inv.getCostType();
        }
        if (splitLineSplit == null || splitLineSplit.isEmpty()) {
            final MboSetRemote invuselinesplitset = this.getMboSet("INVUSELINESPLIT");
            if (invuselinesplitset.isEmpty()) {
                final MboRemote matrec = this.addMatRecTransRecordForStageTransfer(matrecMboSet, this);
                this.updateInvBalances(matrec, this.getDouble("quantity"), "STAGED");
            }
            else {
                int i = 0;
                double totUnitCost = 0.0;
                double totQty = 0.0;
                MboRemote invuselinesplit = null;
                boolean autocreated = true;
                while ((invuselinesplit = invuselinesplitset.getMbo(i)) != null) {
                    if (!invuselinesplit.toBeDeleted()) {
                        if (!costType.equals("LIFO") && !costType.equals("FIFO")) {
                            invuselinesplit.setValue("unitcost", ((InvUseLineSplit)invuselinesplit).getDefaultIssueCost(), 2L);
                        }
                        final MboRemote matrec2 = this.addMatRecTransRecordForStageTransfer(matrecMboSet, invuselinesplit);
                        this.updateInvBalances(matrec2, invuselinesplit.getDouble("quantity"), "STAGED");
                        if (costType.equalsIgnoreCase("ASSET")) {
                            totUnitCost += invuselinesplit.getDouble("unitcost");
                        }
                        totQty += invuselinesplit.getDouble("quantity");
                    }
                    ++i;
                }
                autocreated = invuselinesplitset.getMbo(--i).getBoolean("autocreated");
                if (totQty > 0.0 && !autocreated) {
                    if (i > 0 && costType.equals("ASSET")) {
                        this.setValue("displayunitcost", MXMath.divide(totUnitCost, i), 11L);
                        this.setValue("displaylinecost", MXMath.multiply(this.getDouble("displayunitcost"), totQty), 11L);
                    }
                    this.setValue("split", true, 2L);
                    this.setValue("quantity", totQty, 2L);
                }
            }
        }
        else {
            int j = 0;
            InvUseLineSplitRemote invUseLineSplit = null;
            final ItemRemote item = (ItemRemote)this.getMboSet("ITEM").getMbo(0);
            double totUnitCost2 = 0.0;
            double totQty2 = 0.0;
            while (j < splitLineSplit.size()) {
                invUseLineSplit = splitLineSplit.get(j);
                if (!invUseLineSplit.toBeDeleted()) {
                    if (!costType.equals("LIFO") && !costType.equals("FIFO")) {
                        invUseLineSplit.setValue("unitcost", ((InvUseLineSplit)invUseLineSplit).getDefaultIssueCost(), 2L);
                    }
                    final MboRemote matrec3 = this.addMatRecTransRecordForStageTransfer(matrecMboSet, invUseLineSplit);
                    this.updateInvBalances(matrec3, invUseLineSplit.getDouble("quantity"), "STAGED");
                    if (item != null && item.isRotating()) {
                        totUnitCost2 += invUseLineSplit.getDouble("unitcost");
                    }
                    totQty2 += invUseLineSplit.getDouble("quantity");
                }
                ++j;
            }
            if (totQty2 > 0.0) {
                if (j > 0 && costType.equalsIgnoreCase("ASSET")) {
                    this.setValue("displayunitcost", MXMath.divide(totUnitCost2, j), 11L);
                    this.setValue("displaylinecost", MXMath.multiply(this.getDouble("displayunitcost"), totQty2), 11L);
                }
                this.setValue("split", true, 2L);
                this.setValue("quantity", totQty2, 2L);
            }
        }
    }
    
    public MboRemote addMatRecTransRecordForStageTransfer(final MboSetRemote matrecMboSet, final MboRemote mbo) throws MXException, RemoteException {
        final MboRemote matrec = matrecMboSet.add();
        matrec.setValue("issuetype", this.getTranslator().toExternalDefaultValue("ISSUETYP", "STAGETRANSFER", this), 11L);
        matrec.setValue("conversion", this.getString("conversion"), 2L);
        matrec.setValue("fromsiteid", this.getString("siteid"), 2L);
        matrec.setValue("newsite", this.getString("siteid"), 2L);
        matrec.setValue("itemnum", this.getString("itemnum"), 3L);
        matrec.setValue("itemsetid", this.getString("itemsetid"), 2L);
        matrec.setValue("fromconditioncode", this.getString("fromconditioncode"), 3L);
        matrec.setValue("conditioncode", this.getString("fromconditioncode"), 3L);
        matrec.setValue("fromstoreloc", this.getString("fromstoreloc"), 2L);
        matrec.setValue("tolot", this.getString("fromlot"), 11L);
        matrec.setValue("frombin", mbo.getString("frombin"), 11L);
        matrec.setValue("tostoreloc", this.getString("fromstoreloc"), 2L);
        matrec.setValue("tobin", this.getString("stagingbin"), 11L);
        matrec.setValue("quantity", mbo.getDouble("quantity"), 3L);
        matrec.setValue("rotassetnum", mbo.getString("rotassetnum"), 3L);
        matrec.setValue("unitcost", mbo.getDouble("unitcost"), 3L);
        matrec.setValue("displayunitcost", mbo.getDouble("unitcost"), 2L);
        matrec.setValue("enteredastask", this.getBoolean("enteredastask"), 11L);
        matrec.setValue("refwo", this.getString("refwo"), 11L);
        matrec.setValue("assetnum", this.getString("assetnum"), 11L);
        matrec.setValue("location", this.getString("location"), 11L);
        matrec.setValue("remark", this.getString("remark"), 2L);
        matrec.setValue("issueto", this.getString("issueto"), 2L);
        matrec.setValue("actualdate", this.getDate("actualdate"), 2L);
        matrec.setValue("enterby", this.getString("enterby"), 2L);
        matrec.setValue("fromlot", mbo.getString("fromlot"), 11L);
        if (this.getTranslator().toInternalString("LINETYPE", this.getString("linetype")).equals("TOOL")) {
            matrec.setValueNull("glcreditacct", 11L);
            matrec.setValueNull("gldebitacct", 11L);
        }
        else {
            matrec.setValue("glcreditacct", this.getString("glcreditacct"), 2L);
            matrec.setValue("gldebitacct", this.getString("glcreditacct"), 2L);
        }
        final MboRemote inv = this.getMboSet("INVENTORY").getMbo(0);
        if (inv != null) {
            matrec.setValue("totalcurbal", ((Inventory)inv).getCurrentBalance(null, null), 2L);
            matrec.setValue("curbal", ((Inventory)inv).getCurrentBalance(mbo.getString("frombin"), mbo.getString("fromlot"), this.getString("fromconditioncode")), 2L);
        }
        matrec.setValue("receiptquantity", mbo.getDouble("quantity"), 3L);
        matrec.setValue("currencyunitcost", matrec.getDouble("unitcost") * matrec.getDouble("exchangerate"), 3L);
        matrec.setValue("actualcost", matrec.getDouble("unitcost") * matrec.getDouble("exchangerate"), 3L);
        matrec.setValue("description", this.getMboSet("ITEM").getMbo(0).getString("DESCRIPTION"), 2L);
        matrec.setValue("mrnum", this.getString("mrnum"), 3L);
        matrec.setValue("mrlinenum", this.getString("mrlinenum"), 3L);
        matrec.setValue("ponum", this.getString("ponum"), 11L);
        matrec.setValue("porevisionnum", this.getInt("porevisionnum"), 2L);
        matrec.setValue("polinenum", this.getString("polinenum"), 11L);
        matrec.setValue("invuselineid", this.getLong("invuselineid"), 2L);
        if (this.getOwner() != null) {
            matrec.setValue("invuseid", ((InvUse)this.getOwner()).getLong("invuseid"), 2L);
        }
        matrec.setValue("shelflife", this.getFloat("shelflife"), 11L);
        matrec.setValue("invuselinenum", this.getString("invuselinenum"), 2L);
        if (mbo.isBasedOn("INVUSELINESPLIT")) {
            matrec.setValue("invuselinesplitid", mbo.getLong("invuselinesplitid"), 2L);
        }
        return matrec;
    }
    
    public void addRecordForShipTransfer(final MboSetRemote matrecMboSet, final ArrayList<InvUseLineSplitRemote> splitLineSplit) throws MXException, RemoteException {
        final MboRemote owner = this.getOwner();
        String costtype = "";
        final Inventory inv = (Inventory)this.getMboSet("INVENTORY").getMbo(0);
        if (inv != null) {
            costtype = inv.getCostType();
        }
        if (splitLineSplit == null || splitLineSplit.isEmpty()) {
            final MboSetRemote invuselinesplitset = this.getMboSet("INVUSELINESPLIT");
            if (invuselinesplitset.isEmpty()) {
                final MboRemote matrec = this.addMatRecTransRecordForShipTransfer(matrecMboSet, this);
                if (owner != null && owner.isBasedOn("InvUse") && ((InvUse)owner).isEntered()) {
                    this.updateInvBalances(matrec, this.getDouble("quantity"), "SHIPPED");
                }
                this.updateAssetStatus(this.getString("rotassetnum"), "DECOMMISSIONED");
            }
            else {
                int i = 0;
                double totUnitCost = 0.0;
                double totQty = 0.0;
                MboRemote invuselinesplit = null;
                boolean autocreated = true;
                while ((invuselinesplit = invuselinesplitset.getMbo(i)) != null) {
                    if (!invuselinesplit.toBeDeleted()) {
                        if (owner != null && owner.isBasedOn("INVUSE") && ((InvUse)owner).isStaged()) {
                            ((InvUseLineSplit)invuselinesplit).setCheckNegBalanceFlag(false);
                        }
                        if (!costtype.equals("") && !costtype.equalsIgnoreCase("LIFO") && !costtype.equalsIgnoreCase("FIFO")) {
                            invuselinesplit.setValue("unitcost", ((InvUseLineSplit)invuselinesplit).getDefaultIssueCost(), 2L);
                        }
                        final MboRemote matrec2 = this.addMatRecTransRecordForShipTransfer(matrecMboSet, invuselinesplit);
                        if (owner != null && owner.isBasedOn("InvUse") && ((InvUse)owner).isEntered()) {
                            this.updateInvBalances(matrec2, invuselinesplit.getDouble("quantity"), "SHIPPED");
                        }
                        this.updateAssetStatus(this.getString("rotassetnum"), "DECOMMISSIONED");
                        if (costtype.equalsIgnoreCase("ASSET")) {
                            totUnitCost += invuselinesplit.getDouble("unitcost");
                        }
                        totQty += invuselinesplit.getDouble("quantity");
                    }
                    ++i;
                }
                autocreated = invuselinesplitset.getMbo(--i).getBoolean("autocreated");
                if (totQty > 0.0 && !autocreated) {
                    if (i > 0 && costtype.equalsIgnoreCase("ASSET")) {
                        this.setValue("displayunitcost", MXMath.divide(totUnitCost, i), 11L);
                        this.setValue("displaylinecost", MXMath.multiply(this.getDouble("displayunitcost"), totQty), 11L);
                    }
                    this.setValue("split", true, 2L);
                    this.setValue("quantity", totQty, 2L);
                }
            }
        }
        else {
            int j = 0;
            InvUseLineSplitRemote invUseLineSplit = null;
            double totUnitCost = 0.0;
            double totQty = 0.0;
            while (j < splitLineSplit.size()) {
                invUseLineSplit = splitLineSplit.get(j);
                if (owner != null && owner.isBasedOn("INVUSE") && ((InvUse)owner).isStaged()) {
                    ((InvUseLineSplit)invUseLineSplit).setCheckNegBalanceFlag(false);
                }
                if (!costtype.equals("") && !costtype.equalsIgnoreCase("LIFO") && !costtype.equalsIgnoreCase("FIFO")) {
                    invUseLineSplit.setValue("unitcost", ((InvUseLineSplit)invUseLineSplit).getDefaultIssueCost(), 2L);
                }
                if (!invUseLineSplit.toBeDeleted()) {
                    final MboRemote matrec3 = this.addMatRecTransRecordForShipTransfer(matrecMboSet, invUseLineSplit);
                    if (owner != null && owner.isBasedOn("InvUse") && ((InvUse)owner).isEntered()) {
                        this.updateInvBalances(matrec3, invUseLineSplit.getDouble("quantity"), "SHIPPED");
                    }
                    this.updateAssetStatus(this.getString("rotassetnum"), "DECOMMISSIONED");
                    if (costtype.equalsIgnoreCase("ASSET")) {
                        totUnitCost += invUseLineSplit.getDouble("unitcost");
                    }
                    totQty += invUseLineSplit.getDouble("quantity");
                }
                ++j;
            }
            if (totQty > 0.0) {
                if (j > 0 && costtype.equalsIgnoreCase("ASSET")) {
                    this.setValue("displayunitcost", MXMath.divide(totUnitCost, j), 11L);
                    this.setValue("displaylinecost", MXMath.multiply(this.getDouble("displayunitcost"), totQty), 11L);
                }
                this.setValue("split", true, 2L);
                this.setValue("quantity", totQty, 2L);
            }
        }
    }
    
    public MboRemote addMatRecTransRecordForShipTransfer(final MboSetRemote matrecMboSet, final MboRemote mbo) throws MXException, RemoteException {
        final MboRemote matrec = matrecMboSet.add();
        ((MatRecTransSet)matrecMboSet).setAddKitComponentsToStores();
        matrec.setValue("issuetype", this.getTranslator().toExternalDefaultValue("ISSUETYP", "SHIPTRANSFER", this), 11L);
        matrec.setValue("fromsiteid", this.getString("siteid"), 2L);
        matrec.setValue("positeid", this.getString("siteid"), 2L);
        matrec.setValue("newsite", this.getString("tositeid"), 2L);
        matrec.setValue("itemnum", this.getString("itemnum"), 2L);
        matrec.setValue("commodity", this.getString("COMMODITY"), 11L);
        matrec.setValue("commoditygroup", this.getString("COMMODITYGROUP"), 11L);
        matrec.setValue("itemsetid", this.getString("itemsetid"), 2L);
        matrec.setValue("fromconditioncode", this.getString("fromconditioncode"), 11L);
        matrec.setValue("conditioncode", this.getString("toconditioncode"), 2L);
        matrec.setValue("fromstoreloc", this.getString("fromstoreloc"), 10L);
        matrec.setValue("tolot", this.getString("tolot"), 11L);
        matrec.setValue("frombin", mbo.getString("frombin"), 11L);
        matrec.setValue("tostoreloc", this.getString("tostoreloc"), 10L);
        if (!matrec.getString("siteid").equals(matrec.getString("newsite"))) {
            matrec.setPropagateKeyFlag(false);
            matrec.setValue("SiteId", matrec.getString("newsite"), 2L);
            final SiteServiceRemote siteService = (SiteServiceRemote)MXServer.getMXServer().lookup("SITE");
            final String org = siteService.getOrgForSite(matrec.getString("newsite"), matrec.getUserInfo());
            matrec.setValue("OrgId", org, 2L);
            matrec.setPropagateKeyFlag(true);
        }
        matrec.setValue("tobin", this.getString("tobin"), 11L);
        matrec.setValue("quantity", mbo.getDouble("quantity"), 2L);
        matrec.setValue("rotassetnum", mbo.getString("rotassetnum"), 2L);
        matrec.setValue("receiptquantity", mbo.getDouble("quantity"), 2L);
        matrec.setValue("currencyunitcost", mbo.getDouble("unitcost"), 2L);
        matrec.setValue("unitcost", mbo.getDouble("unitcost"), 2L);
        matrec.setValue("displayunitcost", mbo.getDouble("unitcost"), 2L);
        matrec.setValue("actualcost", matrec.getDouble("unitcost"), 2L);
        matrec.setValue("enteredastask", this.getBoolean("enteredastask"), 11L);
        matrec.setValue("refwo", this.getString("refwo"), 11L);
        matrec.setValue("assetnum", this.getString("assetnum"), 2L);
        matrec.setValue("location", this.getString("location"), 2L);
        matrec.setValue("remark", this.getString("remark"), 2L);
        matrec.setValue("issueto", this.getString("issueto"), 2L);
        matrec.setValue("actualdate", this.getDate("actualdate"), 2L);
        matrec.setValue("enterby", this.getString("enterby"), 2L);
        matrec.setValue("fromlot", mbo.getString("fromlot"), 11L);
        matrec.setValue("conversion", this.getDouble("conversion"), 2L);
        if (this.getTranslator().toInternalString("LINETYPE", this.getString("linetype")).equals("TOOL")) {
            matrec.setValueNull("glcreditacct", 11L);
            matrec.setValueNull("gldebitacct", 11L);
        }
        else {
            matrec.setValue("glcreditacct", this.getString("glcreditacct"), 11L);
            final MboRemote owner = this.getOwner();
            if (owner != null && owner.isBasedOn("INVUSE")) {
                matrec.setValue("gldebitacct", ((InvUse)owner).getClearingAcct(), 11L);
            }
        }
        final MboRemote inv = this.getMboSet("INVENTORY").getMbo(0);
        if (inv != null) {
            matrec.setValue("consignment", inv.getBoolean("consignment"), 2L);
            matrec.setValue("consvendor", inv.getString("consvendor"), 2L);
            matrec.setValue("receivedunit", ((Inventory)inv).getString("issueunit"), 10L);
        }
        final MboRemote toinv = ((MatRecTrans)matrec).getSharedInventory(this.getString("fromstoreloc"), this.getString("siteid"));
        if (inv != null) {
            matrec.setValue("totalcurbal", ((Inventory)toinv).getCurrentBalance(null, null), 2L);
            matrec.setValue("curbal", ((Inventory)toinv).getCurrentBalance(this.getString("tobin"), this.getString("tolot"), this.getString("toconditioncode")), 2L);
            matrec.setValue("oldavgcost", ((Inventory)toinv).getDouble("avgcost"), 2L);
        }
        matrec.setValue("description", this.getMboSet("ITEM").getMbo(0).getString("DESCRIPTION"), 2L);
        matrec.setValue("mrnum", this.getString("mrnum"), 2L);
        matrec.setValue("mrlinenum", this.getString("mrlinenum"), 2L);
        matrec.setValue("ponum", this.getString("ponum"), 2L);
        matrec.setValue("polinenum", this.getString("polinenum"), 11L);
        matrec.setValue("invuselineid", this.getLong("invuselineid"), 2L);
        matrec.setValue("shelflife", this.getFloat("shelflife"), 11L);
        final HashMap<Long, MboRemote> shipmentLineMap = ((InvUse)this.getOwner()).getShipmentLineMap();
        final Long splitidKey = mbo.getLong("invuselinesplitid");
        final MboRemote shipmentLine = shipmentLineMap.get(splitidKey);
        if (shipmentLine != null) {
            matrec.setValue("invuselinenum", shipmentLine.getString("invuselinenum"), 2L);
            matrec.setValue("invuselinesplitid", shipmentLine.getLong("invuselinesplitid"), 2L);
            if (shipmentLine.getOwner() != null) {
                matrec.setValue("shipmentnum", ((Shipment)shipmentLine.getOwner()).getString("shipmentnum"), 2L);
            }
            matrec.setValue("shipmentlinenum", shipmentLine.getString("shipmentlinenum"), 11L);
        }
        if (mbo.getDouble("physcnt") > 0.0) {
            final InvBalances invBal = (InvBalances)this.getSharedInvBalance(mbo.getString("frombin"), mbo.getString("fromlot"));
            if (invBal.getDate("physcntdate").after(mbo.getDate("physcntdate"))) {
                ((InvUseLineSet)this.getThisMboSet()).getPhyscntdateList().add(Integer.toString(this.getInt("invuselinenum")));
            }
            else {
                invBal.adjustPhysicalCount(mbo.getDouble("physcnt"), mbo.getDate("physcntdate"));
            }
        }
        if (this.getOwner() != null) {
            matrec.setValue("invuseid", ((InvUse)this.getOwner()).getLong("invuseid"), 2L);
            matrec.setValue("exchangerate", ((InvUse)this.getOwner()).getDouble("exchangerate"), 2L);
        }
        return matrec;
    }
    
    public void addTransferRecordForComplete(final MboSetRemote matrecMboSet, final ArrayList<InvUseLineSplitRemote> splitLineSplit) throws MXException, RemoteException {
        String costtype = "";
        final MboRemote owner = this.getOwner();
        final Inventory inv = (Inventory)this.getMboSet("INVENTORY").getMbo(0);
        if (inv != null) {
            costtype = inv.getCostType();
        }
        if (splitLineSplit == null || splitLineSplit.isEmpty()) {
            final MboSetRemote invuselinesplitset = this.getMboSet("INVUSELINESPLIT");
            if (invuselinesplitset.isEmpty()) {
                this.addMatRecTransRecordForComplete(matrecMboSet, this);
            }
            else {
                int i = 0;
                MboRemote invuselinesplit = null;
                while ((invuselinesplit = invuselinesplitset.getMbo(i)) != null) {
                    if (owner != null && owner.isBasedOn("INVUSE") && ((InvUse)owner).isStaged()) {
                        ((InvUseLineSplit)invuselinesplit).setCheckNegBalanceFlag(false);
                    }
                    if (!costtype.equals("") && !costtype.equalsIgnoreCase("LIFO") && !costtype.equalsIgnoreCase("FIFO")) {
                        invuselinesplit.setValue("unitcost", ((InvUseLineSplit)invuselinesplit).getDefaultIssueCost(), 2L);
                    }
                    this.addMatRecTransRecordForComplete(matrecMboSet, invuselinesplit);
                    ++i;
                }
            }
        }
        else {
            int j = 0;
            InvUseLineSplitRemote invUseLineSplit = null;
            double totUnitCost = 0.0;
            double totQty = 0.0;
            while (j < splitLineSplit.size()) {
                invUseLineSplit = splitLineSplit.get(j);
                if (owner != null && owner.isBasedOn("INVUSE") && ((InvUse)owner).isStaged()) {
                    ((InvUseLineSplit)invUseLineSplit).setCheckNegBalanceFlag(false);
                }
                if (!costtype.equals("") && !costtype.equalsIgnoreCase("LIFO") && !costtype.equalsIgnoreCase("FIFO")) {
                    invUseLineSplit.setValue("unitcost", ((InvUseLineSplit)invUseLineSplit).getDefaultIssueCost(), 2L);
                }
                if (!invUseLineSplit.toBeDeleted()) {
                    this.addMatRecTransRecordForComplete(matrecMboSet, invUseLineSplit);
                    if (costtype.equalsIgnoreCase("ASSET")) {
                        totUnitCost += invUseLineSplit.getDouble("unitcost");
                    }
                    totQty += invUseLineSplit.getDouble("quantity");
                }
                ++j;
            }
            if (totQty > 0.0) {
                if (j > 0 && costtype.equalsIgnoreCase("ASSET")) {
                    this.setValue("displayunitcost", MXMath.divide(totUnitCost, j), 11L);
                    this.setValue("displaylinecost", MXMath.multiply(this.getDouble("displayunitcost"), totQty), 11L);
                }
                this.setValue("split", true, 2L);
                this.setValue("quantity", totQty, 2L);
            }
        }
    }
    
    public MboRemote addMatRecTransRecordForComplete(final MboSetRemote matrecMboSet, final MboRemote mbo) throws MXException, RemoteException {
        final MboRemote matrec = matrecMboSet.add(2L);
        ((MatRecTransSet)matrecMboSet).setAddKitComponentsToStores();
        final MboRemote owner = this.getOwner();
        if (owner != null && owner.isBasedOn("InvUse") && ((InvUse)owner).isStaged()) {
            final MboSetRemote matRecTransSet = this.getMboSet("MATRECSTAGETRANSFER");
            if (!matRecTransSet.isEmpty()) {
                final MboRemote matRecTrans = matRecTransSet.getMbo(0);
                if (matRecTrans != null) {
                    this.setValue("stagingbin", matRecTrans.getString("tobin"), 2L);
                    this.setValue("staginglot", matRecTrans.getString("tolot"), 2L);
                }
            }
            ((MatRecTrans)matrec).setCheckNegBalance(false);
            ((MatRecTrans)matrec).setFromInvBalUpdated();
            if (this.updatedToInvbal) {
                ((MatRecTrans)matrec).setToInvBalUpdated();
            }
        }
        ((MatRecTrans)matrec).setInvReserveUpdatedFlag(true);
        matrec.setValue("fromsiteid", this.getString("siteid"), 11L);
        matrec.setValue("newsite", this.getString("tositeid"), 11L);
        matrec.setValue("issuetype", this.getString("usetype"), 11L);
        matrec.setValue("itemsetid", this.getString("itemsetid"), 2L);
        matrec.setValue("itemnum", this.getString("itemnum"), 11L);
        matrec.setValue("commodity", this.getString("commodity"), 11L);
        matrec.setValue("commoditygroup", this.getString("commoditygroup"), 11L);
        final MboRemote item = this.getMboSet("ITEM").getMbo(0);
        if (item != null) {
            matrec.setValue("outside", item.getBoolean("outside"), 2L);
        }
        matrec.setValue("fromconditioncode", this.getString("fromconditioncode"), 11L);
        matrec.setValue("conditioncode", this.getString("toconditioncode"), 11L);
        matrec.setValue("fromstoreloc", this.getString("fromstoreloc"), 10L);
        matrec.setValue("tostoreloc", this.getString("tostoreloc"), 10L);
        if (!matrec.getString("siteid").equals(matrec.getString("newsite"))) {
            matrec.setPropagateKeyFlag(false);
            matrec.setValue("SiteId", matrec.getString("newsite"), 2L);
            final SiteServiceRemote siteService = (SiteServiceRemote)MXServer.getMXServer().lookup("SITE");
            final String org = siteService.getOrgForSite(matrec.getString("newsite"), matrec.getUserInfo());
            matrec.setValue("OrgId", org, 2L);
            matrec.setPropagateKeyFlag(true);
        }
        matrec.setValue("conversion", this.getDouble("conversion"), 2L);
        matrec.setValue("frombin", mbo.getString("frombin"), 11L);
        matrec.setValue("tobin", this.getString("tobin"), 11L);
        matrec.setValue("tolot", this.getString("tolot"), 11L);
        matrec.setValue("rotassetnum", mbo.getString("rotassetnum"), 3L);
        matrec.setValue("enteredastask", this.getBoolean("enteredastask"), 11L);
        matrec.setValue("refwo", this.getString("refwo"), 2L);
        matrec.setValue("assetnum", this.getString("assetnum"), 2L);
        matrec.setValue("location", this.getString("location"), 11L);
        matrec.setValue("remark", this.getString("remark"), 2L);
        matrec.setValue("issueto", this.getString("issueto"), 2L);
        matrec.setValue("actualdate", this.getDate("actualdate"), 2L);
        matrec.setValue("enterby", this.getString("enterby"), 2L);
        matrec.setValue("mrnum", this.getString("mrnum"), 2L);
        matrec.setValue("mrlinenum", this.getString("mrlinenum"), 2L);
        matrec.setValue("ponum", this.getString("ponum"), 2L);
        matrec.setValue("porevisionnum", this.getInt("porevisionnum"), 2L);
        matrec.setValue("polinenum", this.getString("polinenum"), 11L);
        matrec.setValue("fromlot", mbo.getString("fromlot"), 11L);
        if (!mbo.getString("newassetnum").equals("")) {
            final MboRemote asset = matrec.getMboSet("ROTASSET").getMbo(0);
            if (asset != null) {
                asset.setValue("newassetnum", mbo.getString("newassetnum"), 2L);
            }
        }
        final MboRemote inv = ((MatRecTrans)matrec).getSharedInventory(this.getString("fromstoreloc"), this.getString("siteid"));
        if (inv != null) {
            matrec.setValue("consignment", inv.getBoolean("consignment"), 2L);
            matrec.setValue("consvendor", inv.getString("consvendor"), 2L);
            matrec.setValue("receivedunit", ((Inventory)inv).getString("issueunit"), 10L);
        }
        final MboRemote toinv = ((MatRecTrans)matrec).getSharedInventory(this.getString("fromstoreloc"), this.getString("siteid"));
        if (inv != null) {
            matrec.setValue("totalcurbal", ((Inventory)toinv).getCurrentBalance(null, null), 2L);
            matrec.setValue("curbal", ((Inventory)toinv).getCurrentBalance(this.getString("tobin"), this.getString("tolot"), this.getString("toconditioncode")), 2L);
            matrec.setValue("oldavgcost", ((Inventory)toinv).getDouble("avgcost"), 2L);
        }
        if (this.getTranslator().toInternalString("linetype", this.getString("linetype")).equals("TOOL")) {
            matrec.setValueNull("glcreditacct", 11L);
            matrec.setValueNull("gldebitacct", 11L);
        }
        else {
            matrec.setValue("glcreditacct", this.getString("glcreditacct"), 11L);
            matrec.setValue("gldebitacct", this.getString("gldebitacct"), 11L);
        }
        matrec.setValue("invuselineid", this.getLong("invuselineid"), 2L);
        if (this.getOwner() != null) {
            matrec.setValue("invuseid", ((InvUse)this.getOwner()).getLong("invuseid"), 2L);
        }
        matrec.setValue("receiptquantity", mbo.getDouble("quantity"), 2L);
        if (this.getDouble("conversion") > 0.0) {
            matrec.setValue("displayunitcost", mbo.getDouble("unitcost") / this.getDouble("conversion"), 2L);
        }
        else {
            matrec.setValue("displayunitcost", mbo.getDouble("unitcost"), 2L);
        }
        matrec.setValue("currencyunitcost", matrec.getDouble("unitcost") / this.getDouble("conversion") * matrec.getDouble("exchangerate"), 2L);
        matrec.setValue("actualcost", matrec.getDouble("unitcost") / this.getDouble("conversion") * matrec.getDouble("exchangerate"), 2L);
        if (mbo.isBasedOn("INVUSELINE") && !mbo.isNull("newphyscnt")) {
            final MboRemote invBal = ((Inventory)inv).getInvBalanceRecord(mbo.getString("frombin"), mbo.getString("fromlot"), mbo.getString("fromconditioncode"));
            if (invBal.getDate("physcntdate").after(mbo.getDate("physcntdate"))) {
                ((InvUseLineSet)this.getThisMboSet()).getPhyscntdateList().add(Integer.toString(this.getInt("invuselinenum")));
            }
            else {
                ((InvBalances)invBal).adjustPhysicalCount(mbo.getDouble("physcnt"), mbo.getDate("physcntdate"));
            }
        }
        else if (mbo.isBasedOn("INVUSELINESPLIT") && mbo.getDouble("physcnt") > 0.0) {
            final MboRemote invBal = ((Inventory)inv).getInvBalanceRecord(mbo.getString("frombin"), mbo.getString("fromlot"), mbo.getString("fromconditioncode"));
            if (invBal.getDate("physcntdate").after(mbo.getDate("physcntdate"))) {
                ((InvUseLineSet)this.getThisMboSet()).getPhyscntdateList().add(Integer.toString(this.getInt("invuselinenum")));
            }
            else {
                ((InvBalances)invBal).adjustPhysicalCount(mbo.getDouble("physcnt"), mbo.getDate("physcntdate"));
            }
        }
        matrec.setValue("shelflife", this.getFloat("shelflife"), 11L);
        return matrec;
    }
    
    public void addIssueReturnRecordForComplete(final MboSetRemote matrecMboSet, final ArrayList<InvUseLineSplitRemote> splitLineSplit) throws MXException, RemoteException {
        String costType = "";
        final MboRemote owner = this.getOwner();
        final Inventory inv = (Inventory)this.getMboSet("INVENTORY").getMbo(0);
        if (inv != null) {
            costType = inv.getCostType();
        }
        if (splitLineSplit == null || splitLineSplit.isEmpty()) {
            final MboSetRemote invuselinesplitset = this.getMboSet("INVUSELINESPLIT");
            if (invuselinesplitset.isEmpty()) {
                this.addMatUseTransRecordForComplete(matrecMboSet, this);
            }
            else {
                int i = 0;
                MboRemote invuselinesplit = null;
                while ((invuselinesplit = invuselinesplitset.getMbo(i)) != null) {
                    if (owner != null && owner.isBasedOn("INVUSE") && ((InvUse)owner).isStaged()) {
                        ((InvUseLineSplit)invuselinesplit).setCheckNegBalanceFlag(false);
                    }
                    if (!costType.equals("") && !costType.equalsIgnoreCase("LIFO") && !costType.equalsIgnoreCase("FIFO")) {
                        invuselinesplit.setValue("unitcost", this.getDouble("unitcost"), 2L);
                    }
                    this.addMatUseTransRecordForComplete(matrecMboSet, invuselinesplit);
                    ++i;
                }
            }
        }
        else {
            int j = 0;
            InvUseLineSplitRemote invUseLineSplit = null;
            double totUnitCost = 0.0;
            double totQty = 0.0;
            while (j < splitLineSplit.size()) {
                invUseLineSplit = splitLineSplit.get(j);
                if (owner != null && owner.isBasedOn("INVUSE") && ((InvUse)owner).isStaged()) {
                    ((InvUseLineSplit)invUseLineSplit).setCheckNegBalanceFlag(false);
                }
                if (!costType.equals("") && !costType.equalsIgnoreCase("LIFO") && !costType.equalsIgnoreCase("FIFO")) {
                    invUseLineSplit.setValue("unitcost", this.getDouble("unitcost"), 2L);
                }
                if (!invUseLineSplit.toBeDeleted()) {
                    this.addMatUseTransRecordForComplete(matrecMboSet, invUseLineSplit);
                    if (costType.equalsIgnoreCase("ASSET")) {
                        totUnitCost += invUseLineSplit.getDouble("unitcost");
                    }
                    totQty += invUseLineSplit.getDouble("quantity");
                }
                ++j;
            }
            if (totQty > 0.0) {
                if (j > 0 && costType.equalsIgnoreCase("ASSET")) {
                    this.setValue("displayunitcost", MXMath.divide(totUnitCost, j), 11L);
                    this.setValue("displaylinecost", MXMath.multiply(this.getDouble("displayunitcost"), totQty), 11L);
                }
                this.setValue("split", true, 2L);
                this.setValue("quantity", totQty, 2L);
            }
        }
    }
    
    public MboRemote addMatUseTransRecordForComplete(final MboSetRemote matuseMboSet, final MboRemote mbo) throws MXException, RemoteException {
        final MboRemote matuse = matuseMboSet.add(2L);
        final MboRemote owner = this.getOwner();
        if (owner != null && owner.isBasedOn("InvUse") && ((InvUse)owner).isStaged()) {
            final MboSetRemote matRecTransSet = this.getMboSet("MATRECSTAGETRANSFER");
            if (!matRecTransSet.isEmpty()) {
                final MboRemote matRecTrans = matRecTransSet.getMbo(0);
                if (matRecTrans != null) {
                    this.setValue("stagingbin", matRecTrans.getString("tobin"), 2L);
                    this.setValue("staginglot", matRecTrans.getString("tolot"), 2L);
                }
            }
            ((MatUseTrans)matuse).setCheckNegBalanceFlag(false);
            ((MatUseTrans)matuse).setSharedInvBalancesUpdatedFlag(true);
        }
        ((MatUseTrans)matuse).setInvReserveUpdatedFlag(true);
        matuse.setValue("tositeid", this.getString("tositeid"), 2L);
        matuse.setValue("issuetype", this.getString("usetype"), 11L);
        matuse.setValue("itemsetid", this.getString("itemsetid"), 2L);
        matuse.setValue("itemnum", this.getString("itemnum"), 3L);
        matuse.setValue("commodity", this.getString("COMMODITY"), 11L);
        matuse.setValue("commoditygroup", this.getString("COMMODITYGROUP"), 11L);
        final MboRemote item = this.getMboSet("ITEM").getMbo(0);
        if (item != null) {
            matuse.setValue("itemtype", item.getString("itemtype"), 11L);
        }
        matuse.setValue("conditioncode", this.getString("fromconditioncode"), 2L);
        matuse.setValue("storeloc", this.getString("fromstoreloc"), 10L);
        matuse.setValue("binnum", mbo.getString("frombin"), 11L);
        matuse.setValue("issueid", this.getString("issueid"), 2L);
        matuse.setValue("lotnum", mbo.getString("fromlot"), 11L);
        if (this.isReturn() && !this.getString("issueid").equals("")) {
            final SqlFormat sqf = new SqlFormat(this.getOwner(), "matusetransid=:1 and siteid=:siteid");
            sqf.setObject(1, "INVUSELINE", "ISSUEID", this.getString("issueid"));
            final String whereClause = sqf.format();
            final MatUseTrans matUseMbo = (MatUseTrans)((MboSet)this.getThisMboSet()).getSharedMboSet("MATUSETRANS", whereClause).getMbo(0);
            this.remainQty = matUseMbo.getTotalQtyForReturn();
            ((MatUseTrans)matuse).setIssueForThisReturn(matUseMbo);
            ((MatUseTrans)matuse).setTotalQtyForThisReturn(this.remainQty);
        }
        if (this.isIssue()) {
            matuse.setValue("quantity", -mbo.getDouble("quantity"), 2L);
        }
        else {
            matuse.setValue("quantity", this.getDouble("quantity"), 2L);
        }
        matuse.setValue("unitcost", mbo.getDouble("unitcost"), 2L);
        matuse.setValue("enteredastask", this.getBoolean("enteredastask"), 11L);
        matuse.setValue("refwo", this.getString("refwo"), 11L);
        matuse.setValue("assetnum", this.getString("assetnum"), 11L);
        matuse.setValue("location", this.getString("location"), 11L);
        if (this.isRotating()) {
            matuse.setValue("rotassetnum", mbo.getString("rotassetnum"), 11L);
        }
        matuse.setValue("memo", this.getString("remark"), 11L);
        matuse.setValue("issueto", this.getString("issueto"), 11L);
        matuse.setValue("actualdate", this.getDate("actualdate"), 2L);
        matuse.setValue("enterby", this.getString("enterby"), 11L);
        matuse.setValue("mrnum", this.getString("mrnum"), 11L);
        matuse.setValue("mrlinenum", this.getString("mrlinenum"), 11L);
        matuse.setValue("ponum", this.getString("ponum"), 11L);
        matuse.setValue("porevisionnum", this.getInt("porevisionnum"), 11L);
        matuse.setValue("polinenum", this.getString("polinenum"), 11L);
        if (this.getTranslator().toInternalString("linetype", this.getString("linetype")).equals("TOOL")) {
            matuse.setValueNull("glcreditacct", 11L);
            matuse.setValueNull("gldebitacct", 11L);
        }
        else {
            matuse.setValue("glcreditacct", this.getString("glcreditacct"), 11L);
            matuse.setValue("gldebitacct", this.getString("gldebitacct"), 11L);
        }
        final MboRemote inv = this.getMboSet("INVENTORY").getMbo(0);
        if (inv != null) {
            matuse.setValue("curbal", ((Inventory)inv).getCurrentBalance(mbo.getString("frombin"), mbo.getString("fromlot"), this.getString("fromconditioncode")), 2L);
        }
        if (!this.isRotating()) {
            if (mbo.isBasedOn("INVUSELINESPLIT") && mbo.getDouble("physcnt") > 0.0) {
                matuse.setValue("physcnt", mbo.getDouble("physcnt"), 2L);
                final InvBalances invBal = (InvBalances)this.getSharedInvBalance(mbo.getString("frombin"), mbo.getString("fromlot"));
                if (invBal.getDate("physcntdate").after(mbo.getDate("physcntdate"))) {
                    ((InvUseLineSet)this.getThisMboSet()).getPhyscntdateList().add(Integer.toString(this.getInt("invuselinenum")));
                }
                else {
                    invBal.adjustPhysicalCount(mbo.getDouble("physcnt"), mbo.getDate("physcntdate"));
                }
            }
            else if (!mbo.isNull("newphyscnt")) {
                matuse.setValue("physcnt", mbo.getDouble("physcnt"), 2L);
                final InvBalances invBal = (InvBalances)this.getSharedInvBalance(mbo.getString("frombin"), mbo.getString("fromlot"));
                if (invBal.getDate("physcntdate").after(mbo.getDate("physcntdate"))) {
                    ((InvUseLineSet)this.getThisMboSet()).getPhyscntdateList().add(Integer.toString(this.getInt("invuselinenum")));
                }
                else {
                    invBal.adjustPhysicalCount(mbo.getDouble("physcnt"), mbo.getDate("physcntdate"));
                }
            }
        }
        matuse.setValue("invuselineid", this.getLong("invuselineid"), 2L);
        if (this.getOwner() != null) {
            matuse.setValue("invuseid", ((InvUse)this.getOwner()).getLong("invuseid"), 11L);
        }
        if (this.isIssue() && !mbo.getString("newassetnum").equals("")) {
            final MboRemote asset = matuse.getMboSet("ROTASSET").getMbo(0);
            if (asset != null) {
                asset.setValue("newassetnum", mbo.getString("newassetnum"), 11L);
            }
        }
        return matuse;
    }
    
    public MboRemote addMatRecTransRecordForCancelStageTransfer() throws MXException, RemoteException {
        MboSetRemote matRecTransSet = null;
        matRecTransSet = this.getMboSet("MATRECSTAGETRANSFER");
        MboRemote matrec = null;
        final MboSetRemote newMatRecMboSet = this.getMboSet("$emptyMatUseTrans", "MATRECTRANS", "1=2");
        for (int j = 0; (matrec = matRecTransSet.getMbo(j)) != null; ++j) {
            final long matrecid = matrec.getLong("matrectransid");
            matrec = matrec.copy(newMatRecMboSet, 2L);
            final String binnum = matrec.getString("frombin");
            matrec.setValue("frombin", matrec.getString("tobin"), 2L);
            matrec.setValue("tobin", binnum, 2L);
            matrec.setValue("receiptref", matrecid, 11L);
            final MboRemote inv = this.getMboSet("INVENTORY").getMbo(0);
            if (inv != null) {
                matrec.setValue("totalcurbal", ((Inventory)inv).getCurrentBalance(null, null), 2L);
                matrec.setValue("curbal", ((Inventory)inv).getCurrentBalance(this.getString("tobin"), this.getString("fromlot"), this.getString("fromconditioncode")), 2L);
            }
            matrec.setValue("currencyunitcost", MXMath.multiply(matrec.getDouble("unitcost"), matrec.getDouble("exchangerate")), 2L);
            matrec.setValue("invuselineid", this.getLong("invuselineid"), 2L);
            matrec.setValue("transdate", MXServer.getMXServer().getDate(), 2L);
            if (this.getOwner() != null) {
                matrec.setValue("invuseid", ((InvUse)this.getOwner()).getLong("invuseid"), 2L);
            }
            double qty = this.getDouble("quantity");
            final MboRemote invUseLineSplit = matrec.getMboSet("INVUSELINESPLIT").getMbo(0);
            if (invUseLineSplit != null) {
                qty = invUseLineSplit.getDouble("quantity");
            }
            this.updateInvBalances(matrec, qty, "CANCELLED");
            String costtype = "";
            if (inv != null) {
                costtype = ((Inventory)inv).getCostType();
            }
            if (costtype.equalsIgnoreCase("LIFO") || costtype.equalsIgnoreCase("FIFO")) {
                this.updateLifoFifoForCancelled(invUseLineSplit);
            }
        }
        return matrec;
    }
    
    public MboRemote addMatRecTransRecordForCancelShipTransfer() throws MXException, RemoteException {
        MboSetRemote matRecTransSet = null;
        matRecTransSet = this.getMboSet("MATRECSHIPTRANSFER");
        MboRemote matrec = null;
        final MboSetRemote newMatRecMboSet = this.getMboSet("$emptyMatRecTrans", "MATRECTRANS", "1=2");
        for (int j = 0; (matrec = matRecTransSet.getMbo(j)) != null; ++j) {
            final long matrecid = matrec.getLong("matrectransid");
            matrec = matrec.copy(newMatRecMboSet, 2L);
            matrec.setValue("issuetype", this.getTranslator().toExternalDefaultValue("ISSUETYP", "SHIPCANCEL", this), 11L);
            final String creditacct = matrec.getString("glcreditacct");
            matrec.setValue("glcreditacct", matrec.getString("gldebitacct"), 2L);
            matrec.setValue("gldebitacct", creditacct, 2L);
            matrec.setValue("receiptref", matrecid, 11L);
            final MboRemote inv = this.getMboSet("INVENTORY").getMbo(0);
            if (inv != null) {
                matrec.setValue("totalcurbal", ((Inventory)inv).getCurrentBalance(null, null), 2L);
                matrec.setValue("curbal", ((Inventory)inv).getCurrentBalance(this.getString("tobin"), this.getString("fromlot"), this.getString("fromconditioncode")), 2L);
            }
            matrec.setValue("currencyunitcost", MXMath.multiply(matrec.getDouble("unitcost"), matrec.getDouble("exchangerate")), 2L);
            matrec.setValue("invuselineid", this.getLong("invuselineid"), 2L);
            if (this.getOwner() != null) {
                matrec.setValue("invuseid", ((InvUse)this.getOwner()).getLong("invuseid"), 2L);
            }
            matrec.setValue("transdate", MXServer.getMXServer().getDate(), 2L);
            if (this.getDouble("returnedqty") == 0.0) {
                double qty = this.getDouble("quantity");
                final MboRemote invUseLineSplit = matrec.getMboSet("INVUSELINESPLIT").getMbo(0);
                if (invUseLineSplit != null) {
                    qty = invUseLineSplit.getDouble("quantity");
                }
                this.updateInvBalances(matrec, qty, "CANCELLED");
                String costtype = "";
                if (inv != null) {
                    costtype = ((Inventory)inv).getCostType();
                }
                if (costtype.equalsIgnoreCase("LIFO") || costtype.equalsIgnoreCase("FIFO")) {
                    this.updateLifoFifoForCancelled(invUseLineSplit);
                }
            }
            this.updateAssetStatus(this.getString("rotassetnum"), "NOT READY");
        }
        return matrec;
    }
    
    @Override
    public MboRemote getPO() throws MXException, RemoteException {
        if (this.getString("ponum").equals("")) {
            return null;
        }
        final SqlFormat sqf = new SqlFormat(this, "ponum = :ponum and storelocsiteid = :siteid");
        final PORemote po = (PORemote)((MboSet)this.getThisMboSet()).getSharedMboSet("PO", sqf.format()).getMbo(0);
        return po;
    }
    
    @Override
    public MboRemote getPOLine() throws MXException, RemoteException {
        final SqlFormat sqf = new SqlFormat(this, "ponum = :ponum and polinenum = :polinenum and siteid= :positeid");
        final POLineRemote poline = (POLineRemote)((MboSet)this.getThisMboSet()).getSharedMboSet("POLINE", sqf.format()).getMbo(0);
        return poline;
    }
    
    @Override
    public double getTotalCurBalance() throws MXException, RemoteException {
        final MboRemote inv = this.getMboSet("INVENTORY").getMbo(0);
        if (inv != null) {
            return ((Inventory)inv).getCurrentBalance(null, null);
        }
        return 0.0;
    }
    
    public double getInvUseLineQtyForReturn(final long matusetransid) throws MXException, RemoteException {
        InvUseLine invUseLine = null;
        double qty = 0.0;
        for (int i = 0; (invUseLine = (InvUseLine)this.getThisMboSet().getMbo(i)) != null; ++i) {
            invUseLine = (InvUseLine)this.getThisMboSet().getMbo(i);
            if (invUseLine != null && !invUseLine.toBeDeleted() && invUseLine.isReturn() && invUseLine.getLong("issueid") == matusetransid && invUseLine.getString("siteid").equals(this.getString("siteid")) && invUseLine.getLong("invuselineid") != this.getLong("invuselineid")) {
                qty += invUseLine.getDouble("quantity");
            }
        }
        final SqlFormat sqf = new SqlFormat(this, "siteid=:siteid and issueid=:1");
        sqf.setLong(1, matusetransid);
        final MboSetRemote invUseLineSet = ((MboSet)this.getThisMboSet()).getSharedMboSet("INVUSELINE", sqf.format());
        if (invUseLineSet == null || invUseLineSet.isEmpty()) {
            return qty;
        }
        for (int i = 0; (invUseLine = (InvUseLine)invUseLineSet.getMbo(i)) != null; ++i) {
            final MboRemote owner = invUseLine.getMboSet("INVUSE").getMbo(0);
            if (owner != null && owner.isBasedOn("InvUse") && !((InvUse)owner).isCompleted() && !invUseLine.getString("invusenum").equals(owner.getString("invusenum"))) {
                qty += invUseLine.getDouble("quantity");
            }
        }
        return qty;
    }
    
    public double getQtyForReturn() throws MXException, RemoteException {
        if (this.remainQty != -1.11) {
            return this.remainQty;
        }
        final SqlFormat sqf = new SqlFormat(this, "siteid=:siteid and matusetransid=:1");
        sqf.setLong(1, this.getLong("issueid"));
        final MboSetRemote matUseTransSet = this.getMboSet("$MATUSETRANS" + this.getString("issueid"), "MATUSETRANS", sqf.format());
        if (matUseTransSet == null || matUseTransSet.isEmpty()) {
            return 0.0;
        }
        return MXMath.abs(matUseTransSet.getMbo(0).getDouble("quantity")) - matUseTransSet.getMbo(0).getDouble("qtyreturned") - this.getInvUseLineQtyForReturn(this.getLong("issueid"));
    }
    
    public void updateUnitCost() throws MXException, RemoteException {
        final double cost = this.getDefaultIssueCost();
        if (this.getDouble("unitcost") != cost) {
            this.setValue("unitcost", cost, 2L);
        }
    }
    
    @Override
    public boolean validateQty() throws MXException, RemoteException {
        if (this.getLong("issueid") > 0L) {
            final double remainingQty = this.getQtyForReturn();
            final String dummy = "";
            if (this.getDouble("quantity") > remainingQty) {
                final Object[] params = { dummy + (this.getDouble("quantity") - remainingQty) };
                ((InvUseLineSet)this.getThisMboSet()).addWarning(new MXApplicationException("inventory", "ReturnQtyExceeded", params));
                return false;
            }
        }
        return true;
    }
    
    protected void setConversionFactor() throws MXException, RemoteException {
        String fromMeasureUnit = "";
        String toMeasureUnit = "";
        if (this.isNull("itemnum") || this.isNull("tostoreloc")) {
            return;
        }
        final MboSetRemote itemSet = this.getMboSet("ITEM");
        if (!itemSet.isEmpty()) {
            final ItemRemote item = (ItemRemote)itemSet.getMbo(0);
            if (item.isRotating() || item.isKit()) {
                this.setValue("conversion", 1, 2L);
                this.setFieldFlag("conversion", 7L, true);
                return;
            }
            this.setFieldFlag("conversion", 7L, false);
        }
        if (this.isTransfer() && !this.isNull("ponum") && !this.isNull("receivedunit")) {
            fromMeasureUnit = this.getString("receivedunit");
        }
        if (fromMeasureUnit == "" && !this.isNull("fromstoreloc")) {
            final MboRemote mbor = this.getMboSet("INVENTORY").getMbo(0);
            if (mbor != null) {
                fromMeasureUnit = mbor.getString("ISSUEUNIT");
                if (this.isTransfer()) {
                    this.setValue("receivedunit", fromMeasureUnit, 11L);
                }
            }
        }
        final MboRemote toInventory = this.getMboSet("TOINVENTORY").getMbo(0);
        if (toInventory == null) {
            if (this.isNull("conversion")) {
                this.setValue("conversion", 1, 11L);
            }
            return;
        }
        toMeasureUnit = toInventory.getString("ISSUEUNIT");
        if (fromMeasureUnit == "" || toMeasureUnit == "") {
            return;
        }
        final InventoryServiceRemote invService = (InventoryServiceRemote)MXServer.getMXServer().lookup("INVENTORY");
        double conversion = 0.0;
        String conversionDisplay = "";
        try {
            conversion = invService.getConversionFactor(this.getUserInfo(), fromMeasureUnit, toMeasureUnit, this.getString("itemsetid"), this.getString("itemnum"));
            if (conversion > 0.0) {
                conversionDisplay = Double.toString(conversion);
                this.setValue("conversion", conversion, 2L);
            }
        }
        catch (MXApplicationException mxe) {
            if (conversion > 0.0 && mxe.getErrorKey().equalsIgnoreCase("conversionIsZero")) {
                final Object[] params = { conversionDisplay };
                throw new MXApplicationException("inventory", "conversionPrecisionLow", params);
            }
            if (!mxe.getErrorKey().equalsIgnoreCase("conversionDoesNotExist")) {
                throw mxe;
            }
            this.conversionException = mxe;
            this.setValueNull("conversion", 2L);
        }
    }
    
    public boolean needsSplitting() throws MXException, RemoteException {
        final MboRemote owner = this.getOwner();
        if (owner != null && owner.isBasedOn("InvUse")) {
            ((InvUse)owner).setEvaluateSplitFlag(1);
        }
        if (this.isIssue() || this.isTransfer()) {
            final MboRemote inventory = this.getSharedInventory();
            if (inventory == null) {
                return false;
            }
            final MboRemote invBal = this.getSharedInvBalance();
            if (invBal == null) {
                return true;
            }
            final ItemRemote item = (ItemRemote)this.getMboSet("ITEM").getMbo(0);
            if (item != null && item.isRotating()) {
                if (this.getDouble("quantity") > 1.0 || this.getString("rotassetnum").equals("")) {
                    if (owner != null && owner.isBasedOn("InvUse")) {
                        ((InvUse)owner).setEvaluateSplitFlag(2);
                    }
                    return true;
                }
                return false;
            }
            else {
                double qty = 0.0;
                final Long keyid = invBal.getLong("invbalancesid");
                final HashMap<Long, Double> invBalQtyNSMap = ((InvUse)owner).getInvBalQtyNSMap();
                double remainingQty = 0.0;
                if (invBalQtyNSMap.containsKey(keyid)) {
                    qty = invBalQtyNSMap.get(keyid);
                    qty -= this.getDouble("quantity");
                    if (qty < 0.0) {
                        if (owner != null && owner.isBasedOn("InvUse")) {
                            ((InvUse)owner).setEvaluateSplitFlag(2);
                        }
                        return true;
                    }
                    invBalQtyNSMap.put(keyid, qty);
                }
                else {
                    if (this.getDouble("quantity") > invBal.getDouble("curbal")) {
                        if (owner != null && owner.isBasedOn("InvUse")) {
                            ((InvUse)owner).setEvaluateSplitFlag(2);
                        }
                        return true;
                    }
                    remainingQty = invBal.getDouble("curbal") - this.getDouble("quantity");
                    invBalQtyNSMap.put(keyid, remainingQty);
                }
            }
        }
        return false;
    }
    
    public String getDefaultLotNum() throws MXException, RemoteException {
        final SqlFormat sqf = new SqlFormat(this, "siteid = :1 and itemnum = :2 and location = :3 and itemsetid = :4 and ( useby is null or useby > :5 ) and exists (select invbalances.lotnum from invbalances WHERE invbalances.itemnum=invlot.itemnum and invbalances.location=invlot.location and invbalances.itemsetid = invlot.itemsetid and invbalances.lotnum=invlot.lotnum and invbalances.siteid=invlot.siteid and invbalances.curbal>0)");
        sqf.setObject(1, "INVLOT", "siteid", this.getString("siteid"));
        sqf.setObject(2, "INVLOT", "itemnum", this.getString("itemnum"));
        sqf.setObject(3, "INVLOT", "location", this.getString("fromstoreloc"));
        sqf.setObject(4, "INVLOT", "itemsetid", this.getString("itemsetid"));
        sqf.setTimestamp(5, MXServer.getMXServer().getDate());
        final MboSetRemote invLots = this.getMboSet("$INVLOT" + this.getString("invusenum") + this.getString("siteid"), "INVLOT", sqf.format());
        invLots.setOrderBy("useby");
        invLots.reset();
        String rtn = null;
        if (!invLots.isEmpty()) {
            rtn = invLots.getMbo(0).getString("lotnum");
        }
        invLots.close();
        return rtn;
    }
    
    public void canGoNegative(final UserInfo userInfo, final double toBeIssued, final double curbal, final double totalAvailable, final MboRemote sourceMbo) throws MXException, RemoteException {
        if (toBeIssued <= curbal && toBeIssued <= totalAvailable) {
            return;
        }
        final String negCurbal = this.getMboServer().getMaxVar().getString("NEGATIVECURBAL", sourceMbo.getString("orgid"));
        final String negAvailable = this.getMboServer().getMaxVar().getString("NEGATIVEAVAIL", sourceMbo.getString("orgid"));
        if (negCurbal.equals("ALLOW") && negAvailable.equals("ALLOW")) {
            return;
        }
        if (toBeIssued > curbal) {
            if (negCurbal.equals("DISALLOW")) {
                final Object[] params = { this.getString("invuselinenum") };
                throw new MXApplicationException("inventory", "negativeBalisNotAllowedForLine", params);
            }
            if (negAvailable.equals("DISALLOW")) {
                final Object[] params = { this.getString("invuselinenum") };
                throw new MXApplicationException("inventory", "negativeAvailisNotAllowedForLine", params);
            }
        }
        if (toBeIssued > totalAvailable && negAvailable.equals("DISALLOW")) {
            throw new MXApplicationException("inventory", "negativeAvailisNotAllowed");
        }
    }
    
    public void canGoNegative(final UserInfo userInfo, final double toBeIssued, final double totalAvailable, final MboRemote sourceMbo) throws MXException, RemoteException {
        final String negAvailable = this.getMboServer().getMaxVar().getString("NEGATIVEAVAIL", sourceMbo.getString("orgid"));
        if (toBeIssued > totalAvailable && negAvailable.equals("DISALLOW")) {
            final Object[] params = { this.getString("invuselinenum") };
            throw new MXApplicationException("inventory", "negativeAvailisNotAllowedForLine", params);
        }
    }
    
    @Override
    public void modify() throws MXException, RemoteException {
        if (this.getOwner() != null && this.getOwner().isBasedOn("InvUse") && this.getOwner().getOwner() != null && !this.getOwner().getOwner().isBasedOn("InvReserve")) {
            ((InvUse)this.getOwner()).modify();
        }
    }
    
    public void checkItemStatus() throws MXException, RemoteException {
        final Inventory inventory = (Inventory)this.getMboSet("INVENTORY").getMbo(0);
        final String status = this.getTranslator().toInternalString("ITEMSTATUS", inventory.getString("status"));
        if (status.equals("PLANNING") || status.equals("PENDING") || status.equals("OBSOLETE")) {
            final Object[] params = { this.getString("itemnum"), inventory.getString("status"), this.getString("invuselinenum") };
            throw new MXApplicationException("inventory", "invalidItemStatus", params);
        }
    }
    
    @Override
    public void setReservationUserPref() throws MXException, RemoteException {
        final MboRemote owner = this.getOwner();
        if (owner != null && owner.isBasedOn("InvUse")) {
            owner.setValue("showagainpref", !owner.getBoolean("resvpref"), 2L);
        }
    }
    
    @Override
    public void setReturnUserPref() throws MXException, RemoteException {
        final MboRemote owner = this.getOwner();
        if (owner != null && owner.isBasedOn("InvUse")) {
            owner.setValue("showagainpref", !owner.getBoolean("returnpref"), 2L);
        }
    }
    
    @Override
    public void setUserPref(final MboRemote mbo) throws MXException, RemoteException {
        final MboRemote owner = this.getOwner();
        if (owner != null && owner.isBasedOn("InvUse")) {
            owner.setValue("showagainpref", mbo.getBoolean("showagainpref"), 2L);
        }
    }
    
    public double getPendingQty(final String requestnum, final String siteid) throws MXException, RemoteException {
        if (requestnum.equals("")) {
            return 0.0;
        }
        final SqlFormat sqf1 = new SqlFormat(this, "requestnum=:1 and siteid= :2 and invusenum in ( select invusenum from invuse where siteid=:2 and status in ( select value from synonymdomain where domainid = 'INVUSESTATUS' and maxvalue = 'ENTERED'))");
        sqf1.setObject(1, "INVRESERVE", "REQUESTNUM", requestnum);
        sqf1.setObject(2, "INVRESERVE", "STORELOCSITEID", siteid);
        double pendingQty = 0.0;
        final MboSetRemote invUseLineSet = this.getMboSet("$INVUSELINE" + this.getString("invusenum"), "INVUSELINE", sqf1.format());
        int i = 0;
        MboRemote invUseLine = null;
        if (!invUseLineSet.isEmpty()) {
            while ((invUseLine = invUseLineSet.getMbo(i)) != null) {
                if (!invUseLine.getString("invusenum").equalsIgnoreCase(this.getString("invusenum"))) {
                    pendingQty += invUseLine.getDouble("quantity");
                }
                ++i;
            }
        }
        return pendingQty;
    }
    
    @Override
    public MboSetRemote smartFindByObjectName(final String sourceObj, final String targetAttrName, final String value, final boolean exact) throws MXException, RemoteException {
        if (sourceObj.equalsIgnoreCase("PO") && targetAttrName.equalsIgnoreCase("PONUM")) {
            final SqlFormat sqf = new SqlFormat(this, "ponum=:ponum and siteid=:positeid and status in (select value from synonymdomain where maxvalue in ('APPR','WAPPR','INPRG','CLOSE'))");
            final MboSetRemote returnedSet = this.getMboSet("$poset" + this.getString("ponum"), "PO", sqf.format());
            return returnedSet;
        }
        return super.smartFindByObjectName(sourceObj, targetAttrName, value, exact);
    }
    
    public boolean checkRotatingAssetExistInToSite(final String rotassetnum, final MboRemote mbo) throws MXException, RemoteException {
        if (rotassetnum.equals("")) {
            return false;
        }
        final String siteId = this.getString("tositeid");
        final SqlFormat sqf = new SqlFormat(this, "assetnum=:1 and siteid=:siteid");
        sqf.setObject(1, "ASSET", "ASSETNUM", rotassetnum);
        final MboSetRemote assetSet = this.getMboSet("$rotasset" + rotassetnum, "ASSET", sqf.format());
        final AssetRemote asset = (AssetRemote)assetSet.getMbo(0);
        if (asset != null && !siteId.equals(asset.getString("siteid"))) {
            asset.setValue("newsite", siteId, 11L);
            if (!this.isNull("ponum")) {
                asset.validateMoveAcrossOrg(siteId);
            }
            final AssetSetRemote movedAssetSet = (AssetSetRemote)asset.getMboSet("MOVEDASSET");
            if (movedAssetSet.isEmpty()) {
                asset.checkForChildrenAssetSite(siteId);
                final AssetSetRemote assetSiteSet = (AssetSetRemote)asset.getMboSet("NEWASSETSITE");
                if (!assetSiteSet.isEmpty()) {
                    return true;
                }
            }
            else {
                final AssetRemote movedAsset = (Asset)movedAssetSet.getMbo(0);
                mbo.setValue("newassetnum", movedAsset.getString("assetnum"), 11L);
            }
        }
        return false;
    }
    
    public void updateAssetStatus(final String rotassetnum, final String status) throws MXException, RemoteException {
        if (!this.getString("siteid").equalsIgnoreCase(this.getString("tositeid"))) {
            final MboSetRemote assetSet = this.getMboSet("$FROMASSETBYROTASSETNUM" + this.getString("rotassetnum"), "ASSET", "assetnum=:rotassetnum and siteid=:siteid");
            if (!assetSet.isEmpty()) {
                final AssetRemote asset = (AssetRemote)assetSet.getMbo(0);
                final String internalStatus = this.getTranslator().toInternalString("LOCASSETSTATUS", asset.getString("status"));
                if (status.equalsIgnoreCase("DECOMMISSIONED")) {
                    if (!internalStatus.equals("DECOMMISSIONED")) {
                        final String newStatus = this.getTranslator().toExternalDefaultValue("LOCASSETSTATUS", "DECOMMISSIONED", asset);
                        asset.changeStatus(newStatus, true, true, true, true);
                    }
                }
                else if (status.equalsIgnoreCase("NOT READY") && !internalStatus.equals("NOT READY")) {
                    final String newStatus = this.getTranslator().toExternalDefaultValue("LOCASSETSTATUS", "NOT READY", asset);
                    asset.changeStatus(newStatus, true, true, true, true);
                }
            }
        }
    }
    
    @Override
    public void updateReceiptsComplete() throws MXException, RemoteException {
        double orderqty = this.getDouble("quantity");
        if (orderqty == 0.0) {
            orderqty = 1.0;
        }
        double receivedQty = 0.0;
        double returnedQty = 0.0;
        receivedQty = this.getDouble("receivedqty");
        returnedQty = MXMath.multiply(MXMath.abs(this.getDouble("returnedqty")), this.getDouble("conversion"));
        if (orderqty > 0.0 && MXMath.add(receivedQty, returnedQty) >= orderqty) {
            this.setValue("receiptscomplete", true, 3L);
        }
        else if (orderqty < 0.0 && MXMath.subtract(receivedQty, returnedQty) <= orderqty) {
            this.setValue("receiptscomplete", true, 3L);
        }
        else {
            this.setValue("receiptscomplete", false, 3L);
        }
    }
    
    @Override
    public void updateReceivedQty(final double receivedQty) throws MXException, RemoteException {
        final double alreadyReceivedQty = this.isNull("receivedqty") ? 0.0 : this.getDouble("receivedqty");
        this.setValue("receivedqty", alreadyReceivedQty + receivedQty, 11L);
    }
    
    @Override
    public void updateReturnedQty(final double returnedQty) throws MXException, RemoteException {
        final double alreadyReturnedQty = this.isNull("returnedqty") ? 0.0 : this.getDouble("returnedqty");
        this.setValue("returnedqty", alreadyReturnedQty + returnedQty, 11L);
    }
    
    @Override
    public boolean isInspectionRequired() throws MXException, RemoteException {
        return this.getBoolean("inspectionrequired");
    }
    
    @Override
    public void initFieldFlagsOnMbo(final String attrName) throws MXException {
        try {
            if (!this.toBeAdded()) {
                if (attrName.equalsIgnoreCase("rotassetnum")) {
                    final MboRemote owner = this.getOwner();
                    if (owner != null && owner.isBasedOn("InvUse") && ((InvUse)owner).isEntered() && !this.getString("rotassetnum").equalsIgnoreCase("")) {
                        final String keyNum = this.getString("invusenum") + this.getString("invuselinenum");
                        ((InvUse)owner).setUsedRotAssetNSMap(keyNum, this.getString("rotassetnum"));
                        if (!this.getString("newassetnum").equalsIgnoreCase("")) {
                            ((InvUse)owner).setUsedRotAssetNSMap(keyNum, this.getString("rotassetnum"));
                        }
                    }
                }
                if (attrName.equalsIgnoreCase("newassetnum") && !this.getString("newassetnum").equals("")) {
                    this.setFieldFlag("newassetnum", 7L, false);
                }
                if ((attrName.equalsIgnoreCase("gldebitacct") || attrName.equalsIgnoreCase("glcreditacct")) && this.isTool() && !this.isTransfer()) {
                    this.setFieldFlag("gldebitacct", 7L, true);
                    this.setFieldFlag("glcreditacct", 7L, true);
                    if (this.isIssue()) {
                        this.setFieldFlag("issueto", 128L, true);
                    }
                }
                if (attrName.equalsIgnoreCase("fromassetnum") || attrName.equalsIgnoreCase("rotassetnum") || attrName.equalsIgnoreCase("newphyscnt") || attrName.equalsIgnoreCase("newphyscntdate")) {
                    final ItemRemote item = (ItemRemote)this.getMboSet("ITEM").getMbo(0);
                    if (!item.isRotating()) {
                        this.setFieldFlag("fromassetnum", 7L, true);
                        this.setFieldFlag("rotassetnum", 7L, true);
                    }
                    else {
                        if (this.getDouble("quantity") > 1.0) {
                            this.setFieldFlag("fromassetnum", 7L, true);
                            this.setFieldFlag("rotassetnum", 7L, true);
                        }
                        this.setFieldFlag("newphyscnt", 7L, true);
                        this.setFieldFlag("newphyscntdate", 7L, true);
                    }
                }
                if (attrName.equalsIgnoreCase("fromconditioncode") || attrName.equalsIgnoreCase("toconditioncode")) {
                    final ItemRemote item = (ItemRemote)this.getMboSet("ITEM").getMbo(0);
                    if (item != null && !item.isConditionEnabled()) {
                        this.setFieldFlag("fromconditioncode", 7L, true);
                        this.setFieldFlag("toconditioncode", 7L, true);
                    }
                }
                if (attrName.equalsIgnoreCase("fromlot") || attrName.equalsIgnoreCase("tolot")) {
                    final ItemRemote item = (ItemRemote)this.getMboSet("ITEM").getMbo(0);
                    if (item != null && !item.isLotted()) {
                        this.setFieldFlag("fromlot", 7L, true);
                        this.setFieldFlag("tolot", 7L, true);
                    }
                }
            }
        }
        catch (RemoteException e) {
            e.printStackTrace();
        }
    }
    
    public void setDisplayUnitCost() throws MXException, RemoteException {
        int i = 0;
        double unitCost = 0.0;
        InvUseLineSplit invUseLineSplit = null;
        double totqty = 0.0;
        final Inventory inv = (Inventory)this.getMboSet("INVENTORY").getMbo(0);
        if (inv != null && inv.getCostType() != null && (inv.getCostType().equalsIgnoreCase("ASSET") || inv.getCostType().equalsIgnoreCase("LIFO") || inv.getCostType().equalsIgnoreCase("FIFO"))) {
            if (this.isReturn() && !this.isNull("issueid")) {
                invUseLineSplit = (InvUseLineSplit)this.getMboSet("INVUSELINESPLIT").getMbo(0);
                if (invUseLineSplit != null) {
                    this.setValue("displayunitcost", invUseLineSplit.getDouble("unitcost"), 11L);
                }
            }
            else {
                for (InvUseLineSplitSet invUseLineSplitSet = (InvUseLineSplitSet)this.getMboSet("INVUSELINESPLIT"); (invUseLineSplit = (InvUseLineSplit)invUseLineSplitSet.getMbo(i)) != null; ++i) {
                    unitCost += MXMath.multiply(invUseLineSplit.getDouble("unitcost"), invUseLineSplit.getDouble("quantity"));
                    totqty += invUseLineSplit.getDouble("quantity");
                }
                if (totqty > 0.0) {
                    this.setValue("displayunitcost", MXMath.divide(unitCost, totqty), 11L);
                }
                this.setValue("displaylinecost", MXMath.multiply(this.getDouble("displayunitCost"), this.getDouble("quantity")), 11L);
            }
        }
        else {
            this.setValue("displayunitcost", this.getDouble("unitcost"), 11L);
            this.setValue("displaylinecost", this.getDouble("lineCost"), 11L);
        }
    }
    
    public void updateLifoFifoTable(final MboRemote invUseLineSplit) throws MXException, RemoteException {
        MboRemote invlifofifocost = null;
        final Inventory inv = (Inventory)this.getSharedInventory();
        double qty = this.getDouble("quantity");
        final String conditionCode = this.getString("fromconditionCode");
        final MboSetRemote invlifofifocostset = inv.getInvLifoFifoCostRecordSetSorted(conditionCode);
        if (invlifofifocostset.isEmpty()) {
            throw new MXApplicationException("inventory", "missingQuantity");
        }
        for (int i = 0; (invlifofifocost = invlifofifocostset.getMbo(i)) != null && qty != 0.0; ++i) {
            if (invlifofifocost.toBeDeleted() || invlifofifocost.getDouble("quantity") != 0.0) {
                if (invlifofifocost.getDouble("quantity") > qty) {
                    invUseLineSplit.setValue("unitcost", invlifofifocost.getDouble("unitcost"), 2L);
                    qty = MXMath.subtract(invlifofifocost.getDouble("quantity"), qty);
                    invlifofifocost.setValue("quantity", qty, 2L);
                }
                else {
                    invUseLineSplit.setValue("unitcost", invlifofifocost.getDouble("unitcost"), 2L);
                    invlifofifocost.setValue("quantity", 0, 2L);
                    qty = MXMath.subtract(qty, invlifofifocost.getDouble("quantity"));
                }
            }
        }
    }
    
    public void updateLifoFifoForCancelled(final MboRemote useLine) throws MXException, RemoteException {
        final Inventory inv = (Inventory)this.getSharedInventory();
        final InvLifoFifoCost invLifoFifoCost = (InvLifoFifoCost)inv.addInvLifoFifoCostRecord(this.getString("fromconditionCode"));
        invLifoFifoCost.setValue("quantity", useLine.getDouble("quantity"), 2L);
        invLifoFifoCost.setValue("unitcost", useLine.getDouble("unitcost"), 2L);
        invLifoFifoCost.setValue("refobject", this.getName(), 2L);
        invLifoFifoCost.setValue("refobjectid", this.getLong("invuselineid"), 2L);
    }
    
    public void addTransactionRecordsLIFOFIFO(final MboSetRemote transMboSet, final ArrayList<InvUseLineSplitRemote> splitLineSplit, final String status) throws MXException, RemoteException {
        final Inventory inv = (Inventory)this.getMboSet("INVENTORY").getMbo(0);
        final String conditionCode = this.getString("fromconditionCode");
        final MboRemote owner = this.getOwner();
        MboSetRemote invlifofifocostset = null;
        if (owner != null && owner.isBasedOn("InvUse")) {
            if (((InvUse)owner).invLifoFifoSetMap.containsKey(inv.getLong("inventoryid"))) {
                invlifofifocostset = ((InvUse)owner).invLifoFifoSetMap.get(inv.getLong("inventoryid"));
            }
            else {
                invlifofifocostset = inv.getInvLifoFifoCostRecordSetSorted(conditionCode);
                ((InvUse)owner).invLifoFifoSetMap.put(inv.getLong("inventoryid"), invlifofifocostset);
            }
        }
        if (splitLineSplit == null || splitLineSplit.isEmpty()) {
            final MboSetRemote invuselinesplitset = this.getMboSet("INVUSELINESPLIT");
            int i = 0;
            double totQty = 0.0;
            double totUnitCost = 0.0;
            MboRemote invuselinesplit = null;
            boolean autocreated = true;
            for (int count = invuselinesplitset.count(); count > 0; --count) {
                invuselinesplit = invuselinesplitset.getMbo(i);
                if (!invuselinesplit.toBeDeleted()) {
                    totQty += invuselinesplit.getDouble("quantity");
                    final double lifoFifoUnitCost = this.updateInvLifoFifoCostSet(transMboSet, invuselinesplit, invlifofifocostset, status);
                    totUnitCost += lifoFifoUnitCost;
                }
                ++i;
            }
            autocreated = invuselinesplitset.getMbo(--i).getBoolean("autocreated");
            if (totQty > 0.0 && !autocreated) {
                this.setValue("split", true, 2L);
                this.setValue("quantity", totQty, 2L);
            }
            if (this.getDouble("quantity") > 0.0) {
                this.setValue("displayunitcost", MXMath.divide(totUnitCost, totQty), 2L);
            }
        }
        else {
            int j = 0;
            InvUseLineSplitRemote invUseLineSplit = null;
            double totUnitCost2 = 0.0;
            double totQty2 = 0.0;
            while (j < splitLineSplit.size()) {
                invUseLineSplit = splitLineSplit.get(j);
                if (!invUseLineSplit.toBeDeleted()) {
                    totQty2 += invUseLineSplit.getDouble("quantity");
                    final double lifoFifoUnitCost2 = this.updateInvLifoFifoCostSet(transMboSet, invUseLineSplit, invlifofifocostset, status);
                    totUnitCost2 += lifoFifoUnitCost2;
                }
                ++j;
            }
            if (totQty2 > 0.0) {
                this.setValue("displayunitcost", MXMath.divide(totUnitCost2, totQty2), 2L);
                this.setValue("split", true, 2L);
                this.setValue("quantity", totQty2, 2L);
            }
        }
    }
    
    public double updateInvLifoFifoCostSet(final MboSetRemote transMboSet, MboRemote invUseLineSplit, final MboSetRemote invlifofifocostset, final String status) throws MXException, RemoteException {
        if (invUseLineSplit == null) {
            return 0.0;
        }
        MboRemote invlifofifocost = null;
        double qty = invUseLineSplit.getDouble("quantity");
        int i = 0;
        double lifoFifoUnitCost = 0.0;
        while ((invlifofifocost = invlifofifocostset.getMbo(i)) != null) {
            if (invlifofifocost.getDouble("quantity") == 0.0) {
                ++i;
            }
            else {
                if (invlifofifocost.getDouble("quantity") == qty) {
                    invUseLineSplit.setValue("quantity", qty, 2L);
                    invUseLineSplit.setValue("unitcost", invlifofifocost.getDouble("unitcost"), 2L);
                    invlifofifocost.setValue("quantity", 0, 11L);
                    break;
                }
                if (invlifofifocost.getDouble("quantity") > qty) {
                    invUseLineSplit.setValue("quantity", qty, 2L);
                    invUseLineSplit.setValue("unitcost", invlifofifocost.getDouble("unitcost"), 2L);
                    qty = MXMath.subtract(invlifofifocost.getDouble("quantity"), qty);
                    invlifofifocost.setValue("quantity", qty, 11L);
                    break;
                }
                invUseLineSplit.setValue("quantity", invlifofifocost.getDouble("quantity"), 2L);
                invUseLineSplit.setValue("unitcost", invlifofifocost.getDouble("unitcost"), 2L);
                qty = MXMath.subtract(qty, invlifofifocost.getDouble("quantity"));
                invlifofifocost.setValue("quantity", 0, 11L);
                if (status.equals("STAGED")) {
                    final MboRemote matrec = this.addMatRecTransRecordForStageTransfer(transMboSet, invUseLineSplit);
                    this.updateInvBalances(matrec, invUseLineSplit.getDouble("quantity"), "STAGED");
                }
                else if (status.equals("COMPLETE")) {
                    if (this.isTransfer()) {
                        this.addMatRecTransRecordForComplete(transMboSet, invUseLineSplit);
                    }
                    else {
                        this.addMatUseTransRecordForComplete(transMboSet, invUseLineSplit);
                    }
                }
                else if (status.equals("SHIPPED")) {
                    final MboRemote matrec = this.addMatRecTransRecordForShipTransfer(transMboSet, invUseLineSplit);
                    this.updateInvBalances(matrec, invUseLineSplit.getDouble("quantity"), "SHIPPED");
                    if (!this.getString("rotassetnum").equals("")) {
                        this.updateAssetStatus(this.getString("rotassetnum"), "DECOMMISSIONED");
                    }
                }
                lifoFifoUnitCost += MXMath.multiply(invUseLineSplit.getDouble("unitcost"), invUseLineSplit.getDouble("quantity"));
                invUseLineSplit = invUseLineSplit.copy();
                ++i;
            }
        }
        if (status.equals("STAGED")) {
            final MboRemote matrec = this.addMatRecTransRecordForStageTransfer(transMboSet, invUseLineSplit);
            this.updateInvBalances(matrec, invUseLineSplit.getDouble("quantity"), "STAGED");
        }
        else if (status.equals("COMPLETE")) {
            if (this.isTransfer()) {
                this.addMatRecTransRecordForComplete(transMboSet, invUseLineSplit);
            }
            else {
                this.addMatUseTransRecordForComplete(transMboSet, invUseLineSplit);
            }
        }
        else if (status.equals("SHIPPED")) {
            final MboRemote matrec = this.addMatRecTransRecordForShipTransfer(transMboSet, invUseLineSplit);
            this.updateInvBalances(matrec, invUseLineSplit.getDouble("quantity"), "SHIPPED");
            if (!this.getString("rotassetnum").equals("")) {
                this.updateAssetStatus(this.getString("rotassetnum"), "DECOMMISSIONED");
            }
        }
        lifoFifoUnitCost += MXMath.multiply(invUseLineSplit.getDouble("unitcost"), invUseLineSplit.getDouble("quantity"));
        return lifoFifoUnitCost;
    }
    
    public void setAttributesEditibiltyForReturn() throws MXException, RemoteException {
        final String[] edits = { "QUANTITY", "ACTUALDATE", "MEMO" };
        final MboSetInfo msi = this.getMboSetInfo();
        final Map attrsOrig = msi.getAttributeDetails();
        for (final MboValueInfo mvi : (Collection<MboValueInfo>)attrsOrig.values()) {
            if (!mvi.isUserdefined() && !Arrays.asList(edits).contains(mvi.getAttributeName())) {
                this.setFieldFlag(mvi.getAttributeName().toLowerCase(), 7L, true);
            }
        }
    }
    
    public void allKitComponentsAreInTransferToStore() throws MXException, RemoteException {
        if (!this.getUserInfo().isInteractive()) {
            return;
        }
        ItemSetRemote kitComponentsToAddToStore = null;
        final MboSetRemote itemSet = this.getMboSet("ITEM");
        ItemRemote item = null;
        if (!itemSet.isEmpty()) {
            item = (ItemRemote)itemSet.getMbo(0);
        }
        final String storeroom = this.getString("ToStoreLoc");
        if (item != null && item.isKit() && this.isTransfer() && !this.getString("tostoreloc").equalsIgnoreCase("")) {
            final LocationServiceRemote locService = (LocationServiceRemote)MXServer.getMXServer().lookup("LOCATION");
            if (kitComponentsToAddToStore == null) {
                final Hashtable<String, String> defaultBins = new Hashtable<String, String>();
                defaultBins.put(this.getString("itemnum"), this.getString("tobin"));
                kitComponentsToAddToStore = (ItemSetRemote)locService.getKitComponentsNotYetInStore(this.getUserInfo(), item, storeroom, this.getString("tositeid"), defaultBins);
            }
            if (kitComponentsToAddToStore != null && !kitComponentsToAddToStore.isEmpty()) {
                ((InvUseLineSet)this.getThisMboSet()).addWarning(new MXApplicationException("inventory", "AddKitComponents"));
            }
        }
    }
    
    public void updateMR(final MboRemote invReserve) throws MXException, RemoteException {
        final SqlFormat sqf = new SqlFormat(this, "mrnum = :mrnum and siteid=:tositeid");
        final MboSetRemote mrSet = ((MboSet)this.getThisMboSet()).getSharedMboSet("MR", sqf.format());
        if (mrSet.isEmpty()) {
            return;
        }
        final MboSetRemote mrLines = mrSet.getMbo(0).getMboSet("MRLINE");
        MboRemote current = null;
        for (int i = 0; (current = mrLines.getMbo(i)) != null; ++i) {
            if (current.getString("mrlinenum").equals(this.getString("mrlinenum"))) {
                ((MRLineRemote)current).setInvReserveReference(invReserve);
                current.setValue("complete", true, 2L);
                ((InvReserve)invReserve).setMRUpdated();
                break;
            }
        }
    }
}