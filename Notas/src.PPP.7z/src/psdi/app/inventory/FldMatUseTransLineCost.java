package psdi.app.inventory;

import java.rmi.RemoteException;

import psdi.mbo.Mbo;
import psdi.util.MaxType;
import psdi.mbo.MboRemote;
import psdi.server.AppService;
import psdi.app.currency.CurrencyService;
import psdi.app.workorder.WORemote;
import psdi.util.MXException;
import psdi.mbo.MboValue;
import psdi.mbo.MboValueAdapter;

public class FldMatUseTransLineCost extends MboValueAdapter
{
    public FldMatUseTransLineCost(final MboValue mbv) throws MXException {
        super(mbv);
    }
    
    @Override
    public void action() throws MXException, RemoteException {
        final MboValue thisValue = this.getMboValue();
        final MboRemote owner = thisValue.getMbo().getOwner();
        if (owner != null && owner instanceof WORemote) {
            final MatUseTrans matUse = (MatUseTrans)this.getMboValue().getMbo();
            final boolean hasIssueTypeChanged = matUse.hasIssueTypeChanged();
            double currCost = 0.0;
            if (!thisValue.isNull()) {
                currCost = thisValue.getDouble();
            }
            double prevCost = 0.0;
            final MaxType mtPrevious = thisValue.getPreviousValue();
            if (!mtPrevious.isNull()) {
                prevCost = mtPrevious.asDouble();
            }
            final WORemote woToUpdate = ((WORemote)owner).getWoFromCombined(this.getMboValue("RefWO").getString());
            double diff = 0.0;
            if (hasIssueTypeChanged) {
                diff = Math.abs(currCost) + Math.abs(prevCost);
                matUse.setIssueTypeChange(false);
                if (matUse.isReturn()) {
                    diff *= -1.0;
                }
            }
            else {
                diff = currCost - prevCost;
            }
            if (this.getMboValue("Outside").isNull()) {
                woToUpdate.incrActMatCost(diff, false);
            }
            else {
                woToUpdate.incrActMatCost(diff, this.getMboValue("Outside").getBoolean());
            }
        }
        final Mbo matuse = thisValue.getMbo();
        if (!matuse.isNull("orgid")) {
            final CurrencyService currService = (CurrencyService)((AppService)matuse.getMboServer()).getMXServer().lookup("CURRENCY");
            final String baseCurrency2 = currService.getBaseCurrency2(matuse.getString("orgid"), matuse.getUserInfo());
            if (baseCurrency2 != null && !baseCurrency2.equals("")) {
                try {
                    final double exchangeRate2 = currService.getCurrencyExchangeRate(matuse.getUserInfo(), matuse.getString("currencycode"), baseCurrency2, matuse.getDate("transdate"), matuse.getString("orgid"));
                    matuse.setValue("exchangerate2", exchangeRate2, 11L);
                    matuse.setValue("linecost2", exchangeRate2 * this.getMboValue().getDouble(), 11L);
                }
                catch (Exception e) {
                    matuse.setValueNull("exchangerate2", 11L);
                    matuse.setValueNull("linecost2", 11L);
                }
            }
        }
    }
}
