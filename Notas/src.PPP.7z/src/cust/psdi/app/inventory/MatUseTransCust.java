package cust.psdi.app.inventory;

import java.rmi.RemoteException;
import psdi.app.inventory.InvCost;
import psdi.app.inventory.Inventory;
import psdi.app.inventory.MatUseTrans;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSet;
import psdi.mbo.MboSetRemote;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;

public class MatUseTransCust extends MatUseTrans
{
	  public MatUseTransCust(MboSet ms) throws MXException, RemoteException
	  {
	    super(ms);
	  }
	  
	  public void save() throws MXException, RemoteException
	  {
		    super.save();

		    try
		    {
		        MboRemote owner = getOwner();
		        Inventory invMbo = (Inventory)getSharedInventory();
		        InvCost invcost = null;
		        if (invMbo != null) {
		            invcost = (InvCost)getInvCostRecord(invMbo);
		        }
		        if (invcost != null)
		        {
		            Double avgcost2 = Double.valueOf(invcost.getDouble("avgcost2"));
		            setValue("linecost2", getDouble("quantity") * -1.0D * avgcost2.doubleValue(), 2L);
		        }
		    }
		    catch (Exception e)
		    {
		        e.printStackTrace();
		    }
	  }
  
  private MboRemote getInvCostRecord(MboRemote inventory)
    throws MXException, RemoteException
  {
    MboSetRemote invcostSet = inventory.getMboSet("INVCOST");
    int i = 0;
    MboRemote invCost = null;
    while ((invCost = invcostSet.getMbo(i)) != null)
    {
      if (invCost.getString("itemnum").equals(getString("itemnum"))) {
        if (invCost.getString("location").equals(getString("storeloc"))) {
          if (invCost.getString("itemsetid").equals(getString("itemsetid"))) {
            if ((invCost.getString("conditioncode").equals(getString("conditioncode"))) && 
              (invCost.getString("siteid").equals(getString("siteid")))) {
              return invCost;
            }
          }
        }
      }
      i++;
    }
    return null;
  }
}
