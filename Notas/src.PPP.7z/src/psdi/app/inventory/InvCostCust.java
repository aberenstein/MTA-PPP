package psdi.app.inventory;

import java.rmi.RemoteException;
import java.util.Date;

import psdi.app.currency.CurrencyServiceRemote;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSet;
import psdi.security.UserInfo;
import psdi.server.MXServer;
import psdi.util.MXException;

public class InvCostCust extends InvCost
{
	protected double accumulativeReceiptQty = 0.0D;
  

	public InvCostCust(MboSet ms) throws MXException, RemoteException
	{
		super(ms);
	}
  

	public void init() throws MXException
	{
		super.init();
		try
		{
			String[] existingReadOnly = { "avgcost2" };
			if (!toBeAdded())
			{
				setFieldFlag(existingReadOnly, 7L, true);
			}
		}
		catch (Exception localException) {}
	} 

	  
	///AMB===v===
	/*
	public void updateAverageCost(double quantity, double totalvalue, String currency, Date exchangeDate) throws MXException, RemoteException
	{
		double avgcost = getDouble("avgcost");
		double avgcost2 = getDouble("avgcost2");

		double cur_bal = getCurrentBalance(null, null) + this.accumulativeReceiptQty;
		if ((cur_bal + quantity <= 0.0D) || ((totalvalue == 0.0D) && (quantity == 0.0D))) {
			return;
		}

		UserInfo userinfo = getUserInfo();
		String orgid = getString("orgid");
		CurrencyServiceRemote currService = (CurrencyServiceRemote)MXServer.getMXServer().lookup("CURRENCY");
		String baseCurrency1 = currService.getBaseCurrency1(orgid, userinfo);
		String baseCurrency2 = currService.getBaseCurrency2(orgid, userinfo);
    
		// Si currency == ARS convierte de ARS a USD
		// Si currency == USD convierte de USD a ARS 
		double exr = currency.equalsIgnoreCase("ARS")?
					 currService.getCurrencyExchangeRate(userinfo, baseCurrency1, baseCurrency2, exchangeDate, orgid):
					 currService.getCurrencyExchangeRate(userinfo, baseCurrency2, baseCurrency1, exchangeDate, orgid);
	      
		double new_avgcost = currency.equalsIgnoreCase("ARS")?
				 			 (avgcost * cur_bal + totalvalue) / (cur_bal + quantity):
		 					 (avgcost * cur_bal + totalvalue * exr) / (cur_bal + quantity);
				
				
		double new_avgcost2 = currency.equalsIgnoreCase("ARS")?
		                      ((avgcost2 * cur_bal + totalvalue * exr) / (cur_bal + quantity)):			
		                      ((avgcost2 * cur_bal + totalvalue) / (cur_bal + quantity));

		setValue("avgcost", new_avgcost, 2L);
		setValue("avgcost2", new_avgcost2, 2L);
	}
	*/
	///AMB===^===

	  
	public void updateAverageCost(double quantity, double totalvalue, double exr) throws MXException, RemoteException
	{ 
		///AMB===v===
		double cur_bal = getCurrentBalance(null, null) + this.accumulativeReceiptQty;
		if ((cur_bal + quantity <= 0.0D) || ((totalvalue == 0.0D) && (quantity == 0.0D))) {
			return;
		}

		double new_avgcost;
		if (cur_bal > 0.0D)
		{
			double avgcost = getDouble("avgcost");
			new_avgcost = (avgcost * cur_bal + totalvalue * exr) / (cur_bal + quantity);
		} else {
			new_avgcost = totalvalue * exr / quantity;
		}
		setValue("avgcost", new_avgcost, 2L);
    
		UserInfo user = getUserInfo();
    
		CurrencyServiceRemote currService = (CurrencyServiceRemote)MXServer.getMXServer().lookup("CURRENCY");
    
		Date date = MXServer.getMXServer().getDate(getClientLocale(), getClientTimeZone());
		if (super.exchageDate != null) {
			date = super.exchageDate;
			super.exchageDate = null;
		}
    
		String baseCurrency1 = currService.getBaseCurrency1(getString("orgid"), user);
		String baseCurrency2 = currService.getBaseCurrency2(getString("orgid"), user);
    
		if ((!baseCurrency2.equals("")) && (baseCurrency2 != null))
		{
			double exr2 = currService.getCurrencyExchangeRate(user, baseCurrency1, baseCurrency2, date, getString("orgid"));
      
			if (cur_bal + quantity != 0)
			{
				double avgcost2 = getDouble("avgcost2");
				double new_avgcost2 = exr != 1? ((avgcost2 * cur_bal + totalvalue) / (cur_bal + quantity)):			// la OC esta en la moneda 2 (USD)
					                            ((avgcost2 * cur_bal + totalvalue * exr2) / (cur_bal + quantity));	// la OC esta en la moneda 1 (ARS)			
				setValue("avgcost2", new_avgcost2, 2L);
			}
		}

		///AMB===^===
	} 

  
	void increaseAccumulativeReceiptQty(double currentReceiptQty) throws MXException, RemoteException
	{
		this.accumulativeReceiptQty += currentReceiptQty;
	}
  

	public void add() throws MXException, RemoteException
	{
		super.add();
    
		MboRemote owner = getOwner();
		if (owner == null) return;

		if (((owner instanceof InventoryRemote)) && (owner.toBeAdded()))
		{
			setValue("avgcost2", owner.getDouble("avgcost2"), 2L);
		}
	}

  
	public MboRemote adjustAverageCost(double newcost, double newcost2) throws MXException, RemoteException
	{
		if (((isNull("newavgcost")) || (getMboValue("avgcost").getDouble() == newcost)) && 
		    ((isNull("newavgcost2")) || (getMboValue("avgcost2").getDouble() == newcost2)))
		{
			InvCostSet invCostSet = (InvCostSet)getThisMboSet();
			invCostSet.increaseErrorCount();
			return null;
   		}
		MboRemote invTran = adjustAverageCost(newcost);
    
		double old_cost2 = getDouble("avgcost2");
		invTran.setValue("oldcost2", old_cost2, 2L);
		invTran.setValue("newcost2", newcost2, 2L);

		setValue("avgcost2", newcost2, 2L);

		return invTran;
	}
  

	public MboRemote adjustAverageCost(double newcost) throws MXException, RemoteException
	{
		double cur_bal = getCurrentBalance(null, null);
		double physcnt = 0.0D;

		try
		{
			physcnt = getPhysicalCount(null, null);
		}
		catch (Exception localException) {}
		
		MboRemote invTran = getMboSet("INVTRANS").add(2L);
    
		invTran.setValue("TRANSTYPE", getTranslator().toExternalDefaultValue("ITTYPE", "AVGCSTADJ", invTran), 2L);
    
		invTran.setValue("curbal", cur_bal, 2L);
		invTran.setValue("physcnt", physcnt, 2L);
		invTran.setValue("quantity", cur_bal, 2L);
    
		double old_cost = getDouble("avgcost");
		invTran.setValue("oldcost", old_cost, 2L);
		invTran.setValue("newcost", newcost, 2L);
    
		invTran.setValueNull("binnum", 2L);
		invTran.setValueNull("lotnum", 2L);
    
		String[] ron = { "binnum", "lotnum" };
		invTran.setFieldFlag(ron, 7L, true);
    
		invTran.setValue("gldebitacct", getString("controlaccount"), 2L);
		invTran.setValue("glcreditacct", getString("invcostadjaccount"), 2L);
    
		invTran.setValue("linecost", (newcost - old_cost) * cur_bal, 2L);
		invTran.setValue("conditioncode", getString("conditioncode"), 11L);

		invTran.setValue("memo", getString("memo"), 2L);
    
		setValue("avgcost", newcost, 2L);
    
		return invTran;
	}
}
