package psdi.app.inventory;

import java.rmi.RemoteException;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;
import java.util.Vector;

import psdi.app.asset.AssetRemote;
import psdi.app.common.TransactionGLMerger;
import psdi.app.currency.CurrencyService;
import psdi.app.financial.FinancialServiceRemote;
import psdi.app.integration.IntegrationServiceRemote;
import psdi.app.invoice.InvoiceServiceRemote;
import psdi.app.item.ItemRemote;
import psdi.app.location.LocationRemote;
import psdi.app.meter.DeployedMeterRemote;
import psdi.app.workorder.WORemote;
import psdi.app.workorder.WOSet;
import psdi.mbo.Mbo;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSet;
import psdi.mbo.MboSetInfo;
import psdi.mbo.MboSetRemote;
import psdi.mbo.MboValue;
import psdi.mbo.MboValueInfo;
import psdi.mbo.SqlFormat;
import psdi.mbo.Translate;
import psdi.security.UserInfo;
import psdi.server.AppService;
import psdi.server.MXServer;
import psdi.txn.MXTransaction;
import psdi.util.MXApplicationException;
import psdi.util.MXException;
import psdi.util.MXMath;

public class MatUseTrans
  extends Mbo
  implements MatUseTransRemote
{
  private MboRemote issueMbo = null;
  double remainQty = -1.11D;
  double totalQty = 0.0D;
  double returnQtyDeleted = 0.0D;
  boolean sharedInventoryHasBeenUpdated = false;
  boolean sharedInvBalancesHasBeenUpdated = false;
  boolean invReserveUpdated = false;
  boolean checkNegBalance = true;
  boolean selectItemForReturn = false;
  private boolean uncommitted = false;
  boolean processed = false;
  
  public MatUseTrans(MboSet ms)
    throws MXException, RemoteException
  {
    super(ms);
  }
  
  public void init()
    throws MXException
  {
    super.init();
    try
    {
      MboSetRemote matUseSet = getThisMboSet();
      MXTransaction trn = matUseSet.getMXTransaction();
      trn.setIndexOf(matUseSet, 0);
    }
    catch (Exception e) {}

    setFieldFlag("TRANSDATE", 7L, true);
    setFieldFlag("qtyrequested", 7L, true);
    setFieldFlag("qtyrequested", 128L, true);
    setFieldFlag("CURBAL", 7L, true);
    setFieldFlag("CURBAL", 128L, true);
    setFieldFlag("PHYSCNT", 7L, true);
    setFieldFlag("PHYSCNT", 128L, true);
    setFieldFlag("linecost", 7L, true);
    setFieldFlag("UNITCOST", 128L, true);
    setFieldFlag("linecost", 512L, true);
    
    MboRemote owner = getOwner();
    if ((owner != null) && ((owner instanceof WORemote)))
    {
      setFieldFlag("mrnum", 7L, true);
      setFieldFlag("mrlinenum", 7L, true);
    }
    if (!toBeAdded()) {
      setFlag(7L, true);
    }
  }
  
  public void add()
    throws MXException, RemoteException
  {
    MboRemote owner = getOwner();
    if (owner != null) {
      setValue("tositeid", owner.getString("siteid"), 11L);
    } else {
      setValue("tositeid", getString("siteid"), 11L);
    }
    setValue("sourcembo", "MATUSETRANS", 3L);

    String quantity = getMboValue("quantity").getMboValueInfo().getDefaultValue();
    if (quantity != null) {
      setValue("quantity", Double.parseDouble(quantity), 3L);
    } else {
      setValue("quantity", -1, 3L);
    }
    setValue("ISSUETYPE", getTranslator().toExternalDefaultValue("ISSUETYP", "ISSUE", this), 11L);
    
    String lineType = getMboValue("linetype").getMboValueInfo().getDefaultValue();
    if (lineType != null) {
      setValue("LINETYPE", lineType, 3L);
    } else {
      setValue("LINETYPE", getTranslator().toExternalDefaultValue("LINETYPE", "ITEM", this), 3L);
    }

    Date currentDate = MXServer.getMXServer().getDate();

    setValue("ACTUALDATE", currentDate, 2L);
    setValue("NEWPHYSCNTDATE", currentDate, 2L);
    setValue("TRANSDATE", currentDate, 2L);
    setValue("ENTERBY", getUserInfo().getUserName(), 2L);
    setValue("SPAREPARTADDED", false, 2L);
    setValue("rollup", false, 2L);
    setValue("CONDRATE", 100, 2L);
    setValue("CURBAL", 0, 2L);
    setValue("PHYSCNT", 0, 2L);
    
    CurrencyService curService = (CurrencyService)((AppService)getMboServer()).getMXServer().lookup("CURRENCY");
    setValue("CURRENCYCODE", curService.getBaseCurrency1(getString("orgid"), getUserInfo()));

    MboRemote ownerRem = getOwner();
    if (ownerRem.isBasedOn("INVENTORY"))
    {
      setValue("itemsetid", owner.getString("itemsetid"), 2L);
      setValue("itemnum", owner.getString("itemnum"), 2L);
      setValue("storeloc", owner.getString("location"), 2L);
    }
    else if (ownerRem.isBasedOn("LOCATIONS"))
    {
      setValue("storeloc", owner.getString("location"), 2L);
      setValue("UNITCOST", 0, 2L);
      setFieldFlag("UNITCOST", 7L, true);
    }
    else if (ownerRem.isBasedOn("WORKORDER"))
    {
      setValue("wonum", owner.getString("wonum"), 2L);
      setValue("fincntrlid", owner.getString("fincntrlid"), 2L);
    }
    else if (ownerRem.isBasedOn("MATRECTRANS"))
    {
      addFromMatRec();
    }
    if ((owner != null) && (owner.isBasedOn("ASSET")))
    {
      setValue("assetnum", owner.getString("assetnum"), 11L);
      setValue("tositeid", owner.getString("siteid"), 11L);
      setValue("location", owner.getString("location"), 11L);
      setFieldFlag("assetnum", 7L, true);
      setFieldFlag("tositeid", 7L, true);
      setFieldFlag("location", 7L, true);
      if ((((AssetRemote)owner).getDefSiteId() != null) && (((AssetRemote)owner).getDefStoreloc() != null))
      {
        setValue("siteid", ((AssetRemote)owner).getDefSiteId(), 2L);
        setValue("storeloc", ((AssetRemote)owner).getDefStoreloc(), 2L);
      }
    }
  }
  
  private void addFromMatRec()
    throws MXException, RemoteException
  {
    MatRecTrans owner = (MatRecTrans)getOwner();

    double quantity = owner.getDouble("quantity");
    if ((owner.getPOLine().isInspectionRequired()) && (!owner.isReturn()) && (!owner.isVoidReceipt())) {
      quantity = (owner.getDouble("inspectedqty") - owner.getDouble("rejectqty")) * -1.0D;
    } else if (!owner.isMisclReceipt()) {
      quantity *= -1.0D;
    }
    double unitcost = owner.getDouble("unitcost");
    String matRecLineType = getTranslator().toInternalString("LINETYPE", owner.getString("linetype"));
    if (matRecLineType.equalsIgnoreCase("SPORDER")) {
      setValue("linetype", getTranslator().toExternalDefaultValue("LINETYPE", "ITEM", this), 2L);
    } else {
      setValue("linetype", owner.getString("linetype"), 2L);
    }
    setValue("itemsetid", owner.getString("itemsetid"), 2L);
    setValue("itemnum", owner.getString("itemnum"), 2L);
    setValue("conditioncode", owner.getString("conditioncode"), 2L);
    setValue("description", owner.getString("description"), 2L);
    setValue("enteredastask", owner.getString("enteredastask"), 2L);
    setValueNull("storeloc", 2L);
    setValueNull("binnum", 2L);
    setValueNull("lotnum", 2L);
    setValue("glcreditacct", owner.getString("glcreditacct"), 11L);
    if ((owner.isBasedOn("MATRECTRANS")) && (getTranslator().toInternalString("ISSUETYP", owner.getString("issuetype")).equalsIgnoreCase("INVOICE"))) {
      setValue("gldebitacct", owner.getString("gldebitacct"), 11L);
    } else {
      setValue("gldebitacct", owner.getPOLine().getString("gldebitacct"), 11L);
    }
    setValue("commodity", owner.getString("commodity"), 11L);
    setValue("commoditygroup", owner.getString("commoditygroup"), 11L);
    setValue("ponum", owner.getString("ponum"), 2L);
    setValue("porevisionnum", owner.getString("porevisionnum"), 2L);
    setValue("polinenum", owner.getString("polinenum"), 2L);
    setValue("it1", owner.getString("it1"), 2L);
    setValue("it2", owner.getString("it2"), 2L);
    setValue("it3", owner.getString("it3"), 2L);
    setValue("it4", owner.getString("it4"), 2L);
    setValue("it5", owner.getString("it5"), 2L);
    setValue("it6", owner.getString("it6"), 2L);
    setValue("it7", owner.getString("it7"), 2L);
    setValue("it8", owner.getString("it8"), 2L);
    setValue("it9", owner.getString("it9"), 2L);
    setValue("it10", owner.getString("it10"), 2L);
    setValue("itin1", owner.getString("itin1"), 2L);
    setValue("itin2", owner.getString("itin2"), 2L);
    setValue("itin3", owner.getString("itin3"), 2L);
    setValue("itin4", owner.getString("itin4"), 2L);
    setValue("itin5", owner.getString("itin5"), 2L);
    setValue("itin6", owner.getString("itin6"), 2L);
    setValue("itin7", owner.getString("itin7"), 2L);
    setValue("packingslipnum", owner.getString("packingslipnum"), 2L);

    String issueType = null;
    if ((quantity == 0.0D) && (getTranslator().toInternalString("ISSUETYP", owner.getString("issuetype")).equalsIgnoreCase("INVOICE")))
    {
      issueType = getTranslator().toExternalDefaultValue("ISSUETYP", "INVOICE", this);
      setFieldFlag("issueto", 128L, false);
    }
    else if (quantity < 0.0D)
    {
      issueType = getTranslator().toExternalDefaultValue("ISSUETYP", "ISSUE", this);
    }
    else
    {
      issueType = getTranslator().toExternalDefaultValue("ISSUETYP", owner.getString("issuetype"), this);
    }
    setValue("issuetype", issueType, 2L);
    setValue("matrectransid", owner.getString("matrectransid"), 2L);
    setValue("enterby", owner.getString("enterby"), 2L);
    if ((issueType.equalsIgnoreCase("RETURN")) || (owner.isVoidReceipt())) {
      setFieldFlag("issueto", 128L, false);
    }
    setValue("issueto", owner.getString("issueto"), 2L);
    setValue("outside", owner.getBoolean("outside"), 2L);
    setValue("rollup", false, 2L);
    setValue("sparepartadded", false, 2L);
    if (owner.getDouble("qtyrequested") < 0.0D) {
      getMboValue("qtyrequested").getMboValueInfo().setPositive(false);
    }
    setValue("qtyrequested", owner.getDouble("qtyrequested"), 2L);
    setValue("actualcost", owner.getDouble("actualcost"), 2L);
    setValue("actualdate", owner.getString("actualdate"), 3L);
    setValue("financialperiod", owner.getString("financialperiod"), 11L);
    setValue("exchangerate", owner.getDouble("exchangerate"), 2L);
    if (!owner.getMboValue("exchangerate2").isNull()) {
      setValue("exchangerate2", owner.getDouble("exchangerate2"), 2L);
    }
    setValue("quantity", quantity, 2L);
    setValue("unitcost", unitcost, 2L);
    if (!owner.isNull("conversion")) {
      setValue("conversion", owner.getDouble("conversion"), 2L);
    }
    setValue("currencycode", owner.getString("currencycode"), 2L);
    if (owner.getPOLine().isInspectionRequired())
    {
      if (issueType.equalsIgnoreCase("INVOICE")) {
        setValue("currencylinecost", owner.getDouble("currencylinecost"), 2L);
      } else {
        setValue("currencylinecost", quantity * -1.0D * unitcost, 2L);
      }
    }
    else {
      setValue("currencylinecost", owner.getDouble("currencylinecost"), 2L);
    }
    setValue("currencyunitcost", owner.getDouble("currencyunitcost"), 2L);
    setValue("matrectransid", owner.getString("matrectransid"), 2L);

    cust.component.Logger.Log("addFromMatRec(antes#1)");
    ///AMB===v===
    ///if (!isNull("exchangerate2")) {
    ///    setValue("linecost2", getDouble("exchangerate2") * getDouble("linecost"), 2L);
    ///}
    Inventory invMbo = (Inventory)getSharedInventory();
    InvCost invcost = (InvCost)getInvCostRecord(invMbo);
    ///AMB===^===
    cust.component.Logger.Log("addFromMatRec(despues#1)");
    
    if (owner.getPOLine().isInspectionRequired())
    {
      if (issueType.equalsIgnoreCase("INVOICE")) {
        setValue("linecost", owner.getDouble("loadedcost"), 2L);
      } else {
        setValue("linecost", quantity * -1.0D * unitcost, 2L);
      }
    }
    else {
      setValue("linecost", owner.getDouble("loadedcost"), 2L);
    }
    
    cust.component.Logger.Log("addFromMatRec(antes#2)");
    ///AMB===v===
    ///if (!isNull("exchangerate2")) {
    ///    setValue("linecost2", getDouble("exchangerate2") * getDouble("linecost"), 2L);
    ///}
    setValue("linecost2", invcost.getDouble("avgcost2") * quantity, 2L);
    ///AMB===^===
    cust.component.Logger.Log("addFromMatRec(despues#2)");

    setValue("assetnum", owner.getString("assetnum"), 11L);

    MatRecTrans matrec = owner;
    
    setValue("rotassetnum", matrec.getRotAssetNum(), 11L);
    setValue("mrlinenum", owner.getString("mrlinenum"), 11L);
    setValue("mrnum", owner.getString("mrnum"), 11L);
    setValue("wonum", owner.getString("wonum"), 11L);
    setValue("taskid", owner.getString("taskid"), 11L);
    setValue("refwo", owner.getString("refwo"), 11L);
    setValue("fincntrlid", owner.getString("fincntrlid"), 2L);
    setValue("location", owner.getString("location"), 11L);
    setValue("ownersysid", owner.getString("ownersysid"), 2L);
    setValue("binnum", owner.getString("tobin"), 3L);
    setValue("lotnum", owner.getString("tolot"), 3L);
    if (issueType.equalsIgnoreCase("INVOICE")) {
      setValue("financialperiod", owner.getString("financialperiod"), 11L);
    }
    if (owner.isMisclReceipt())
    {
      setValue("storeloc", owner.getString("tostoreloc"), 11L);
      setValue("curbal", owner.getDouble("curbal"), 11L);
    }
    if ((!owner.isNull("positeid")) && (!owner.getString("positeid").equalsIgnoreCase(getString("siteid")))) {
      setValue("siteid", owner.getString("fromsiteid"), 66L);
    }
  }
  
  public double getTotalQtyForReturn()
    throws MXException, RemoteException
  {
    if (!isIssue()) {
      return 0.0D;
    }
    MboSetRemote matUseSet = getMboSet("RETURNS");
    
    return Math.abs(getDouble("quantity")) - Math.abs(matUseSet.sum("quantity"));
  }
  
  public double getQtyForReturn()
    throws MXException, RemoteException
  {
    return this.remainQty;
  }
  
  public void setQtyForReturn(double qty)
    throws MXException, RemoteException
  {
    this.remainQty += qty;
  }
  
  public MatUseTransRemote getIssueForThisReturn()
    throws MXException, RemoteException
  {
    return (MatUseTransRemote)this.issueMbo;
  }
  
  public double getTotalQty()
    throws MXException, RemoteException
  {
    return this.totalQty;
  }
  
  public void setTotalQtyForThisReturn(double qty)
    throws MXException, RemoteException
  {
    this.totalQty = qty;
  }
  
  public void canDelete()
    throws MXException, RemoteException
  {
    if (toBeAdded()) {
      return;
    }
    throw new MXApplicationException("inventory", "matusetransCannotDelete");
  }
  
  public void appValidate()
    throws MXException, RemoteException
  {
    boolean isToolInv = false;
    MboRemote owner = getOwner();
    if (owner != null) {
      if ((owner instanceof ToolInv)) {
        isToolInv = true;
      }
    }
    super.appValidate();
    if (isIssue())
    {
      InventoryRemote invRem = (InventoryRemote)getSharedInventory();
      if (invRem != null) {
        invRem.checkRequestAgainstItemMaxIssue(getString("assetnum"), -getDouble("quantity"));
      }
    }
    if ((isIssue()) && (!toBeAdded()))
    {
      super.save();
      return;
    }
    if ((isReturn()) && (!toBeAdded())) {
      return;
    }
    if (!toBeDeleted())
    {
      if ((isNull("itemnum")) && (isNull("description"))) {
        throw new MXApplicationException("inventory", "enterItemOrDesc");
      }
      if ((isNull("itemnum")) && (!isNull("storeloc"))) {
        throw new MXApplicationException("inventory", "enterValidItemnum");
      }
      if ((!isToolInv) && (!getTranslator().toInternalString("LINETYPE", getString("linetype")).equals("TOOL"))) {
        if ((isNull("refwo")) && (isNull("assetnum")) && (isNull("location")) && (isNull("gldebitacct")) && (isNull("mrnum"))) {
          throw new MXApplicationException("inventory", "matusetransNullChargeTo");
        }
      }
    }
    if ((!isNull("itemnum")) && (isNull("storeloc")) && ((getOwner() == null) || (!getOwner().getName().equals("MATRECTRANS"))))
    {
      ItemRemote item = (ItemRemote)getMboSet("ITEM").getMbo(0);
      
      Mbo itemOrg = (Mbo)item.getMboSet("itemorginfo").getMbo(0);
      if (itemOrg != null)
      {
        String itemOrgCategory = getTranslator().toInternalString("CATEGORY", itemOrg.getString("category"));
        if ((!getTranslator().toInternalString("LINETYPE", getString("linetype")).equals("SPORDER")) && (itemOrgCategory != null) && (!itemOrgCategory.equals("NS")) && (!itemOrgCategory.equals("SP"))) {
          throw new MXApplicationException("inventory", "cannotIssueNoStoreloc");
        }
      }
    }
    if ((!getString("mrnum").equals("")) && (getString("mrlinenum").equals(""))) {
      throw new MXApplicationException("inventory", "specifyReqLineNum");
    }
    if ((!getString("mrlinenum").equals("")) && (getString("mrnum").equals(""))) {
      throw new MXApplicationException("inventory", "specifyReqNum");
    }
    if ((!isNull("itemnum")) && (!getTranslator().toInternalString("LINETYPE", getString("linetype")).equals("SPORDER")) && (owner != null) && (!owner.isBasedOn("InvUse")))
    {
      ItemRemote item = (ItemRemote)getMboSet("ITEM").getMbo(0);
      if ((item.isRotating()) && (isNull("rotassetnum"))) {
        if ((getOwner() == null) || (!(getOwner() instanceof MatRecTrans))) {
          throw new MXApplicationException("inventory", "matusetransNullRotassetnum");
        }
      }
      if ((!isNull("rotassetnum")) && (isIssue()))
      {
        MboRemote rotasset = getMboSet("rotasset").getMbo(0);
        if ((rotasset != null) && 
          (!getString("binnum").equalsIgnoreCase(rotasset.getString("binnum"))))
        {
          Object[] param = { "Item/Rotating Asset/Bin combination", "" };
          throw new MXApplicationException("commlog", "InvalidTemplateId", param);
        }
      }
      if ((item.isConditionEnabled()) && (isNull("conditioncode")))
      {
        Object[] param = { getString("itemnum") };
        throw new MXApplicationException("inventory", "noConditionCode", param);
      }
    }
    if ((getDouble("quantity") == 0.0D) && (!getTranslator().toInternalString("ISSUETYP", getString("issuetype")).equalsIgnoreCase("INVOICE"))) {
      throw new MXApplicationException("inventory", "matusetransZeroQuantity");
    }
    if (!isNull("issuetype"))
    {
      if ((isIssue()) && (getDouble("quantity") > 0.0D)) {
        throw new MXApplicationException("inventory", "matusetransPosQuantity");
      }
      if ((isReturn()) && (getDouble("quantity") < 0.0D)) {
        throw new MXApplicationException("inventory", "matusetransNegQuantity");
      }
    }
    if ((!isNull("itemnum")) && (!isNull("storeloc")))
    {
      MboRemote inventory = getSharedInventory();
      if (inventory == null) {
        throw new MXApplicationException("inventory", "invbalNotInInventory");
      }
      MboRemote invBal = getSharedInvBalance();
      if ((invBal == null) && (isIssue())) {
        throw new MXApplicationException("inventory", "matusetransNoBalances");
      }
      if (invBal != null)
      {
        Date currentUseBy = invBal.getDate("useby");
        Calendar currentUseByCal = null;
        if (currentUseBy != null)
        {
          currentUseByCal = Calendar.getInstance();
          currentUseByCal.setTime(currentUseBy);
          Date now = MXServer.getMXServer().getDate();
          Calendar nowCal = Calendar.getInstance();
          nowCal.setTime(now);
          nowCal.set(11, 0);
          nowCal.set(12, 0);
          nowCal.set(13, 0);
          nowCal.set(14, 0);
          if (currentUseByCal.before(nowCal)) {
            throw new MXApplicationException("inventory", "expiredLot");
          }
        }
      }
      if ((toBeAdded()) && (isIssue()) && (owner != null) && (!(owner instanceof MatRecTransRemote)) && (getCheckNegBalanceFlag())) {
        checkForNegativeBalance();
      }
    }
    boolean noFinancial = false;
    if (((owner != null) && (owner.isBasedOn("InvUse"))) || (((isIssue()) || (isReturn())) && (getTranslator().toInternalString("LINETYPE", getString("linetype")).equals("TOOL")))) {
      noFinancial = true;
    }
    FinancialServiceRemote fsr = (FinancialServiceRemote)MXServer.getMXServer().lookup("FINANCIAL");
    if ((!isToolInv) && (!noFinancial))
    {
      if (fsr.glRequiredForTrans(getUserInfo(), getString("orgid"))) {
        if ((isNull("gldebitacct")) || (isNull("glcreditacct"))) {
          throw new MXApplicationException("financial", "GLRequiredForTrans");
        }
      }
      if (!toBeDeleted())
      {
        String glDebitAcct = getString("gldebitacct");
        String orgID = getString("orgid");
        if (!glDebitAcct.equals(""))
        {
          String[] params = { glDebitAcct };
          if (!fsr.validateFullGLAccount(getUserInfo(), glDebitAcct, orgID)) {
            throw new MXApplicationException("inventory", "InvalidGLAccount", params);
          }
        }
        if (!isNull("glcreditacct"))
        {
          String[] params = { getString("glcreditacct") };
          if (!fsr.validateFullGLAccount(getUserInfo(), getString("glcreditacct"), orgID)) {
            throw new MXApplicationException("inventory", "InvalidGLAccount", params);
          }
        }
      }
    }
    if (!isNull("RefWO"))
    {
      verifyChangesAreAllowed();
      

      boolean editHistMode = false;
      if ((owner != null) && (owner.isBasedOn("WORKORDER")))
      {
        WORemote woOwner = (WORemote)owner;
        editHistMode = woOwner.isWOInEditHist();
      }
      if ((getWO().getBoolean("HistoryFlag")) && (isIssue()) && (!editHistMode))
      {
        Object[] param = { getString("refwo"), getMboValue("REFWO").getColumnTitle() };
        throw new MXApplicationException("workorder", "WOHistory", param);
      }
    }
  }
  
  private void verifyChangesAreAllowed()
    throws MXException, RemoteException
  {
    MboRemote workorder = getWO();
    if (workorder == null) {
      return;
    }
    if (!isNull("taskid"))
    {
      MboSetRemote woChildren = workorder.getMboSet("CHILDREN");
      int y = 0;
      MboRemote woChild = woChildren.getMbo(y);
      while (woChild != null)
      {
        if (woChild.getBoolean("ISTASK")) {
          if ((getString("taskid").equals(woChild.getString("TASKID"))) && (!woChild.getBoolean("woacceptscharges")))
          {
            Object[] param = { workorder.getString("wonum"), getString("taskid") };
            
            throw new MXApplicationException("workorder", "TaskAcceptsChargesNo", param);
          }
        }
        y++;
        woChild = woChildren.getMbo(y);
      }
    }
    else if (!workorder.getBoolean("woacceptscharges"))
    {
      Object[] param = { workorder.getString("wonum") };
      throw new MXApplicationException("workorder", "WOAcceptsChargesNo", param);
    }
  }
  
  public MboRemote getWO()
    throws MXException, RemoteException
  {
    MboRemote owner = getOwner();
    if ((owner != null) && ((owner instanceof WORemote))) {
      return owner;
    }
    if (isNull("refwo")) {
      return null;
    }
    SqlFormat sqf = new SqlFormat(this, "wonum=:refwo and siteid=:tositeid");
    MboSetRemote woset = ((MboSet)getThisMboSet()).getSharedMboSet("WORKORDER", sqf.format());
    
    MboRemote woMbo = null;
    if (!woset.isEmpty()) {
      woMbo = woset.getMbo(0);
    }
    return woMbo;
  }
  
  public void save()
    throws MXException, RemoteException
  {
    MboRemote owner = getOwner();
    Inventory invMbo = (Inventory)getSharedInventory();
    if (invMbo != null)
    {
      setValue("consignment", invMbo.getBoolean("consignment"), 2L);
      setValue("consvendor", invMbo.getString("consvendor"), 2L);
      if ((!getBoolean("split")) && (owner != null) && ((owner.isBasedOn("WORKORDER")) || (owner.isBasedOn("ASSET"))) && ((invMbo.getCostType().equalsIgnoreCase("LIFO")) || (invMbo.getCostType().equalsIgnoreCase("FIFO")))) {
        createMatUseTransRecordforLifoFifo(invMbo);
      }
    }
    if (isKitting())
    {
      super.save();
      return;
    }
    if (((!isNull("assetnum")) || (!isNull("location"))) && (!isNull("itemnum"))) {
      handleMeterReadingOnIssue();
    }
    if ((owner != null) && (owner.getName().equals("MATRECTRANS")))
    {
      if ((((MatRecTrans)owner).isMisclReceipt()) && (isReturn())) {
        if (invMbo != null) {
          invMbo.updateInventoryIssueDetails(getDate("actualdate"), getDouble("quantity"));
        }
      }
      super.save();
      return;
    }
    if ((!isNull("ponum")) || ((owner != null) && (getOwner().getName().equals("MATRECTRANS"))))
    {
      super.save();
      return;
    }
    if ((isIssue()) && (!toBeAdded()))
    {
      super.save();
      return;
    }
    if ((isReturn()) && (!toBeAdded()))
    {
      super.save();
      return;
    }
    if ((isReturn()) && (!toBeDeleted()) && (this.issueMbo != null))
    {
      SqlFormat sqf = new SqlFormat(this, "matusetransid=:1");
      sqf.setLong(1, getLong("issueid"));
      MboRemote issue = null;
      issue = ((MboSet)getThisMboSet()).getSharedMboSet("MATUSETRANS", sqf.format()).getMbo(0);
      if (issue != null) {
        issue.setValue("QTYRETURNED", issue.getDouble("qtyreturned") + Math.abs(getDouble("quantity")), 2L);
      }
    }
    ///cust.component.Logger.Log("IsReturn="+String.valueOf(isReturn()));/////////////////////////////////////////////
    updateWorkOrder();
    if (!isNull("rotassetnum"))
    {
      if ((isIssue()) && (!isNull("location")))
      {
        LocationRemote location = (LocationRemote)getMboSet("LOCATION").getMbo(0);
        if (location.isStore())
        {
          Object[] params = { getString("itemnum"), getString("location") };
          throw new MXApplicationException("inventory", "rotItemIssueToStore", params);
        }
      }
      moveAsset();
    }
    if (!isNull("assetnum")) {
      updateAssetSparePart();
    }
    MboValue mbv = getMboValue("requestnum");
    if ((!this.invReserveUpdated) && (!mbv.isNull())) {
      updateInvReserve();
    }
    if ((isNull("itemnum")) || (isNull("storeloc")))
    {
      setUncommitted(true);
      
      ///cust.component.Logger.Log("1");
      super.save();
      return;
    }
    InvBalances invBalMbo = (InvBalances)getSharedInvBalance();
    InvCost invcost = (InvCost)getInvCostRecord(invMbo);
    IntegrationServiceRemote intserv = (IntegrationServiceRemote)((AppService)getMboServer()).getMXServer().lookup("INTEGRATION");
    boolean useIntegration = intserv.useIntegrationRules(getString("ownersysid"), invMbo.getString("ownersysid"), "INV", getUserInfo());
    if (isReturn())
    {
      if (((invMbo.getCostType().equals("LIFO")) || (invMbo.getCostType().equals("FIFO"))) && (!useIntegration))
      {
        ///cust.component.Logger.Log("2");
        invMbo.addInvLifoFifoCostRecord(getDouble("quantity"), getDouble("unitcost"), getString("conditioncode"), getName(), (int) getLong("matusetransid"));
      }
      else if ((!isNull("conditioncode")) && (invcost == null))
      {
        ///cust.component.Logger.Log("3");
        invcost = (InvCost)invMbo.addInvCostRecord(getString("conditioncode"));
        invcost.setValue("stdcost", getDouble("unitcost"), 2L);
      }
      if (invBalMbo == null)
      {
        if (invMbo.getOwner() == null)
        {
          MboRemote ownerOfThisMatUse = getOwner();
          if ((ownerOfThisMatUse != null) && ((ownerOfThisMatUse instanceof InventoryRemote)))
          {
            MboSetRemote locSet = getMboServer().getMboSet("LOCATIONS", getUserInfo());
            SqlFormat sqf = new SqlFormat(getUserInfo(), "location=:1 and siteid=:2");
            sqf.setObject(1, "LOCATIONS", "LOCATION", getString("storeloc"));
            sqf.setObject(2, "SITE", "SITEID", getString("siteid"));
            locSet.setWhere(sqf.format());
            locSet.reset();
            MboRemote location = locSet.getMbo(0);
            invMbo.getThisMboSet().setOwner(location);
          }
          else
          {
            invMbo.getThisMboSet().setOwner(this);
          }
        }
        invBalMbo = (InvBalances)getInvBalancesRecord(invMbo);
        if (invBalMbo == null)
        {
          invBalMbo = (InvBalances)invMbo.getMboSet("INVBALANCES").add();
          invBalMbo.setValue("binnum", getString("binnum"), 11L);
          invBalMbo.setValue("lotnum", getString("lotnum"), 11L);
          invBalMbo.setValue("conditioncode", getString("conditioncode"), 11L);
        }
      }
    }
    ///cust.component.Logger.Log("4");
    if (invMbo != null) {
      if (!useIntegration)
      {
        if ((!this.sharedInvBalancesHasBeenUpdated) || (!this.sharedInventoryHasBeenUpdated))
        {
          if (!this.sharedInventoryHasBeenUpdated)
          {
            updateInventory(invMbo, invBalMbo, invcost);
            this.sharedInventoryHasBeenUpdated = true;
          }
          if (!this.sharedInvBalancesHasBeenUpdated)
          {
            setValue("curbal", invBalMbo.getCurrentBalance(), 2L);
            setValue("physcnt", invBalMbo.getPhysicalCount(), 2L);
            updateInvBalances(invBalMbo);
            this.sharedInvBalancesHasBeenUpdated = true;
          }
          setUncommitted(true);
          
          ///cust.component.Logger.Log("5");
          super.save();
          setFlag(7L, true);
        }
        setUncommitted(true);
        if (!isNull("newphyscnt"))
        {
          Date phyCntDate = getDate("NEWPHYSCNTDATE");
          if (isNull("NEWPHYSCNTDATE")) {
            phyCntDate = getDate("ACTUALDATE");
          }
          Calendar phyCal = Calendar.getInstance();
          phyCal.setTime(phyCntDate);
          int second = phyCal.get(13);
          phyCal.set(13, second + 1);
          Date datePlusOneSecond = phyCal.getTime();
          invMbo.adjustPhysicalCount(getString("binnum"), getString("lotnum"), getDouble("newphyscnt"), datePlusOneSecond, null, getString("conditioncode"));
        }
      }
    }
    ///cust.component.Logger.Log("6");
    super.save();
    createInvoiceOnConsumption();
  }
  
  public void createInvoiceOnConsumption()
    throws MXException, RemoteException
  {
    Inventory invMbo = (Inventory)getSharedInventory();
    if ((toBeAdded()) && (invMbo != null) && (invMbo.isConsignment()) && (MXMath.abs(getDouble("quantity")) > 0.0D))
    {
      String invGenType = getTranslator().toInternalString("INVGENTYPE", invMbo.getString("invgentype"), this);
      if ((invGenType != null) && (invGenType.equalsIgnoreCase("CONSUMPTION")))
      {
        UserInfo userInfo = getUserInfo();
        InvoiceServiceRemote invoiceService = (InvoiceServiceRemote)MXServer.getMXServer().lookup("INVOICE");
        MboSetRemote consTransactionSet = invoiceService.addConsignmentTransactions(this, userInfo);
        if (!consTransactionSet.isEmpty())
        {
          MboSetRemote invoiceSet = invoiceService.createInvoicesForConsignment(userInfo, consTransactionSet, invGenType);
          MboRemote invoice = invoiceSet.getMbo(0);
          if (invoice != null)
          {
            setValue("consinvoicenum", invoice.getString("invoicenum"), 11L);
            invoiceSet.setMXTransaction(getMXTransaction());
          }
        }
      }
    }
  }
  
  protected void doKitMakeInvBalanceUpdates()
    throws MXException, RemoteException
  {
    Inventory fromInventoryMbo = (Inventory)getSharedInventoryForKit(getString("storeloc"), getString("siteid"), getString("itemnum"));
    double quantity = MXMath.abs(getDouble("quantity"));
    MboSetRemote invBalancesToBuildKit = fromInventoryMbo.getInvBalancesSetForKitComponent("");
    invBalancesToBuildKit.setOrderBy("curbal desc");
    MboRemote fromInvBal = null;
    
    int x = 0;
    String fromInvDefaultBinnum = fromInventoryMbo.getString("binnum");
    while (((fromInvBal = invBalancesToBuildKit.getMbo(x)) != null) && (!fromInvBal.getString("binnum").equalsIgnoreCase(fromInvDefaultBinnum))) {
      x++;
    }
    x = 0;
    if (fromInvBal == null) {
      fromInvBal = invBalancesToBuildKit.getMbo(x);
    }
    double qtyFulfilled = 0.0D;
    do
    {
      double invBalCurBal = fromInvBal.getDouble("curbal");
      
      MboRemote matUseForNewBin = null;
      if (qtyFulfilled > 0.0D) {
        matUseForNewBin = copy();
      }
      if ((fromInvBal.getString("binnum").equalsIgnoreCase(fromInvDefaultBinnum)) && (fromInvBal.isSelected()))
      {
        x++;
      }
      else
      {
        double qtyToTakeFromThisInvCurBal = 0.0D;
        if (invBalCurBal >= quantity - qtyFulfilled) {
          qtyToTakeFromThisInvCurBal = quantity - qtyFulfilled;
        } else {
          qtyToTakeFromThisInvCurBal = invBalCurBal;
        }
        double fromOldBal = 0.0D;
        fromOldBal = fromInvBal.getDouble("curbal");
        
        ((InvBalances)fromInvBal).updateCurrentBalance(qtyToTakeFromThisInvCurBal * -1.0D + fromOldBal);
        if (matUseForNewBin != null)
        {
          matUseForNewBin.setValue("quantity", qtyToTakeFromThisInvCurBal * -1.0D, 2L);
          matUseForNewBin.setValue("binnum", fromInvBal.getString("binnum"), 2L);
          
          matUseForNewBin.setValue("curbal", fromOldBal, 2L);
          matUseForNewBin.setValue("physcnt", fromInvBal.getDouble("physcnt"), 2L);
        }
        else
        {
          setValue("quantity", qtyToTakeFromThisInvCurBal * -1.0D, 2L);
          setValue("binnum", fromInvBal.getString("binnum"), 2L);
          
          setValue("curbal", fromOldBal, 2L);
          setValue("physcnt", fromInvBal.getDouble("physcnt"), 2L);
        }
        qtyFulfilled += qtyToTakeFromThisInvCurBal;
        if (fromInvBal.getString("binnum").equalsIgnoreCase(fromInvDefaultBinnum)) {
          fromInvBal.select();
        } else {
          x++;
        }
      }
    } while (((fromInvBal = invBalancesToBuildKit.getMbo(x)) != null) && (qtyFulfilled < quantity));
  }
  
  private MboRemote getSharedInventoryForKit(String storeLoc, String siteId, String itemnum)
    throws MXException, RemoteException
  {
    MboRemote owner = getOwner();
    if (((owner instanceof InventoryRemote)) && (owner.getString("location").equals(storeLoc)) && (owner.getString("itemnum").equals(itemnum))) {
      return owner;
    }
    SqlFormat sqf = new SqlFormat(this, "itemnum = :1 and location = :2 and siteid = :3");
    sqf.setObject(1, "INVENTORY", "itemnum", itemnum);
    sqf.setObject(2, "INVENTORY", "location", storeLoc);
    sqf.setObject(3, "INVENTORY", "siteid", siteId);
    MboSetRemote invSet = ((MboSet)getThisMboSet()).getSharedMboSet("INVENTORY", sqf.format());
    if (invSet != null) {
      invSet.setOwner(this);
    }
    if ((invSet == null) || (invSet.isEmpty())) {
      return null;
    }
    return invSet.getMbo(0);
  }
  
  private void updateInventory(Inventory invMbo, InvBalances invBal, InvCost invcost)
    throws MXException, RemoteException
  {
    if (invMbo.toBeAdded())
    {
      invMbo.updateInventoryIssueDetails(getDate("actualdate"), getDouble("quantity"));
    }
    else
    {
      MatUseTransSet owningSet = (MatUseTransSet)getThisMboSet();
      owningSet.addDeltaIssueYTD(invMbo, getDouble("quantity"), this);
    }
    if ((isReturn()) && (invcost != null))
    {
      cust.component.Logger.Log("updateInventory(antes)");
      //invMbo.updateInventoryAverageCost(getDouble("quantity"), Math.abs(getDouble("linecost")), 1.0D, invcost); ///AMB<======
      invcost.increaseAccumulativeReceiptQty(getDouble("quantity"));
      cust.component.Logger.Log("updateInventory(despues)");
    }
  }  
  
  public MboRemote getSharedInventory()
    throws MXException, RemoteException
  {
    MboRemote parent = getOwner();
    if ((parent != null) && (parent.getName().equals("INVENTORY"))) {
      return parent;
    }
    SqlFormat sqf = new SqlFormat(this, "itemnum = :itemnum and itemsetid = :itemsetid and location = :storeloc and siteid=:siteid");
    MboSetRemote invSet = ((MboSet)getThisMboSet()).getSharedMboSet("INVENTORY", sqf.format());
    if ((invSet == null) || (invSet.isEmpty())) {
      return null;
    }
    return invSet.getMbo(0);
  }
  
  public MboSetRemote getSharedAssetSet()
    throws MXException, RemoteException
  {
    MboRemote owner = getOwner();
    MboSetRemote assetSet = null;
    if (isReturn())
    {
      SqlFormat sqf = new SqlFormat(this, "assetnum = :rotassetnum and siteid=:tositeid");
      assetSet = ((MboSet)getThisMboSet()).getSharedMboSet("ASSET", sqf.format());
    }
    else if ((owner != null) && (owner.isBasedOn("INVUSE")))
    {
      assetSet = getMboSet("ROTASSET");
    }
    else
    {
      SqlFormat sqf = new SqlFormat(this, "assetnum = :rotassetnum and siteid=:siteid");
      assetSet = ((MboSet)getThisMboSet()).getSharedMboSet("ASSET", sqf.format());
    }
    if ((assetSet == null) || (assetSet.isEmpty())) {
      return null;
    }
    if (assetSet.getOwner() == null) {
      assetSet.setOwner(this);
    }
    return assetSet;
  }
  
  public MboRemote getSharedInvBalance()
    throws MXException, RemoteException
  {
    MboRemote owner = getOwner();
    InvBalances bal = null;
    
    String checkBinnum = getString("binnum");
    String checkLotnum = getString("lotnum");
    String conditionCode = getString("conditionCode");
    if ((owner != null) && (owner.getName().equals("INVENTORY")))
    {
      bal = ((Inventory)owner).getInvBalanceRecord(checkBinnum, checkLotnum, conditionCode);
    }
    else
    {
      MboRemote inventoryMbo = getSharedInventory();
      if (inventoryMbo == null) {
        return null;
      }
      bal = ((Inventory)inventoryMbo).getInvBalanceRecord(checkBinnum, checkLotnum, conditionCode);
    }
    return bal;
  }
  
  public MboRemote getInvBalancesRecord(MboRemote inventory)
    throws MXException, RemoteException
  {
    MboSetRemote invBalSet = inventory.getMboSet("INVBALANCES");
    int i = 0;
    MboRemote invBal = null;
    while ((invBal = invBalSet.getMbo(i)) != null)
    {
      if ((invBal.getString("itemnum").equals(getString("itemnum"))) && (invBal.getString("location").equals(getString("storeloc"))) && (invBal.getString("itemsetid").equals(getString("itemsetid"))) && (invBal.getString("binnum").equals(getString("binnum"))) && (invBal.getString("lotnum").equals(getString("lotnum"))) && (invBal.getString("conditioncode").equals(getString("conditioncode"))) && (invBal.getString("siteid").equals(getString("siteid")))) {
        return invBal;
      }
      i++;
    }
    return null;
  }
  
  private MboRemote getInvCostRecord(MboRemote inventory)
    throws MXException, RemoteException
  {
    MboSetRemote invcostSet = inventory.getMboSet("INVCOST");
    int i = 0;
    MboRemote invCost = null;
    while ((invCost = invcostSet.getMbo(i)) != null)
    {
      if ((invCost.getString("itemnum").equals(getString("itemnum"))) && (invCost.getString("location").equals(getString("storeloc"))) && (invCost.getString("itemsetid").equals(getString("itemsetid"))) && (invCost.getString("conditioncode").equals(getString("conditioncode"))) && (invCost.getString("siteid").equals(getString("siteid")))) {
        return invCost;
      }
      i++;
    }
    return null;
  }
  
private boolean isRotAssetReturnedToStore()
    throws MXException, RemoteException
  {
    return (isReturn()) && (!isNull("RotAssetNum")) && (!isNull("storeloc"));
  }
  
  private void updateInvBalances(InvBalances invBal)
    throws MXException, RemoteException
  {
    if (invBal.toBeAdded())
    {
      double newValue = invBal.getDouble("curbal") + getDouble("quantity");
      invBal.setValue("curbal", newValue, 2L);
    }
    else
    {
      MatUseTransSet owningSet = (MatUseTransSet)getThisMboSet();
      owningSet.addDeltaCurbal(invBal, getDouble("quantity"), this);
    }
  }
  
  public void setIgnoreLocationAssetMismatch(boolean value)
  {
    this.ignoreAssetLocMismatch = value;
  }
  
  public void setIgnoreLocationOccupied(boolean value)
  {
    this.ignoreLocOccupied = value;
  }
  
  public void setUpdateWorkOrdersOnMoveAsset(boolean value)
  {
    this.updateWO = value;
  }
  
  private void moveAsset()
    throws MXException, RemoteException
  {
    MboSetRemote rotAssetRecSet = getSharedAssetSet();
    
    this.rotAssetRec = ((AssetRemote)rotAssetRecSet.getMbo(0));
    if (this.rotAssetRec == null) {
      return;
    }
    Date moveDate = getDate("actualdate");
    this.rotAssetRec.setValue("movedby", getString("enterby"), 11L);
    

    String moveToLoc = "";
    if (isReturn())
    {
      moveToLoc = getString("storeloc");
      this.rotAssetRec.setValue("newsite", getString("siteid"), 11L);
      this.rotAssetRec.setValue("newlocation", moveToLoc, 11L);
      if (getString("siteid").equalsIgnoreCase(getString("tositeid"))) {
        this.rotAssetRec.setValue("binnum", getString("binnum"), 11L);
      }
    }
    else
    {
      moveToLoc = getString("location");
      
      this.rotAssetRec.setValue("newsite", getString("tositeid"), 11L);
      this.rotAssetRec.setValue("newlocation", moveToLoc, 11L);
    }
    if ((!isNull("itemnum")) && (!isReturn()) && (!this.rotAssetRec.getBoolean("mainthierchy")))
    {
      MboRemote item = getMboSet("ITEM").getMbo(0);
      if (item.getBoolean("attachonissue"))
      {
        String parent = null;
        if (isNull("assetnum"))
        {
          if (!isNull("wonum"))
          {
            MboRemote WO = getMboSet("WORKORDER").getMbo(0);
            if (!WO.isNull("assetnum")) {
              parent = WO.getString("assetnum");
            }
          }
        }
        else {
          parent = getString("assetnum");
        }
        if (parent != null) {
          try
          {
            this.rotAssetRec.setValue("newparent", parent, 2L);
          }
          catch (Exception e)
          {
            this.rotAssetRec.setValue("newparent", this.rotAssetRec.getString("parent"), 11L);
          }
        }
      }
    }
    this.rotAssetRec.issueAsset(moveToLoc, getString("memo"), moveDate, getString("wonum"), !this.ignoreAssetLocMismatch, !this.ignoreLocOccupied, this.updateWO, getString("matusetransid"));
    if (rotAssetRecSet.hasWarnings())
    {
      MboSet thisSet = (MboSet)getThisMboSet();
      thisSet.clearWarnings();
      MXException[] a = rotAssetRecSet.getWarnings();
      for (int i = 0; i < a.length; i++) {
        thisSet.addWarning(a[i]);
      }
    }
  }
  
private void updateWorkOrder()
    throws MXException, RemoteException
  {
    if (isNull("RefWO")) {
      return;
    }
    MboRemote wombo = null;
    
    MboRemote owner = getOwner();
    if ((owner != null) && ((owner instanceof WORemote))) {
      return;
    }
    MboRemote ownersOwner = null;
    if (owner != null) {
      ownersOwner = owner.getOwner();
    }
    if ((owner != null) && ((owner instanceof InventoryRemote)) && (ownersOwner != null) && ((ownersOwner instanceof WORemote)) && (wombo != null) && (wombo.getString("wonum").equalsIgnoreCase(getString("wonum")))) {
      wombo = ownersOwner;
    }
    if (wombo == null)
    {
      SqlFormat sqf = new SqlFormat(this, "wonum=:RefWO and siteid=:tositeid");
      MboSetRemote woset = ((MboSet)getThisMboSet()).getSharedMboSet("WORKORDER", sqf.format());
      


      wombo = woset.getMbo(0);
    }
    if (wombo != null)
    {
      IntegrationServiceRemote intserv = (IntegrationServiceRemote)((AppService)getMboServer()).getMXServer().lookup("INTEGRATION");
      boolean useIntegration = intserv.useIntegrationRules(getString("ownersysid"), wombo.getString("ownersysid"), "INVISSWO", getUserInfo());
      if ((!useIntegration) && (!this.workOrderUpdated))
      {
        if (isReturn()) {
          ((WORemote)wombo).incrActMatCost(Math.abs(getDouble("linecost")) * -1.0D, getBoolean("outside"));
        } else {
          ((WORemote)wombo).incrActMatCost(Math.abs(getDouble("linecost")), getBoolean("outside"));
        }
        setWorkOrderUpdatedFlag(true);
        if ((owner != null) && (owner.isBasedOn("InvUse"))) {
          ((WOSet)wombo.getThisMboSet()).skipappvalidate = true;
        }
      }
    }
  }
  
  private void updateInvReserve()
    throws MXException, RemoteException
  {
    if (isReturn()) {
      return;
    }
    MboRemote owner = getOwner();
    if ((owner != null) && ((owner instanceof InvReserveRemote)))
    {
      ((InvReserveRemote)owner).incrActualQty(Math.abs(getDouble("quantity")));
      return;
    }
    boolean useMR = (!getString("mrnum").equals("")) && (!getString("mrlinenum").equals(""));
    
    MboSetRemote invrSet = getSharedInvReserveSet();
    if (invrSet.isEmpty())
    {
      invrSet.reset();
      return;
    }
    if (useMR)
    {
      for (int x = 0;; x++)
      {
        InvReserveRemote invrMbo = (InvReserveRemote)invrSet.getMbo(x);
        if (invrMbo == null) {
          break;
        }
        if ((invrMbo.getString("mrnum").equals(getString("mrnum"))) && (invrMbo.getString("mrlinenum").equals(getString("mrlinenum"))))
        {
          MatUseTransSet matUseSet = (MatUseTransSet)getThisMboSet();
          Vector<InvReserveRemote> invResVector = matUseSet.getInvReserveVector();
          InvReserveRemote invResInVector = getInvReserveInVector(invResVector, invrMbo);
          if (invResInVector != null) {
            invrMbo = invResInVector;
          } else {
            invResVector.addElement(invrMbo);
          }
          invrMbo.incrActualQty(Math.abs(getDouble("quantity")));
          
          setInvReserveUpdatedFlag(true);
          break;
        }
      }
    }
    else
    {
      InvReserveRemote invrMbo = (InvReserveRemote)invrSet.getMbo(0);
      



      MatUseTransSet matUseSet = (MatUseTransSet)getThisMboSet();
      Vector<InvReserveRemote> invResVector = matUseSet.getInvReserveVector();
      InvReserveRemote invResInVector = getInvReserveInVector(invResVector, invrMbo);
      if (invResInVector != null) {
        invrMbo = invResInVector;
      } else {
        invResVector.addElement(invrMbo);
      }
      invrMbo.incrActualQty(Math.abs(getDouble("quantity")));
      
      setInvReserveUpdatedFlag(true);
    }
  }
  
  public MboSetRemote getSharedInvReserveSet()
    throws MXException, RemoteException
  {
    SqlFormat sqf = null;
    String requestNum = getString("requestnum");
    if ((!getString("mrnum").equals("")) && (!getString("mrlinenum").equals("")))
    {
      StringBuffer mrLineNum = new StringBuffer("(");
      StringBuffer mrNum = new StringBuffer("(");
      MboSetRemote thisMboSet = getThisMboSet();
      for (int x = 0;; x++)
      {
        MboRemote thisMbo = thisMboSet.getMbo(x);
        if (thisMbo == null) {
          break;
        }
        if ((!thisMbo.getString("mrnum").equals("")) || (!thisMbo.getString("mrlinenum").equals("")))
        {
          mrNum.append("'");
          mrLineNum.append(thisMbo.getInt("mrlinenum"));
          mrNum.append(thisMbo.getString("mrnum"));
          
          mrLineNum.append(",");
          mrNum.append("',");
        }
      }
      String mrString = mrNum.toString();
      String mrLineString = mrLineNum.toString();
      if (mrString.charAt(mrString.length() - 1) == ',') {
        mrString = mrString.substring(0, mrString.length() - 1) + ")";
      }
      if (mrLineString.charAt(mrLineString.length() - 1) == ',') {
        mrLineString = mrLineString.substring(0, mrLineString.length() - 1) + ")";
      }
      sqf = new SqlFormat(this, "mrnum in " + mrString + " and mrlinenum in " + mrLineString);
    }
    else if ((!isNull("itemnum")) && ((requestNum == null) || (requestNum.equals(""))))
    {
      StringBuffer where = new StringBuffer("");
      if (!isNull("mrnum"))
      {
        where.append(" and mrnum = :mrnum");
        if (isNull("mrlinenum")) {
          where.append(" and mrlinenum is null");
        } else {
          where.append(" and mrlinenum = :mrlinenum");
        }
      }
      else if (!isNull("ponum"))
      {
        where.append(" and ponum=:ponum");
        if (isNull("polinenum")) {
          where.append(" and polinenum is null");
        } else {
          where.append(" and polinenum=:polinenum");
        }
      }
      else if (!isNull("refwo"))
      {
        where.append(" and wonum = :refwo");
        if (!isNull("assetnum")) {
          where.append(" and assetnum = :assetnum");
        }
      }
      else if (!isNull("assetnum"))
      {
        where.append(" and assetnum = :assetnum and wonum is null");
      }
      if (where.toString().equals("")) {
        where.append(" and 1=2 ");
      }
      sqf = new SqlFormat(this, "itemnum=:itemnum and location=:storeloc and storelocsiteid=:tositeid" + where.toString());
    }
    else
    {
      sqf = new SqlFormat(this, "requestnum = :1");
      sqf.setObject(1, "INVRESERVE", "REQUESTNUM", requestNum);
    }
    String whereClause = sqf.format();
    
    MboSetRemote invrSet = ((MboSet)getThisMboSet()).getSharedMboSet("INVRESERVE", whereClause);
    
    return invrSet;
  }
  
  private void updateAssetSparePart()
    throws MXException, RemoteException
  {
    ItemRemote itemMbo = (ItemRemote)getMboSet("ITEM").getMbo(0);
    if (itemMbo == null) {
      return;
    }
    String assetnum = getString("assetnum");
    String siteid = getString("tositeid");
    String itemnum = getString("itemnum");
    String itemsetid = getString("itemsetid");
    if ((!itemMbo.canSparePartAutoAdd()) && (!itemMbo.sparePartExists(assetnum, siteid))) {
      return;
    }
    MatUseTransSet matUseSet = (MatUseTransSet)getThisMboSet();
    if (matUseSet.sparePartExistsInHashTable(assetnum + siteid, itemnum)) {
      return;
    }
    if (itemMbo.sparePartExists(assetnum, siteid))
    {
      MboRemote sparePart = getSparePart(itemnum, itemsetid, assetnum, siteid);
      if (sparePart != null)
      {
        double currentIssuedQty = sparePart.getDouble("issuedqty");
        double matUseIssuedQty = getDouble("quantity");
        double newIssuedQty = currentIssuedQty - matUseIssuedQty;
        if (newIssuedQty < 0.0D) {
          newIssuedQty = 0.0D;
        }
        sparePart.setValue("issuedqty", newIssuedQty, 11L);
      }
      return;
    }
    itemMbo.addSparePart(assetnum, siteid);
    



    matUseSet.storeNewSparePartKeys(assetnum + siteid, itemnum);
    



    setValue("sparepartadded", true, 2L);
  }
  
  private void handleMeterReadingOnIssue()
    throws MXException, RemoteException
  {
    if ((toBeAdded()) && (isIssue()))
    {
      ItemRemote item = (ItemRemote)getMboSet("ITEM").getMbo(0);
      if ((isNull("rotassetnum")) && (!item.isNull("metername")))
      {
        DeployedMeterRemote dmr = null;
        boolean meterreadingEntered = false;
        if (!isNull("ASSETNUM"))
        {
          SqlFormat assetmeter = new SqlFormat(this, "assetnum = :assetnum and metername = :1 and orgid = :orgid and siteid=:tositeid");
          assetmeter.setObject(1, "ASSETMETER", "METERNAME", item.getString("metername"));
          dmr = (DeployedMeterRemote)getMboSet("$assetMeterForItem", "ASSETMETER", assetmeter.format()).getMbo(0);
          if (dmr != null) {
            meterreadingEntered = dmr.enterReadingOnMaterialIssue();
          }
        }
        if ((!isNull("LOCATION")) && (!meterreadingEntered))
        {
          SqlFormat locationmeter = new SqlFormat(this, "location = :location and metername = :1 and orgid = :orgid and siteid=:tositeid");
          locationmeter.setObject(1, "LOCATIONMETER", "METERNAME", item.getString("metername"));
          dmr = (DeployedMeterRemote)getMboSet("$locationMeterForItem", "LOCATIONMETER", locationmeter.format()).getMbo(0);
          if (dmr != null) {
            dmr.enterReadingOnMaterialIssue();
          }
        }
      }
    }
  }
  
  public boolean canBeReturned()
    throws MXException, RemoteException
  {
    if (!isNull("rotassetnum"))
    {
      MboSetRemote rotAssetSet = getMboSet("ROTASSET");
      if (rotAssetSet.isEmpty())
      {
        rotAssetSet.reset();
        return false;
      }
      String curLocation = rotAssetSet.getMbo(0).getString("location");
      if (curLocation.equals(getString("location")))
      {
        rotAssetSet.reset();
        return true;
      }
    }
    return true;
  }
  
  public MboRemote returnIssue(String bin, String lot, double qty)
    throws MXException, RemoteException
  {
    MboRemote matReturn = returnIssue();
    matReturn.setValue("quantity", qty, 2L);
    matReturn.setValue("binnum", bin, 2L);
    matReturn.setValue("lotnum", lot, 2L);
    return matReturn;
  }
  
  public MboRemote returnIssue()
    throws MXException, RemoteException
  {
    return returnIssue(getThisMboSet());
  }
  
  public MboRemote returnIssue(MboSetRemote newMatUseSet)
    throws MXException, RemoteException
  {
    if (isReturn()) {
      throw new MXApplicationException("inventory", "returnOnlyIssues");
    }
    IntegrationServiceRemote intserv = (IntegrationServiceRemote)((AppService)getMboServer()).getMXServer().lookup("INTEGRATION");
    InventoryRemote invMbo = (InventoryRemote)getSharedInventory();
    if (invMbo == null) {
      throw new MXApplicationException("inventory", "invbalNotInInventory");
    }
    boolean useIntegration = intserv.useIntegrationRules(getString("ownersysid"), invMbo.getString("ownersysid"), "INVISSR", getUserInfo());
    if (useIntegration) {
      throw new MXApplicationException("inventory", "mxcollabINVISSR");
    }
    if (!canBeReturned()) {
      throw new MXApplicationException("inventory", "cannotReturnIssue");
    }
    if (Math.abs(this.remainQty + 1.11D) < 1.0E-007D)
    {
      this.totalQty = getTotalQtyForReturn();
      this.remainQty = this.totalQty;
    }
    if (this.remainQty <= 0.0D) {
      throw new MXApplicationException("inventory", "cannotreturnanymore");
    }
    MatUseTransRemote rtn = (MatUseTransRemote)newMatUseSet.add();
    try
    {
      rtn.setIssueForThisReturn(this);

      rtn.setTotalQtyForThisReturn(this.totalQty);
      rtn.setValue("issueid", getLong("matusetransid"), 2L);
      rtn.setValue("ISSUETYPE", getTranslator().toExternalDefaultValue("ISSUETYP", "RETURN", this), 11L);
      rtn.setValue("POSITIVEQUANTITY", this.remainQty, 11L);
      rtn.setValue("QUANTITY", this.remainQty, 2L);
      
      this.remainQty = 0.0D;
      ((MatUseTrans)rtn).selectItemForReturn = true;
      
      rtn.setValue("ITEMNUM", getString("ITEMNUM"), 2L);
      rtn.setValue("itemsetid", getString("itemsetid"), 2L);
      rtn.setValue("LOCATION", getString("LOCATION"), 11L);
      rtn.setValue("ROTASSETNUM", getString("ROTASSETNUM"), 3L);
      rtn.setValue("tositeid", getString("tositeid"), 11L);
      rtn.setValue("conditioncode", getString("conditioncode"), 11L);
      rtn.setValue("condrate", getString("condrate"), 11L);
      rtn.setValue("STORELOC", getString("STORELOC"), 11L);
      rtn.setValue("BINNUM", getString("BINNUM"), 11L);
      rtn.setValue("LOTNUM", getString("LOTNUM"), 11L);
      rtn.setValue("PONUM", getString("PONUM"), 11L);
      rtn.setValue("CONVERSION", getDouble("CONVERSION"), 2L);
      rtn.setValue("MRNUM", getString("MRNUM"), 11L);
      rtn.setValue("MRLINENUM", getString("MRLINENUM"), 11L);
      rtn.setValue("WONUM", getString("WONUM"), 2L);
      rtn.setValue("FINCNTRLID", getString("FINCNTRLID"), 11L);
      rtn.setValue("ASSETNUM", getString("ASSETNUM"), 11L);
      rtn.setValue("OUTSIDE", getString("OUTSIDE"), 11L);
      rtn.setValue("TASKID", getString("TASKID"), 11L);
      rtn.setValue("REFWO", getString("REFWO"), 11L);
      rtn.setValue("PACKINGSLIPNUM", getString("PACKINGSLIPNUM"), 11L);
      rtn.setValue("POLINENUM", getString("POLINENUM"), 11L);
      rtn.setValue("DESCRIPTION", getString("DESCRIPTION"), 11L);
      rtn.setValue("CURRENCYCODE", getString("CURRENCYCODE"), 2L);
      if (!isNull("CURRENCYUNITCOST")) {
        rtn.setValue("CURRENCYUNITCOST", getDouble("CURRENCYUNITCOST"), 11L);
      }
      rtn.setValue("SPAREPARTADDED", getString("SPAREPARTADDED"), 11L);
      rtn.setValue("QTYREQUESTED", getString("QTYREQUESTED"), 11L);
      rtn.setValue("GLDEBITACCT", getString("GLDEBITACCT"), 11L);
      rtn.setValue("GLCREDITACCT", getString("GLCREDITACCT"), 11L);
      rtn.setValue("UNITCOST", getString("UNITCOST"), 2L);
      rtn.setValue("UNITCOST", 44, 2L);
      rtn.setValue("ACTUALCOST", getString("ACTUALCOST"), 11L);
      rtn.setValue("ACTUALCOST", 44, 11L);
      rtn.setValue("MEMO", getString("MEMO"), 11L);
      rtn.setValue("IT1", getString("IT1"), 3L);
      rtn.setValue("IT2", getString("IT2"), 3L);
      rtn.setValue("IT3", getString("IT3"), 3L);
      rtn.setValue("IT4", getString("IT4"), 3L);
      rtn.setValue("IT5", getString("IT5"), 3L);
      rtn.setValue("IT6", getString("IT6"), 3L);
      rtn.setValue("IT7", getString("IT7"), 3L);
      rtn.setValue("IT8", getString("IT8"), 3L);
      rtn.setValue("IT9", getString("IT9"), 3L);
      rtn.setValue("IT10", getString("IT10"), 3L);
      rtn.setValue("ISSUETO", getString("ISSUETO"), 11L);

      String[] edits = { "POSITIVEQUANTITY", "BINNUM", "UNITCOST", "CURRENCYUNITCOST", "ACTUALDATE", "MEMO", "ISSUETYPE" };

      ((MatUseTrans)rtn).selectItemForReturn = true;

      MboSetInfo msi = getMboSetInfo();
      Map attrsOrig = msi.getAttributeDetails();
      Iterator i3 = attrsOrig.values().iterator();
      while (i3.hasNext())
      {
        MboValueInfo mvi = (MboValueInfo)i3.next();
        if (!mvi.isUserdefined())
        {
          if (!Arrays.asList(edits).contains(mvi.getAttributeName())) {
            rtn.setFieldFlag(mvi.getAttributeName().toLowerCase(), 7L, true);
          }
        }
        else
        {
          String attrName = mvi.getName();
          if ((attrName != null) && (!attrName.equals(""))) {
            rtn.setValue(attrName, getString(attrName), 66L);
          }
        }
      }
    }
    catch (MXException m)
    {
      rtn.delete();
      
      rtn.getThisMboSet().remove();
      
      setValue("QTYRETURNED", getMboValue("QTYRETURNED").getPreviousValue().asDouble(), 2L);
      setValueNull("ISSUEID", 2L);
      
      throw m;
    }
    catch (RemoteException r)
    {
      rtn.delete();
      
      rtn.getThisMboSet().remove();
      
      setValue("QTYRETURNED", getMboValue("QTYRETURNED").getPreviousValue().asDouble(), 2L);
      setValueNull("ISSUEID", 2L);
      
      throw r;
    }
    return rtn;
  }
  
  public void setIssueForThisReturn(MboRemote issue)
    throws MXException, RemoteException
  {
    this.issueMbo = issue;
  }
  
  public void setRotatingAssetnum(String rotAssetnum)
    throws MXException, RemoteException
  {
    if (!((ItemRemote)getMboSet("ITEM").getMbo(0)).isRotating()) {
      throw new MXApplicationException("inventory", "matusetransItemNotRotating");
    }
    setValue("rotassetnum", rotAssetnum, 2L);
  }
  
  void updateGlAccounts()
    throws MXException, RemoteException
  {
    TransactionGLMerger glm = new TransactionGLMerger(this);
    glm.setMRInfo(getString("mrnum"), getString("mrlinenum"));
    glm.setItem(getString("itemnum"));
    glm.setItemSetID(getString("itemsetid"));
    
    glm.setConditionCode(getString("conditioncode"));
    

    MboRemote owner = getOwner();
    if ((owner == null) || (!(owner instanceof WORemote)) || (!getString("wonum").equals(owner.getString("wonum")))) {
      glm.setWonum(getString("wonum"));
    } else {
      glm.setWO(owner);
    }
    glm.setAssetnum(getString("assetnum"));
    glm.setLocation(getString("location"));
    glm.setStoreLoc(getString("storeloc"));
    if (!isNull("gldebitacct")) {
      setValue("gldebitacct", glm.mergedGL(getTopGL(glm), getString("gldebitacct")), 11L);
    } else {
      setValue("gldebitacct", glm.getMergedDebitGLAccount(), 11L);
    }
  }
  
  private String getTopGL(TransactionGLMerger glm)
    throws MXException, RemoteException
  {
    String topGl = null;
    if (!isNull("itemnum")) {
      if (isNull("storeloc")) {
        topGl = glm.getItemResourceAccount();
      } else {
        topGl = glm.getInventoryGLAccount();
      }
    }
    return topGl;
  }
  
  public boolean isReturn()
    throws MXException, RemoteException
  {
    if (isNull("ISSUETYPE")) {
      return false;
    }
    return getTranslator().toInternalString("ISSUETYP", getString("ISSUETYPE")).equalsIgnoreCase("RETURN");
  }
  
  public boolean isIssue()
    throws MXException, RemoteException
  {
    if (isNull("ISSUETYPE")) {
      return false;
    }
    return getTranslator().toInternalString("ISSUETYP", getString("ISSUETYPE")).equalsIgnoreCase("ISSUE");
  }
  
  protected boolean isKitMake()
    throws MXException, RemoteException
  {
    Translate tr = getTranslator();
    if (isNull("ISSUETYPE")) {
      return false;
    }
    return tr.toInternalString("ISSUETYP", getString("issuetype")).equalsIgnoreCase("KITMAKE");
  }
  
  protected boolean isKitBreak()
    throws MXException, RemoteException
  {
    Translate tr = getTranslator();
    if (isNull("ISSUETYPE")) {
      return false;
    }
    return tr.toInternalString("ISSUETYP", getString("issuetype")).equalsIgnoreCase("KITBREAK");
  }
  
  protected boolean isKitting()
    throws MXException, RemoteException
  {
    if (isNull("ISSUETYPE")) {
      return false;
    }
    return (isKitMake()) || (isKitBreak());
  }
  
  public String[] getValidateOrder()
  {
    return new String[] { "UnitCost", "ActualDate", "ItemNum", "RotAssetnum", "Storeloc", "WoNum", "Location", "Assetnum", "Quantity" };
  }
  
  boolean hasIssueTypeChanged()
    throws MXException, RemoteException
  {
    return this.issueTypeHasChanged;
  }
  
  void setIssueTypeChange(boolean changed)
    throws MXException, RemoteException
  {
    this.issueTypeHasChanged = changed;
  }
  
  private boolean issueTypeHasChanged = false;
  private boolean ignoreAssetLocMismatch = true;
  private boolean ignoreLocOccupied = true;
  private boolean updateWO = true;
  private AssetRemote rotAssetRec = null;
  
  public void delete(long accessModifier)
    throws MXException, RemoteException
  {
    super.delete(accessModifier);
    MboRemote owner = getOwner();
    if ((owner != null) && ((owner instanceof WORemote)))
    {
      WORemote refWO = ((WORemote)owner).getWoFromCombined(getMboValue("RefWO").getString());
      if (isReturn()) {
        refWO.incrActMatCost(Math.abs(getDouble("LineCost")), getBoolean("Outside"));
      } else {
        refWO.incrActMatCost(-1.0D * getDouble("LineCost"), getBoolean("Outside"));
      }
    }
    MboRemote inv = getSharedInventory();
    if (inv != null) {
      inv.getThisMboSet().reset();
    }
    MboRemote invBal = getSharedInvBalance();
    if (invBal != null) {
      invBal.getThisMboSet().reset();
    }
    if ((owner != null) && ((owner instanceof LocationRemote)) && (isReturn()) && (this.issueMbo != null))
    {
      this.returnQtyDeleted = this.issueMbo.getDouble("QTYRETURNED");
      this.issueMbo.setValue("QTYRETURNED", this.issueMbo.getMboInitialValue("QTYRETURNED").asDouble(), 11L);
    }
  }
  
  public void undelete()
    throws MXException, RemoteException
  {
    MboRemote owner = getOwner();
    if ((owner != null) && ((owner instanceof WORemote)))
    {
      WORemote refWO = ((WORemote)owner).getWoFromCombined(getMboValue("RefWO").getString());
      if (isReturn()) {
        refWO.incrActMatCost(-1.0D * getDouble("LineCost"), getBoolean("Outside"));
      } else {
        refWO.incrActMatCost(getDouble("LineCost"), getBoolean("Outside"));
      }
    }
    if ((owner != null) && ((owner instanceof LocationRemote)) && (isReturn()) && (this.issueMbo != null)) {
      this.issueMbo.setValue("QTYRETURNED", this.returnQtyDeleted, 11L);
    }
    super.undelete();
  }
  
  double getDefaultIssueCost()
    throws MXException, RemoteException
  {
    double issueCost = 0.0D;
    if ((!isNull("itemnum")) && (!isNull("storeloc")))
    {
      String conditionCode = getString("conditioncode");
      
      Inventory inventory = (Inventory)getMboSet("INVENTORY").getMbo(0);
      if (inventory != null)
      {
        MboRemote invcost = inventory.getInvCostRecord(conditionCode);
        if ((isIssue()) || (invcost != null))
        {
          if (!isNull("rotassetnum"))
          {
            AssetRemote rotAsset = (AssetRemote)getMboSet("ROTATINGASSET").getMbo(0);
            issueCost = inventory.getDefaultIssueCost(rotAsset, conditionCode);
          }
          else
          {
            issueCost = inventory.getDefaultIssueCost(conditionCode);
          }
        }
        else
        {
          double fullIssueCost = inventory.getDefaultIssueCost();
          
          MboRemote itemcond = getMboSet("ITEMCONDITION").getMbo(0);
          
          double condrate = itemcond.getDouble("condrate");
          
          issueCost = fullIssueCost * (condrate / 100.0D);
          setValue("condrate", condrate, 11L);
        }
      }
    }
    return issueCost;
  }
  
  private void checkForNegativeBalance()
    throws MXException, RemoteException
  {
    MboRemote owner = getOwner();
    double sumQuantity = 0.0D;
    if ((toBeAdded()) && (isIssue()) && (owner != null) && (!(owner instanceof MatRecTransRemote)))
    {
      MboRemote inventory = getSharedInventory();
      if (inventory == null) {
        return;
      }
      MboRemote invBal = getSharedInvBalance();
      if (invBal == null) {
        return;
      }
      IntegrationServiceRemote intserv = (IntegrationServiceRemote)((AppService)getMboServer()).getMXServer().lookup("INTEGRATION");
      boolean useIntegration = intserv.useIntegrationRules(getString("ownersysid"), inventory.getString("ownersysid"), "INV", getUserInfo());
      if (useIntegration) {
        return;
      }
      InventoryService intServ = (InventoryService)((AppService)getMboServer()).getMXServer().lookup("INVENTORY");
      
      double avblQty = inventory.getDouble("avblBalance");
      if (avblQty < Math.abs(getDouble("quantity"))) {
        if (!isNull("requestnum"))
        {
          double reservedQty = getDouble("RESERVEDQTY");
          double curBal = invBal.getDouble("curbal");
          if ((curBal >= reservedQty) || (curBal >= Math.abs(getDouble("quantity")))) {
            avblQty = curBal;
          }
        }
        else
        {
          MboSetRemote invresSet = getSharedInvReserveSet();
          if (!invresSet.isEmpty())
          {
            double sumReservedQty = invresSet.sum("reservedqty");
            
            avblQty += sumReservedQty;
          }
        }
      }
      MboSetRemote matUseTransSet = getThisMboSet();
      for (int i = 0;; i++)
      {
        MatUseTrans matUseTrans = (MatUseTrans)matUseTransSet.getMbo(i);
        if (matUseTrans == null) {
          break;
        }
        if ((matUseTrans.toBeAdded()) && (!matUseTrans.toBeDeleted()) && (matUseTrans.isIssue())) {
          if ((getString("itemnum").equals(matUseTrans.getString("itemnum"))) && (getString("binnum").equals(matUseTrans.getString("binnum"))) && (getString("lotnum").equals(matUseTrans.getString("lotnum")))) {
            sumQuantity += Math.abs(matUseTrans.getDouble("quantity"));
          }
        }
      }
      intServ.canGoNegative(getUserInfo(), sumQuantity, invBal.getDouble("curbal"), avblQty, this);
    }
  }
  
  private MboRemote getSparePart(String itemnum, String itemsetid, String assetnum, String siteid)
    throws MXException, RemoteException
  {
    MboRemote sparePartMbo = null;
    SqlFormat sqf = new SqlFormat(this, "itemnum = :1 and assetnum = :2 and itemsetid = :3 and siteid =:4");
    sqf.setObject(1, "SPAREPART", "itemnum", itemnum);
    sqf.setObject(2, "SPAREPART", "assetnum", assetnum);
    sqf.setObject(3, "SPAREPART", "itemsetid", itemsetid);
    sqf.setObject(4, "SPAREPART", "siteid", siteid);
    
    MboSetRemote spSet = ((MboSet)getThisMboSet()).getSharedMboSet("SPAREPART", sqf.format());
    if (!spSet.isEmpty()) {
      return spSet.getMbo(0);
    }
    return sparePartMbo;
  }
  
  public boolean isUncommitted()
  {
    return this.uncommitted;
  }
  
  public void setUncommitted(boolean uncommitted)
  {
    this.uncommitted = uncommitted;
  }
  
  public void setSharedInvBalancesUpdatedFlag(boolean updated)
  {
    this.sharedInvBalancesHasBeenUpdated = updated;
  }
  
  public void setInvReserveUpdatedFlag(boolean updated)
  {
    this.invReserveUpdated = updated;
  }
  
  public void setCheckNegBalanceFlag(boolean flag)
    throws MXException, RemoteException
  {
    this.checkNegBalance = flag;
  }
  
  boolean getCheckNegBalanceFlag()
    throws MXException, RemoteException
  {
    return this.checkNegBalance;
  }
  
  public void createMatUseTransRecordforLifoFifo(MboRemote inv)
    throws MXException, RemoteException
  {
    if (isReturn()) {
      return;
    }
    MboRemote invlifofifocost = null;
    double qty = getDouble("positivequantity");
    String conditionCode = getString("conditionCode");
    MboSetRemote invlifofifocostset = ((Inventory)inv).getInvLifoFifoCostRecordSetSorted(conditionCode);
    if (invlifofifocostset.isEmpty()) {
      throw new MXApplicationException("inventory", "missingQuantity");
    }
    int i = 0;
    MatUseTrans newMatMbo = this;
    newMatMbo.setValue("split", true, 2L);
    while ((invlifofifocost = invlifofifocostset.getMbo(i)) != null) {
      if (invlifofifocost.getDouble("quantity") == 0.0D)
      {
        i++;
      }
      else
      {
        if (invlifofifocost.getDouble("quantity") == qty)
        {
          newMatMbo.setValue("positivequantity", invlifofifocost.getDouble("quantity"), 2L);
          newMatMbo.setValue("unitcost", invlifofifocost.getDouble("unitcost"), 2L);
          invlifofifocost.setValue("quantity", 0, 11L);
          break;
        }
        if (invlifofifocost.getDouble("quantity") > qty)
        {
          newMatMbo.setValue("positivequantity", qty, 2L);
          newMatMbo.setValue("unitcost", invlifofifocost.getDouble("unitcost"), 2L);
          qty = MXMath.subtract(invlifofifocost.getDouble("quantity"), qty);
          invlifofifocost.setValue("quantity", qty, 11L);
          break;
        }
        newMatMbo.setValue("positivequantity", invlifofifocost.getDouble("quantity"), 2L);
        newMatMbo.setValue("unitcost", invlifofifocost.getDouble("unitcost"), 2L);
        qty = MXMath.subtract(qty, invlifofifocost.getDouble("quantity"));
        invlifofifocost.setValue("quantity", 0, 11L);
        

        newMatMbo = (MatUseTrans)newMatMbo.copy();
        
        i++;
      }
    }
  }
  
  boolean workOrderUpdated = false;
  
  public void setWorkOrderUpdatedFlag(boolean updated)
  {
    this.workOrderUpdated = updated;
  }
  
  public InvReserveRemote getInvReserveInVector(Vector v, MboRemote thisInvReserve)
    throws MXException, RemoteException
  {
    String requestnum = thisInvReserve.getString("requestnum");
    for (int i = 0; i < v.size(); i++)
    {
      Object obj = v.elementAt(i);
      InvReserveRemote inv = (InvReserveRemote)obj;
      if (inv.getString("requestnum").equals(requestnum)) {
        return inv;
      }
    }
    return null;
  }

}
