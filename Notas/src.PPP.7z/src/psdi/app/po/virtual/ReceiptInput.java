package psdi.app.po.virtual;

import psdi.app.common.receipt.ReceiptMbo;
import psdi.server.MXServer;
import psdi.mbo.SqlFormat;
import psdi.util.MXApplicationException;
import psdi.app.inventory.MatRecTransRemote;
import psdi.app.labor.ServRecTransRemote;
import psdi.app.common.receipt.ReceiptMboRemote;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import java.rmi.RemoteException;
import psdi.mbo.MboSet;
import psdi.util.MXException;
import psdi.app.po.ShipmentRemote;
import psdi.app.po.ShipmentLineRemote;
import psdi.app.po.POLineSetRemote;
import psdi.app.mr.MRRemote;
import psdi.app.po.POLineRemote;
import psdi.app.po.PORemote;
import psdi.mbo.NonPersistentMbo;

public class ReceiptInput extends NonPersistentMbo implements ReceiptInputRemote
{
    private PORemote passedInPO;
    private POLineRemote passedInPOLine;
    private MRRemote passedInMR;
    private POLineSetRemote passedInPOLineSet;
    private ShipmentLineRemote passedInShipmentLine;
    private ShipmentRemote passedInShipment;
    public String rotAssetNum;
    private boolean failed;
    private Double prevValue;
    
    @Override
    public void init() throws MXException {
    }
    
    public ReceiptInput(final MboSet ms) throws MXException, RemoteException {
        super(ms);
        this.passedInPO = null;
        this.passedInPOLine = null;
        this.passedInMR = null;
        this.passedInPOLineSet = null;
        this.passedInShipmentLine = null;
        this.passedInShipment = null;
        this.rotAssetNum = null;
        this.failed = false;
        this.prevValue = 0.0;
    }
    
    @Override
    public MboRemote createReceipt(final MboSetRemote targetSet) throws MXException, RemoteException {
    	cust.component.Logger.Log("ReceiptInput.createReceipt.ENTER");
        final MboRemote newReceipt = targetSet.addAtEnd();
        try {
            ((ReceiptMboRemote)newReceipt).setPOMbo(this.passedInPO);
            ((ReceiptMboRemote)newReceipt).setPOLineMbo(this.passedInPOLine);
            ((ReceiptMboRemote)newReceipt).setMRMbo(this.passedInMR);
            ((ReceiptMboRemote)newReceipt).setPOLineSet(this.passedInPOLineSet);
            newReceipt.setValue("ponum", this.getString("ponum"), 2L);
            newReceipt.setValue("polinenum", this.getString("polinenum"), 2L);
            newReceipt.setValue("orderqty", this.getDouble("orderqty"), 11L);
            newReceipt.setValue("invoicenum", this.getString("invoicenum"), 11L);
            if (!this.isNull("remark")) {
                newReceipt.setValue("remark", this.getString("remark"), 2L);
            }
            if (newReceipt instanceof ServRecTransRemote) {
                final double exchangeRate2 = newReceipt.getDouble("exchangerate2");
                if (exchangeRate2 != 0.0) {
                    newReceipt.setValue("linecost2", exchangeRate2 * newReceipt.getDouble("currencyLineCost"), 11L);
                }
            }
            final double exchangeRate2 = newReceipt.getDouble("exchangerate");
            if (newReceipt instanceof MatRecTransRemote) {
                newReceipt.setValue("receiptquantity", this.getDouble("qtyrequested"), 2L);
                if (this.getMboValue("qtyrequested").isModified() && this.getMboValue("qtyrequested").getPreviousValue().asDouble() != 0.0) {
                    newReceipt.setValue("qtyrequested", this.getMboValue("qtyrequested").getPreviousValue().asDouble(), 2L);
                }
                else {
                    newReceipt.setValue("qtyrequested", this.getDouble("qtyrequested"), 2L);
                }
                if (this.failed) {
                    newReceipt.setValue("qtyrequested", this.prevValue, 2L);
                }
                newReceipt.setValue("qtyalreadyrecvd", this.getDouble("receivedqty"), 11L);
                newReceipt.setValue("asn", this.getString("asn"), 2L);
                if (!this.getString("packingslipnum").equals("")) {
                    newReceipt.setValue("packingslipnum", this.getString("packingslipnum"), 2L);
                }
                if (this.passedInShipmentLine != null) {
                    this.passedInShipmentLine.setValue("rectransid", newReceipt.getLong("matrectransid"), 11L);
                }
                if (this.getTranslator().toInternalString("linetype", newReceipt.getString("linetype")).equalsIgnoreCase("TOOL") && newReceipt.getBoolean("issue") && !this.getTranslator().toInternalString("ISSUETYP", newReceipt.getString("issuetype")).equalsIgnoreCase("RETURN")) {
                    newReceipt.setFieldFlag("issueto", 128L, true);
                }
                else {
                    newReceipt.setFieldFlag("issueto", 128L, false);
                }
                newReceipt.setValue("inspectedqty", 0, 2L);
                if (!this.isNull("assetnum")) {
                    newReceipt.setValue("assetnum", this.getString("assetnum"), 11L);
                }
                else if (this.getMboValue("assetnum").isFlagSet(7L)) {
                    newReceipt.setFieldFlag("assetnum", 7L, true);
                }
                if (this.passedInPO.getBoolean("internal") && !this.passedInPO.getString("storelocsiteid").equalsIgnoreCase(this.passedInPOLine.getString("tositeid")) && (this.passedInPOLine.getBoolean("inspectionrequired") || this.passedInPOLine.getMboSet("ITEM").getMbo(0).getBoolean("rotating"))) {
                    newReceipt.setValue("issuetype", "!RECEIPT!", 11L);
                    newReceipt.setValue("glcreditacct", ((MatRecTransRemote)newReceipt).getClearingAcct().getString("clearingacct"), 11L);
                    newReceipt.setFieldFlag("rotassetnum", 128L, false);
                    newReceipt.setValue("receiptref", this.getLong("matrectransid"), 11L);
                    newReceipt.setValue("rotassetnum", this.rotAssetNum, 11L);
                }
            }
            if (newReceipt instanceof ServRecTransRemote) {
                newReceipt.setValue("QtyAlreadyRecvd", this.getDouble("receivedqty"), 11L);
                if (this.isNull("orderqty")) {
                    newReceipt.setValue("amttoreceive", this.getDouble("currencyamttorcv") * exchangeRate2, 11L);
                    newReceipt.setFieldFlag("qtytoreceive", 7L, true);
                }
                else {
                    newReceipt.setValue("qtytoreceive", this.getDouble("qtyrequested"), 2L);
                    newReceipt.setFieldFlag("amttoreceive", 7L, true);
                    newReceipt.setFieldFlag("percentage", 7L, true);
                }
                if (!this.isNull("orderqty")) {
                    newReceipt.setValue("inspectedqty", 0, 2L);
                    newReceipt.setValue("rejectqty", 0, 2L);
                }
                else if (this.isNull("orderqty")) {
                    newReceipt.setValue("inspectioncost", this.getDouble("currencyamttorcv"), 2L);
                }
                newReceipt.setValue("acceptedcost", 0, 2L);
                newReceipt.setValue("rejectcost", 0, 2L);
            }
        }
        catch (MXApplicationException e) {
        	cust.component.Logger.Log("ReceiptInput.createReceipt.EXCEPTION");
            targetSet.remove(newReceipt);
            this.failed = true;
            this.prevValue = this.getMboValue("qtyrequested").getPreviousValue().asDouble();
            throw e;
        }
    	cust.component.Logger.Log("ReceiptInput.createReceipt.EXIT");
        return newReceipt;
    }
    
    @Override
    public MboRemote createShipmentReceipt(final MboSetRemote targetSet) throws MXException, RemoteException {
        final MboRemote newReceipt = targetSet.addAtEnd();
        try {
            ((ReceiptMboRemote)newReceipt).setPOMbo(this.passedInPO);
            ((ReceiptMboRemote)newReceipt).setPOLineMbo(this.passedInPOLine);
            ((ReceiptMboRemote)newReceipt).setMRMbo(this.passedInMR);
            ((ReceiptMboRemote)newReceipt).setPOLineSet(this.passedInPOLineSet);
            newReceipt.setValue("issuetype", "!SHIPRECEIPT!", 11L);
            final SqlFormat sqf = new SqlFormat(this, "shipmentlineid =:1");
            sqf.setLong(1, this.getLong("shipmentlineid"));
            final MboSetRemote shipmentLineSet = this.getMboSet("$getShipmentLine", "SHIPMENTLINE", sqf.format());
            final MboRemote shipmentLineRemote = shipmentLineSet.getMbo(0);
            final MboRemote invuseLineSplitRemote = shipmentLineRemote.getMboSet("INVUSELINESPLIT").getMbo(0);
            newReceipt.setValue("ponum", this.getString("ponum"), 2L);
            newReceipt.setValue("shipmentlinenum", shipmentLineRemote.getString("shipmentlinenum"), 2L);
            newReceipt.setValue("polinenum", this.getString("polinenum"), 2L);
            newReceipt.setValue("itemsetid", this.getString("itemsetid"), 11L);
            newReceipt.setValue("description", this.getString("description"), 11L);
            newReceipt.setValue("orderqty", this.getDouble("orderqty"), 11L);
            newReceipt.setValue("invoicenum", this.getString("invoicenum"), 11L);
            if (!this.isNull("remark")) {
                newReceipt.setValue("remark", this.getString("remark"), 2L);
            }
            newReceipt.setValue("receiptquantity", this.getDouble("qtyrequested"), 2L);
            if (!invuseLineSplitRemote.isNull("rotassetnum")) {
                newReceipt.setFieldFlag("receiptquantity", 7L, true);
            }
            if (this.getMboValue("qtyrequested").isModified() && this.getMboValue("qtyrequested").getPreviousValue().asDouble() != 0.0) {
                newReceipt.setValue("qtyrequested", this.getMboValue("qtyrequested").getPreviousValue().asDouble(), 2L);
            }
            else {
                newReceipt.setValue("qtyrequested", this.getDouble("qtyrequested"), 2L);
            }
            newReceipt.setValue("linecost", this.getDouble("qtyrequested") * newReceipt.getDouble("unitcost"), 11L);
            if (this.failed) {
                newReceipt.setValue("qtyrequested", this.prevValue, 2L);
            }
            newReceipt.setValue("qtyalreadyrecvd", this.getDouble("receivedqty"), 11L);
            newReceipt.setValue("asn", this.getString("asn"), 2L);
            if (!this.getString("packingslipnum").equals("")) {
                newReceipt.setValue("packingslipnum", this.getString("packingslipnum"), 2L);
            }
            if (!this.isNull("matrectransid")) {
                newReceipt.setValue("receiptref", this.getLong("matrectransid"), 11L);
            }
        }
        catch (MXApplicationException e) {
            targetSet.remove(newReceipt);
            this.failed = true;
            this.prevValue = this.getMboValue("qtyrequested").getPreviousValue().asDouble();
            throw e;
        }
        return newReceipt;
    }
    
    @Override
    public void setPOMbo(final PORemote po) throws RemoteException {
        this.passedInPO = po;
    }
    
    @Override
    public void setPOLineMbo(final POLineRemote poLine) throws RemoteException {
        this.passedInPOLine = poLine;
    }
    
    @Override
    public void setMRMbo(final MRRemote mr) throws RemoteException {
        this.passedInMR = mr;
    }
    
    @Override
    public void setPOLineSet(final POLineSetRemote poLineSet) throws RemoteException {
        this.passedInPOLineSet = poLineSet;
    }
    
    @Override
    public void setShipmentLine(final ShipmentLineRemote sml) throws RemoteException {
        this.passedInShipmentLine = sml;
    }
    
    @Override
    public void setShipment(final ShipmentRemote sm) throws RemoteException {
        this.passedInShipment = sm;
    }
    
    @Override
    public MboRemote createReturnReceipt(final MboSetRemote targetSet) throws MXException, RemoteException {
        boolean bulletinAdded = false;
        MXServer.getBulletinBoard().post("receiptInput.DONTPERFORMCHECKFORADD", this.getUserInfo());
        if (!MXServer.getBulletinBoard().isPosted("PO.NOCHECKPOCLOSE")) {
            MXServer.getBulletinBoard().post("PO.NOCHECKPOCLOSE");
            bulletinAdded = true;
        }
        final MboRemote newReceipt = targetSet.addAtEnd(2L);
        MXServer.getBulletinBoard().remove("receiptInput.DONTPERFORMCHECKFORADD", this.getUserInfo());
        if (bulletinAdded) {
            MXServer.getBulletinBoard().remove("PO.NOCHECKPOCLOSE");
        }
        try {
            final String relationName = this.getThisMboSet().getRelationName();
            if (relationName != null && relationName.equalsIgnoreCase("VOIDRECEIPTINPUT")) {
                newReceipt.setValue("issuetype", "!VOIDRECEIPT!", 11L);
                newReceipt.setValue("actualdate", this.getDate("actualdate"), 11L);
                newReceipt.setFieldFlag("receiptquantity", 7L, true);
            }
            else {
                newReceipt.setValue("issuetype", "!RETURN!", 11L);
            }
            newReceipt.setValue("receiptref", this.getLong("matrectransid"), 11L);
            newReceipt.setValue("ponum", this.getString("ponum"), 2L);
            newReceipt.setValue("polinenum", this.getString("polinenum"), 2L);
            newReceipt.setValue("exchangerate", this.getDouble("exchangerate"), 2L);
            if (this.getDouble("qtyrequested") < 0.0) {
                this.setValue("qtyrequested", this.getDouble("qtyrequested") * -1.0, 11L);
            }
            final POLineRemote thisPOLine = ((MatRecTransRemote)newReceipt).getPOLine();
            if (thisPOLine != null && thisPOLine.getDouble("orderqty") < 0.0 && relationName != null && relationName.equalsIgnoreCase("VOIDRECEIPTINPUT")) {
                newReceipt.setValue("receiptquantity", this.getDouble("qtyrequested"), 2L);
            }
            else if (thisPOLine != null && thisPOLine.getDouble("orderqty") < 0.0 && relationName != null && relationName.equalsIgnoreCase("RETURNRECEIPTINPUT")) {
                newReceipt.setValue("receiptquantity", this.getDouble("qtyrequested"), 2L);
            }
            else {
                newReceipt.setValue("receiptquantity", this.getDouble("qtyrequested") * -1.0, 2L);
            }
            newReceipt.setValue("asn", this.getString("asn"), 2L);
            newReceipt.setValue("invoicenum", this.getString("invoicenum"), 2L);
            if (!this.isNull("remark")) {
                newReceipt.setValue("remark", this.getString("remark"), 2L);
            }
            newReceipt.setValue("tostoreloc", this.getString("tostoreloc"), 11L);
            newReceipt.setValue("tobin", this.getString("tobin"), 11L);
            newReceipt.setValue("tolot", this.getString("tolot"), 11L);
            newReceipt.setValue("conditioncode", this.getString("conditioncode"), 11L);
            final MboSetRemote shipmentLineSetRemote = thisPOLine.getMboSet("SHIPMENTLINE");
            if (!shipmentLineSetRemote.isEmpty()) {
                int j = 0;
                while (true) {
                    final MboRemote shipmentLineRemote = shipmentLineSetRemote.getMbo(j);
                    if (shipmentLineRemote == null) {
                        break;
                    }
                    if (shipmentLineRemote.getString("rectransid").equalsIgnoreCase(newReceipt.getString("receiptref"))) {
                        shipmentLineRemote.setValueNull("rectransid");
                    }
                    ++j;
                }
            }
            if (this.getBoolean("inspectionrequired")) {
                newReceipt.setValue("gldebitacct", thisPOLine.getString("gldebitacct"), 11L);
                newReceipt.setValue("status", "!COMP!", 2L);
            }
            newReceipt.setValue("enterby", this.getString("enterby"), 11L);
            newReceipt.setFieldFlag("conditioncode", 7L, true);
            newReceipt.setFieldFlag("tobin", 7L, true);
            newReceipt.setFieldFlag("tolot", 7L, true);
        }
        catch (MXApplicationException e) {
            targetSet.remove(newReceipt);
            this.failed = true;
            this.getMboValue("qtyrequested").getPreviousValue().asDouble();
            throw e;
        }
        return newReceipt;
    }
    
    @Override
    public MboRemote createReturnReceiptSrv(final MboSetRemote targetSet) throws MXException, RemoteException {
        boolean bulletinAdded = false;
        MXServer.getBulletinBoard().post("receiptInput.DONTPERFORMCHECKFORADD", this.getUserInfo());
        if (!MXServer.getBulletinBoard().isPosted("PO.NOCHECKPOCLOSE")) {
            MXServer.getBulletinBoard().post("PO.NOCHECKPOCLOSE");
            bulletinAdded = true;
        }
        final MboRemote newReceipt = targetSet.addAtEnd(2L);
        MXServer.getBulletinBoard().remove("receiptInput.DONTPERFORMCHECKFORADD", this.getUserInfo());
        if (bulletinAdded) {
            MXServer.getBulletinBoard().remove("PO.NOCHECKPOCLOSE");
        }
        try {
            final String relationName = this.getThisMboSet().getRelationName();
            if (relationName != null && relationName.equalsIgnoreCase("VOIDRECEIPTINPUTSRV")) {
                newReceipt.setValue("issuetype", "!VOIDRECEIPT!", 11L);
                newReceipt.setValue("enterdate", this.getDate("actualdate"), 11L);
                newReceipt.setFieldFlag("receiptquantity", 7L, true);
                newReceipt.setFieldFlag("qtytoreceive", 7L, true);
                newReceipt.setFieldFlag("issuetype", 7L, true);
                newReceipt.setFieldFlag("currencytax1", 7L, true);
                newReceipt.setFieldFlag("currencyloadedcost", 7L, true);
                newReceipt.setFieldFlag("claimnum", 7L, true);
                newReceipt.setFieldFlag("polinenum", 7L, true);
            }
            else {
                newReceipt.setValue("issuetype", "!RETURN!", 11L);
            }
            newReceipt.setValue("receiptref", this.getLong("matrectransid"), 11L);
            newReceipt.setValue("ponum", this.getString("ponum"), 2L);
            newReceipt.setValue("polinenum", this.getString("polinenum"), 2L);
            newReceipt.setValue("exchangerate", this.getDouble("exchangerate"), 2L);
            newReceipt.setValue("invoicenum", this.getString("invoicenum"), 2L);
            if (!this.isNull("remark")) {
                newReceipt.setValue("remark", this.getString("remark"), 2L);
            }
            newReceipt.setValue("enterby", this.getString("enterby"), 11L);
            if (this.isNull("qtyrequested")) {
                if (this.getDouble("costrequested") < 0.0) {
                    this.setValue("costrequested", this.getDouble("costrequested") * -1.0, 11L);
                }
                newReceipt.setValueNull("qtytoreceive", 2L);
                newReceipt.setValue("currencylinecost", this.getDouble("costrequested") * -1.0, 2L);
            }
            else {
                if (this.getDouble("qtyrequested") < 0.0) {
                    boolean needConvert = true;
                    final POLineRemote thisPOLine = ((ReceiptMbo)newReceipt).getPOLine();
                    if (thisPOLine != null && thisPOLine.getDouble("orderqty") < 0.0 && relationName != null && (relationName.equalsIgnoreCase("VOIDRECEIPTINPUTSRV") || relationName.equalsIgnoreCase("RETURNRECEIPTINPUTSRV"))) {
                        needConvert = false;
                    }
                    if (needConvert) {
                        this.setValue("qtyrequested", this.getDouble("qtyrequested") * -1.0, 11L);
                    }
                }
                newReceipt.setValue("qtytoreceive", this.getDouble("qtyrequested") * -1.0, 2L);
            }
            newReceipt.setValue("status", "!COMP!", 2L);
        }
        catch (MXApplicationException e) {
            targetSet.remove(newReceipt);
            this.failed = true;
            this.getMboValue("qtyrequested").getPreviousValue().asDouble();
            throw e;
        }
        return newReceipt;
    }
    
    @Override
    public MboRemote createReturnShipReceipt(final MboSetRemote targetSet) throws MXException, RemoteException {
        final MboRemote newReceipt = targetSet.addAtEnd(2L);
        try {
            final String relationName = this.getThisMboSet().getRelationName();
            if (relationName != null && relationName.equalsIgnoreCase("VOIDRECEIPTINPUT")) {
                newReceipt.setValue("issuetype", "!VOIDSHIPRECEIPT!", 11L);
                newReceipt.setValue("actualdate", this.getDate("actualdate"), 11L);
                newReceipt.setFieldFlag("receiptquantity", 7L, true);
                newReceipt.setFieldFlag("tolot", 7L, true);
            }
            else {
                newReceipt.setValue("issuetype", "!SHIPRETURN!", 11L);
            }
            newReceipt.setValue("receiptref", this.getLong("matrectransid"), 11L);
            newReceipt.setValue("shipmentnum", this.getString("shipmentnum"), 2L);
            newReceipt.setValue("shipmentlinenum", this.getString("shipmentlinenum"), 2L);
            newReceipt.setValue("ponum", this.getString("ponum"), 11L);
            newReceipt.setValue("polinenum", this.getString("polinenum"), 11L);
            newReceipt.setValue("exchangerate", this.getDouble("exchangerate"), 2L);
            if (this.getDouble("qtyrequested") < 0.0) {
                this.setValue("qtyrequested", this.getDouble("qtyrequested") * -1.0, 11L);
            }
            newReceipt.setValue("receiptquantity", this.getDouble("qtyrequested") * -1.0, 2L);
            if (newReceipt.getDouble("conversion") != 0.0) {
                newReceipt.setValue("quantity", newReceipt.getDouble("receiptquantity") * newReceipt.getDouble("conversion"), 2L);
            }
            else {
                newReceipt.setValue("quantity", newReceipt.getDouble("receiptquantity"), 2L);
            }
            if (!this.isNull("remark")) {
                newReceipt.setValue("remark", this.getString("remark"), 2L);
            }
            newReceipt.setValue("tostoreloc", this.getString("tostoreloc"), 11L);
            newReceipt.setValue("tobin", this.getString("tobin"), 11L);
            newReceipt.setValue("tolot", this.getString("tolot"), 11L);
            final MboRemote thisShipmentLine = ((MatRecTransRemote)newReceipt).getMboSet("SHIPMENTLINE").getMbo(0);
            if (thisShipmentLine != null) {
                newReceipt.setValue("fromstoreloc", thisShipmentLine.getString("fromstoreloc"), 2L);
            }
            if (this.getBoolean("inspectionrequired")) {
                newReceipt.setValue("status", "!COMP!", 2L);
            }
            newReceipt.setValue("enterby", this.getString("enterby"), 11L);
            newReceipt.setFieldFlag("conditioncode", 7L, true);
            newReceipt.setFieldFlag("tobin", 7L, true);
        }
        catch (MXApplicationException e) {
            targetSet.remove(newReceipt);
            this.failed = true;
            this.getMboValue("qtyrequested").getPreviousValue().asDouble();
            throw e;
        }
        return newReceipt;
    }
    
    @Override
    public String getInternalLineType() throws MXException, RemoteException {
        return this.getTranslator().toInternalString("LINETYPE", this.getString("linetype"));
    }
}